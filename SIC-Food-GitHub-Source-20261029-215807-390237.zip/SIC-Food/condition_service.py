"""CPU EfficientNet inference; independent image classification, no downloads."""
import math
import time
from threading import RLock
from pathlib import Path
from pipeline_config import PIPELINE, TARGET_INGREDIENTS, parse_condition_class
from image_service import normalize_image


class ConditionClassifier:
    def __init__(self, model, transform, class_names, metadata=None):
        self.model = model
        self.transform = transform
        self.class_names = class_names
        self.metadata = metadata or {}
        self._inference_lock = RLock()

    def _scores(self, image):
        import torch
        image = normalize_image(image)
        with self._inference_lock, torch.inference_mode():
            logits = self.model(self.transform(image).unsqueeze(0).to('cpu'))
            if logits.shape != (1, len(self.class_names)) or not torch.isfinite(logits).all():
                raise ValueError('Đầu ra EfficientNet không hợp lệ.')
            return logits.softmax(1)[0]

    def ingredient_groups(self):
        """Validate the paired-state contract before marginalizing class scores."""
        groups = {}
        for index, label in enumerate(self.class_names):
            ingredient, state = parse_condition_class(label)
            states = groups.setdefault(ingredient, {})
            if state in states:
                raise ValueError('Trùng trạng thái trong class_names.')
            states[state] = index
        if not groups or any(set(states) != {'normal_appearance', 'visible_defect'}
                             for states in groups.values()):
            raise ValueError('Cần đúng hai trạng thái cho mỗi nguyên liệu.')
        return groups

    def predict_ingredient(self, image):
        """P(ingredient) sums its two classes; condition score is conditional."""
        started = time.perf_counter()
        groups = self.ingredient_groups()
        scores = self._scores(image).tolist()
        marginal = {name: sum(scores[i] for i in states.values())
                    for name, states in groups.items()}
        ingredient = max(marginal, key=marginal.get)
        states = groups[ingredient]
        condition = max(states, key=lambda state: scores[states[state]])
        ingredient_score = marginal[ingredient]
        top = []
        for index in sorted(range(len(scores)), key=lambda i: (-scores[i], i))[:3]:
            name, state = parse_condition_class(self.class_names[index])
            top.append({'class_index': index, 'label': self.class_names[index],
                        'ingredient': name, 'appearance': state, 'confidence': scores[index]})
        return {'ingredient': ingredient, 'condition': condition,
                'ingredient_score': ingredient_score,
                'condition_score': scores[states[condition]] / ingredient_score if ingredient_score else 0.0,
                'top3': top, 'class_count': len(self.class_names),
                'elapsed_ms': (time.perf_counter() - started) * 1000}

    def predict(self, image, ingredient=None, top_k=3):
        import torch
        started = time.perf_counter()
        scores = self._scores(image)
        confidence, index = scores.max(0)
        label = self.class_names[int(index)]
        predicted_ingredient, condition = parse_condition_class(label)
        confidence = float(confidence)
        accepted = (ingredient is None or predicted_ingredient == ingredient) and confidence >= PIPELINE['classification_threshold']
        top_scores, indices = scores.topk(min(max(1, int(top_k)), len(self.class_names)))
        top = []
        for score, idx in zip(top_scores.tolist(), indices.tolist()):
            item_label = self.class_names[idx]
            name, state = parse_condition_class(item_label)
            top.append({'class_index': idx, 'label': item_label, 'ingredient': name,
                        'appearance': state, 'confidence': score})
        return {'label': label, 'confidence': confidence,
                'ingredient': predicted_ingredient, 'appearance': condition, 'class_index': int(index),
                'top3': top, 'probabilities': scores.tolist(), 'class_count': len(self.class_names),
                'elapsed_ms': (time.perf_counter()-started)*1000,
                'visual_condition': condition if accepted else 'unknown',
                'status': 'classified' if accepted else 'uncertain'}


def classification_transform(image_size):
    from torchvision import transforms
    return transforms.Compose([
        transforms.Resize((image_size, image_size)), transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])])


def load_classifier_file(path, expected_classes=None, expected_version=None):
    """Load exact training contracts; never guess a model's preprocessing.

    Supported checkpoints:
    - legacy37: 37-class fast-track, ImageNet B0 evaluation transform.
    - v5:       38-class head trained with Resize((224,224)).
    - v6:       38-class V5 continuation with the same preprocessing.
    - legacy_format: older architecture/state_dict/image_size checkpoint (unit tests).
    """
    import torch
    from torchvision.models import efficientnet_b0

    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f'Chưa có checkpoint: {path}')
    checkpoint = torch.load(path, map_location='cpu', weights_only=True)
    if not isinstance(checkpoint, dict):
        raise ValueError('Checkpoint phải là dict có state_dict và class_names.')
    names = checkpoint.get('class_names')
    if (not isinstance(names, (list, tuple)) or not names
            or not all(isinstance(n, str) and n for n in names)
            or len(set(names)) != len(names)):
        raise ValueError('class_names thiếu, trống hoặc trùng lặp.')
    names = list(names)
    parsed = [parse_condition_class(name) for name in names]

    if expected_classes is not None and len(names) != expected_classes:
        raise ValueError(f'Checkpoint cần có {expected_classes} lớp, nhận được {len(names)}.')

    if 'model_state_dict' in checkpoint:
        # This is the actual training format used in V3-fasttrack/V5/V6 notebooks.
        metadata_classes = checkpoint.get('num_classes')
        if metadata_classes != len(names):
            raise ValueError('num_classes không khớp class_names.')

        training_type = checkpoint.get('training_type')
        if training_type == 'prototype_frozen_backbone':
            version = 'legacy37'
            if len(names) != 37 or checkpoint.get('pretrained_weights') != 'IMAGENET1K_V1':
                raise ValueError('Metadata checkpoint fast-track không tương thích.')
            from torchvision.models import EfficientNet_B0_Weights
            transform = EfficientNet_B0_Weights.IMAGENET1K_V1.transforms()
            preprocess_name = 'ImageNet B0: Resize256/CenterCrop224'
        elif training_type in ('provisional_head_training', 'v6_head_finetuning'):
            version = 'v5' if training_type == 'provisional_head_training' else 'v6'
            if len(names) != 38:
                raise ValueError('V5/V6 phải có chính xác 38 lớp.')
            # 19 ingredients, each with both required states, no injected category.
            class_groups = {}
            for ingredient, appearance in parsed:
                class_groups.setdefault(ingredient, set()).add(appearance)
            if len(class_groups) != 19 or any(
                states != {'normal_appearance', 'visible_defect'}
                for states in class_groups.values()
            ) or 'broccoli' in class_groups:
                raise ValueError('V5/V6 phải có 19 nguyên liệu x 2 trạng thái, không gồm broccoli.')
            transform = classification_transform(224)
            preprocess_name = 'Resize((224,224))/ToTensor/ImageNetNormalize'
        else:
            raise ValueError(f'training_type không được hỗ trợ: {training_type!r}')
        state = checkpoint['model_state_dict']
    else:
        # Keep compatibility with previous documented legacy checkpoint format.
        version = 'legacy_format'
        if checkpoint.get('architecture') != 'efficientnet_b0':
            raise ValueError('Checkpoint phải dùng efficientnet_b0.')
        image_size = checkpoint.get('image_size')
        if not isinstance(image_size, int) or not 32 <= image_size <= 1024:
            raise ValueError('image_size không hợp lệ.')
        if 'state_dict' not in checkpoint:
            raise ValueError('Checkpoint thiếu state_dict.')
        state = checkpoint['state_dict']
        transform = classification_transform(image_size)
        preprocess_name = f'Resize(({image_size},{image_size}))/ToTensor/ImageNetNormalize'

    if expected_version is not None and version != expected_version:
        raise ValueError(
            f'Chọn model {expected_version}, nhưng checkpoint là {version}. '
            'Không được dùng nhầm phiên bản checkpoint.'
        )

    if not isinstance(state, dict) or 'classifier.1.weight' not in state:
        raise ValueError('state_dict thiếu classifier.1.weight.')
    if tuple(state['classifier.1.weight'].shape) != (len(names), 1280):
        raise ValueError('Classifier không khớp class_names.')

    model = efficientnet_b0(weights=None)
    model.classifier[1] = torch.nn.Linear(model.classifier[1].in_features, len(names))
    model.load_state_dict(state, strict=True)
    model.to('cpu').eval()
    metadata = {k: checkpoint.get(k) for k in (
        'epoch', 'training_type', 'validation_scope', 'pretrained_weights', 'val_macro_f1'
    )}
    metadata.update({
        'version': version,
        'checkpoint_path': str(path.resolve()),
        'preprocessing': preprocess_name,
        'class_count': len(names),
        'ingredient_count': len(set(ingredient for ingredient, _ in parsed)),
    })
    return ConditionClassifier(model, transform, names, metadata)


def classify_detections(detections, image, classifier=None):
    """Retain every detection, including unsupported objects and invalid crops."""
    width, height = image.size
    for detection in detections:
        ingredient = detection['prediction']['ingredient_id']
        detection['prediction']['visual_condition'] = 'unknown'
        assessment = {'status': 'model_unavailable', 'visual_condition': 'unknown'}
        if ingredient not in TARGET_INGREDIENTS:
            assessment['status'] = 'unsupported_ingredient'
        elif classifier is not None:
            coords = detection['bbox']
            if len(coords) != 4 or not all(math.isfinite(v) for v in coords):
                assessment['status'] = 'invalid_crop'
            else:
                x1, y1, x2, y2 = coords
                box = (max(0, math.floor(x1)), max(0, math.floor(y1)),
                       min(width, math.ceil(x2)), min(height, math.ceil(y2)))
                if box[2] <= box[0] or box[3] <= box[1]:
                    assessment['status'] = 'invalid_crop'
                else:
                    try:
                        assessment = classifier.predict(image.crop(box), ingredient)
                    except Exception:
                        assessment['status'] = 'inference_error'
        detection['condition_assessment'] = assessment
        detection['prediction']['visual_condition'] = assessment['visual_condition']
    return detections
