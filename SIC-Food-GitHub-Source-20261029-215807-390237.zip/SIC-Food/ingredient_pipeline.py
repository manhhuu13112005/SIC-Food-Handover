"""One Module 2 workflow: YOLO -> supported raw-ingredient crop -> V5.

No data/model downloads, no whole-image fallback, no writes of uploaded images.
Object order is lexicographic (x1, y1, x2, y2, class_id, -score), not YOLO order.
"""
import json
import logging
import math
import time
from pathlib import Path

from detection_service import detect_ingredients
from image_service import normalize_image

LOG = logging.getLogger(__name__)
CONFIG_PATH = Path(__file__).resolve().parent / 'config/ingredient_pipeline.json'
REVIEW_STATUSES = {'low_confidence', 'disagreement', 'error'}


def load_pipeline_settings():
    return json.loads(CONFIG_PATH.read_text(encoding='utf-8'))


def validate_settings(settings):
    for name in ('confidence', 'iou', 'padding', 'ingredient_warning_threshold', 'condition_warning_threshold'):
        value = settings[name]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1:
            raise ValueError(f'Cấu hình {name} phải nằm trong [0,1].')
    for name, low, high in [('max_detections', 1, 100), ('image_size', 32, 1280)]:
        value = settings[name]
        if isinstance(value, bool) or not isinstance(value, int) or not low <= value <= high:
            raise ValueError(f'Cấu hình {name} không hợp lệ.')
    if not isinstance(settings['agnostic_nms'], bool) or not isinstance(settings['aliases'], dict):
        raise ValueError('Cấu hình NMS/alias không hợp lệ.')


def supported_ingredient(label, supported, aliases):
    name = label.strip().casefold()
    # Exact canonical names, plus explicitly equivalent aliases only. No fuzzy match.
    name = aliases.get(name, name)
    return name if name in supported else None


def crop_bounds(bbox, size, padding=0.0):
    if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
        raise ValueError('Bounding box cần bốn tọa độ XYXY.')
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in bbox):
        raise ValueError('Bounding box chứa tọa độ không hợp lệ.')
    x1, y1, x2, y2 = bbox
    if x2 <= x1 or y2 <= y1:
        raise ValueError('Bounding box rỗng hoặc đảo tọa độ.')
    width, height = size
    dx, dy = (x2-x1)*padding, (y2-y1)*padding
    # Match the notebook's int truncation after clipping (baseline padding=0).
    box = (int(max(0, min(width, x1-dx))), int(max(0, min(height, y1-dy))),
           int(max(0, min(width, x2+dx))), int(max(0, min(height, y2+dy))))
    if box[2] <= box[0] or box[3] <= box[1]:
        raise ValueError('Bounding box nằm ngoài ảnh hoặc crop rỗng.')
    return box


def _order(detection):
    box = detection.get('bbox', [])
    if len(box) != 4 or not all(isinstance(v, (int, float)) and math.isfinite(v) for v in box):
        return (float('inf'),)*4 + (detection.get('class_id', -1), 0)
    return (*box, detection['class_id'], -detection['confidence'])


def validate_classifier(classifier):
    if classifier.metadata.get('version') != 'v5' or len(classifier.class_names) != 38:
        raise ValueError('Pipeline yêu cầu đúng EfficientNet V5 38 lớp.')
    supported = list(classifier.ingredient_groups())
    if len(supported) != 19:
        raise ValueError('V5 phải có đúng 19 nguyên liệu.')
    return supported


def classify_object(image, row, classifier, settings, reference_ingredient):
    """Shared crop inference for automatic boxes and explicitly reviewed regions.

    A manual reference opens the support gate; it does not force V5's prediction.
    The caller retains YOLO provenance separately and validates user confirmation.
    """
    row = dict(row)
    row.update(ingredient=None, condition=None, ingredient_score=None, condition_score=None,
               top3=[], warnings=[], error_code=None, status='error', crop_xyxy=None,
               supported=reference_ingredient is not None)
    try:
        row['crop_xyxy'] = list(crop_bounds(row['bbox_xyxy'], image.size, settings['padding']))
    except ValueError as error:
        row['error_code'] = 'invalid_crop'
        row['warnings'].append(str(error))
        return row
    if reference_ingredient is None:
        row['status'] = 'unsupported'
        row['warnings'].append('Nhãn YOLO ngoài phạm vi V5; chưa có xác nhận nguyên liệu thủ công.')
        return row
    supported = validate_classifier(classifier)
    if reference_ingredient not in supported:
        raise ValueError('Nguyên liệu xác nhận không thuộc phạm vi V5.')
    try:
        prediction = classifier.predict_ingredient(image.crop(row['crop_xyxy']))
        row.update({k: prediction[k] for k in ('ingredient', 'condition', 'ingredient_score', 'condition_score', 'top3')})
        if row['ingredient'] not in supported or row['condition'] not in ('normal_appearance', 'visible_defect'):
            raise ValueError('Kết quả phân loại ngoài contract V5.')
        if not all(isinstance(row[k], (int, float)) and math.isfinite(row[k]) and 0 <= row[k] <= 1
                   for k in ('ingredient_score', 'condition_score')):
            raise ValueError('Điểm phân loại không hợp lệ.')
        low = (row['ingredient_score'] < settings['ingredient_warning_threshold']
               or row['condition_score'] < settings['condition_warning_threshold'])
        disagreement = row['ingredient'] != reference_ingredient
        row['status'] = 'disagreement' if disagreement else 'low_confidence' if low else 'classified'
        if disagreement:
            row['warnings'].append('V5 khác nguyên liệu tham chiếu YOLO hoặc người dùng; cần kiểm tra nhãn và crop.')
        if low:
            row['warnings'].append('Điểm dưới ngưỡng cảnh báo thử nghiệm, chưa được hiệu chỉnh.')
        if row.get('manual_confirmation'):
            row['warnings'].append('Crop được chạy V5 sau xác nhận thủ công; nhãn YOLO gốc được giữ riêng.')
    except Exception:
        LOG.exception('V5 crop inference failed for object %s', row['object_id'])
        row.update(status='error', ingredient=None, condition=None, ingredient_score=None,
                   condition_score=None, top3=[], error_code='classification_error')
        row['warnings'].append('Không phân loại được crop này; các đối tượng khác vẫn được xử lý.')
    return row


def analyze_ingredients(image, detector, classifier, settings=None):
    started = time.perf_counter()
    settings = dict(settings if settings is not None else load_pipeline_settings())
    validate_settings(settings)
    supported = validate_classifier(classifier)
    image = normalize_image(image)
    detections = detect_ingredients(detector, image,
        confidence=settings['confidence'], image_size=settings['image_size'],
        iou=settings['iou'], agnostic_nms=settings['agnostic_nms'],
        max_detections=settings['max_detections'])
    # Limit work even for a custom detector which ignores max_det.
    detections = sorted(detections, key=_order)[:settings['max_detections']]
    objects = []
    for object_id, detection in enumerate(detections, 1):
        raw = detection['bbox']
        row = {'object_id': object_id,
               'bbox_xyxy': [v if math.isfinite(v) else None for v in raw],
               'crop_xyxy': None, 'yolo_label': detection['original_label'],
               'class_id': detection['class_id'], 'yolo_score': detection['confidence'],
               'yolo_ingredient': None, 'supported': False, 'status': 'error',
               'ingredient': None, 'condition': None, 'ingredient_score': None,
               'condition_score': None, 'top3': [], 'warnings': [], 'error_code': None}
        objects.append(row)
        name = supported_ingredient(row['yolo_label'], supported, settings['aliases'])
        row['yolo_ingredient'] = name
        row['supported'] = name is not None
        objects[-1] = classify_object(image, row, classifier, settings, name)
    return {'objects': objects, 'summary': summarize_objects(objects), 'supported_ingredients': supported,
            'elapsed_ms': (time.perf_counter()-started)*1000, 'settings': settings,
            'model_metadata': dict(classifier.metadata), 'detector_class_count': len(detector.names),
            'limit_reached': len(detections) >= settings['max_detections']}


def summarize_objects(objects):
    return {'detected': len(objects), 'supported': sum(r['supported'] for r in objects),
            'classified': sum(r['ingredient'] is not None for r in objects),
            'visible_defect': sum(r['condition'] == 'visible_defect' for r in objects),
            'needs_review': sum(r['status'] in REVIEW_STATUSES for r in objects),
            'unsupported': sum(r['status'] == 'unsupported' for r in objects)}


def effective_result(row, edit=None):
    """Human edits are an overlay; original AI output is never mutated."""
    edit = edit or {}
    return {'ingredient': edit.get('ingredient', row['ingredient'] or 'uncertain'),
            'condition': edit.get('condition', row['condition'] or 'uncertain'),
            'review': edit.get('review', 'pending'),
            'source': 'user' if edit else 'ai', 'ai_status': row['status']}


def annotate_objects(image, objects, edits=None):
    from PIL import ImageDraw, ImageFont
    from ui_components import food_name
    canvas = image.copy()
    draw = ImageDraw.Draw(canvas)
    size = max(14, min(30, canvas.width//50))
    try:
        font = ImageFont.truetype('C:/Windows/Fonts/arial.ttf', size)
    except OSError:
        font = ImageFont.load_default()
    for row in objects:
        box = row['crop_xyxy']
        if not box:
            continue
        value = effective_result(row, (edits or {}).get(str(row['object_id'])))
        check = (row['status'] != 'classified' and value['review'] != 'confirmed') or value['review'] == 'needs_review'
        condition = value['condition']
        color = '#b77910' if check or condition == 'uncertain' else '#c13e3e' if condition == 'visible_defect' else '#24754d'
        text = f"{row['object_id']:02d} · {food_name(value['ingredient']) if value['ingredient'] != 'uncertain' else (row['yolo_label'] or 'Vùng thủ công')}"
        if row.get('origin') == 'manual':
            text += ' [thêm]'
        elif row.get('geometry_edited'):
            text += ' [sửa vùng]'
        text += ' · Kiểm tra' if check else ' · Bất thường' if condition == 'visible_defect' else ' · Bình thường'
        if value['source'] == 'user':
            text += ' (sửa)'
        x1, y1, x2, y2 = box
        draw.rectangle(box, outline=color, width=max(2, canvas.width//300))
        bounds = draw.textbbox((0, 0), text, font=font)
        tw, th = bounds[2]-bounds[0]+10, bounds[3]-bounds[1]+8
        x, y = max(0, min(x1, canvas.width-tw)), max(0, y1-th)
        draw.rectangle((x, y, min(canvas.width, x+tw), y+th), fill=color)
        draw.text((x+5, y+3-bounds[1]), text, font=font, fill='white')
    return canvas
