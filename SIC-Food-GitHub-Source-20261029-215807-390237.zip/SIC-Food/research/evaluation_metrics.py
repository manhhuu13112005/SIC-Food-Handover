"""Dependency-light metrics with explicit denominators and matching rules."""
from collections import Counter


def ratio(n, d):
    return n / d if d else None


def classification(truth, predicted, labels):
    if len(truth) != len(predicted):
        raise ValueError('Unequal prediction and truth lengths')
    labels = list(labels)
    if any(x not in labels for x in truth + predicted):
        raise ValueError('Unknown class')
    matrix = [[0 for _ in labels] for _ in labels]
    for actual, guess in zip(truth, predicted):
        matrix[labels.index(actual)][labels.index(guess)] += 1
    rows = []
    for i, label in enumerate(labels):
        tp = matrix[i][i]
        support = sum(matrix[i])
        called = sum(row[i] for row in matrix)
        # Zero division is 0 for class metrics; unsupported classes are explicitly marked.
        precision, recall = tp / called if called else 0., tp / support if support else 0.
        rows.append(dict(label=label, support=support, predicted=called,
                         precision=precision, recall=recall,
                         f1=2 * precision * recall / (precision + recall) if precision + recall else 0.))
    supported = [r for r in rows if r['support']]
    return dict(n=len(truth), accuracy=ratio(sum(a == b for a, b in zip(truth, predicted)), len(truth)),
                macro_f1=ratio(sum(r['f1'] for r in rows), len(rows)) if truth else None,
                macro_f1_supported=ratio(sum(r['f1'] for r in supported), len(supported)),
                labels=labels, confusion_matrix=matrix, per_class=rows)


def classifier_metrics(rows, ingredients):
    """Each row is a reviewed, matched crop; uncertain remains in ingredient accuracy."""
    valid = [r for r in rows if r['ingredient'] in ingredients]
    known = [r for r in valid if r['condition'] != 'uncertain']
    correct_ingredient = [r for r in known if r['ingredient'] == r['pred_ingredient']]
    ingredient = classification([r['ingredient'] for r in valid],
                                [r['pred_ingredient'] for r in valid], ingredients)
    joint_labels = [f'{i}/{s}' for i in ingredients for s in ('normal_appearance', 'visible_defect')]
    joint = classification([f"{r['ingredient']}/{r['condition']}" for r in known],
                           [f"{r['pred_ingredient']}/{r['pred_condition']}" for r in known], joint_labels)
    return dict(ingredient=ingredient, joint=joint, uncertain_excluded=len(valid) - len(known),
                condition_given_correct_ingredient=ratio(
                    sum(r['condition'] == r['pred_condition'] for r in correct_ingredient), len(correct_ingredient)),
                condition_denominator=len(correct_ingredient), out_of_scope_excluded=len(rows) - len(valid))


def iou(a, b):
    intersection = max(0., min(a[2], b[2]) - max(a[0], b[0])) * max(0., min(a[3], b[3]) - max(a[1], b[1]))
    union = (a[2]-a[0])*(a[3]-a[1]) + (b[2]-b[0])*(b[3]-b[1]) - intersection
    return intersection / union if union > 0 else 0.


def match_boxes(predictions, truth, threshold=.5, class_aware=False):
    """Confidence ordered, one-to-one matching within each image (ties by stable id)."""
    matched, events = set(), []
    for p in sorted(predictions, key=lambda r: (-r['confidence'], r['image_id'], r['id'])):
        candidates = [(iou(p['bbox'], g['bbox']), index) for index, g in enumerate(truth)
                      if index not in matched and p['image_id'] == g['image_id']
                      and (not class_aware or p['label'] == g['label'])]
        score, index = max(candidates, default=(0., -1))
        good = index >= 0 and score >= threshold
        if good:
            matched.add(index)
        events.append((p, truth[index] if good else None, score if good else 0.))
    return events


def average_precision(predictions, truth, threshold, class_aware=False):
    if not truth:
        return None
    events = match_boxes(predictions, truth, threshold, class_aware)
    tp, fp, curve = 0, 0, []
    for _, match, _ in events:
        tp += match is not None
        fp += match is None
        curve.append((tp / len(truth), tp / (tp + fp)))
    # 101 recall points, monotonic precision envelope, no interpolation between points.
    return sum(max((p for r, p in curve if r >= k / 100), default=0.) for k in range(101)) / 101


def detection_metrics(predictions, truth):
    events = match_boxes(predictions, truth)
    tp = sum(g is not None for _, g, _ in events)
    # 'out_of_scope' is a scope marker, not an actual detector category.
    # Localization still includes these objects; category AP cannot infer their true class.
    labels = sorted({g['label'] for g in truth if g['label'] != 'out_of_scope'})
    per_class = []
    for label in labels:
        ps, gs = [p for p in predictions if p['label'] == label], [g for g in truth if g['label'] == label]
        aps = [average_precision(ps, gs, .5 + .05*k, True) for k in range(10)]
        class_tp = sum(g is not None for _, g, _ in match_boxes(ps, gs, class_aware=True))
        per_class.append(dict(label=label, support=len(gs), precision_iou50=ratio(class_tp, len(ps)),
                              recall_iou50=ratio(class_tp, len(gs)), ap50=aps[0], map50_95=sum(aps)/10))
    return dict(protocol='IoU .50:.05:.95, 101 recall points, max_det frozen from config; no area/crowd handling',
                actual=len(truth), detected=len(predictions), localization_tp_iou50=tp,
                localization_precision_iou50=ratio(tp, len(predictions)), localization_recall_iou50=ratio(tp, len(truth)),
                localization_ap50=average_precision(predictions, truth, .5),
                localization_map50_95=ratio(sum(average_precision(predictions, truth, .5+.05*k) or 0. for k in range(10)), 10) if truth else None,
                class_aware_map50_95=ratio(sum(r['map50_95'] for r in per_class), len(per_class)),
                class_aware_out_of_scope_gt_excluded=sum(g['label']=='out_of_scope' for g in truth),
                per_class=per_class)
