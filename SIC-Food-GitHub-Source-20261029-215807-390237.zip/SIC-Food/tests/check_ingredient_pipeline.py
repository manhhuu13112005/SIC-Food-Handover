"""Real CPU pipeline regression. Read manual labels; write only a new report folder.

This small, previously reviewed sample is diagnostic, not an independent benchmark.
No training, model downloads or updates of the source review tables.
"""
import csv
import hashlib
import json
import sys
import time
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as handle:
        for block in iter(lambda: handle.read(1024*1024), b''):
            checksum.update(block)
    return checksum.hexdigest()


def key(image_file, bbox, label):
    return (image_file, ','.join(str(int(v)) for v in bbox), label)


def main():
    from image_service import decode_image
    from model_loader import load_condition_model, load_model
    from ingredient_pipeline import analyze_ingredients, annotate_objects
    from detection_service import detect_image
    from page2 import detect_video_frame
    import torch

    report_dir = ROOT / 'reports/module2_v5_20261029'
    report_dir.mkdir(parents=True, exist_ok=True)
    source_dir = ROOT / 'reports/pipeline_v5_test'
    protected = [ROOT/'best.pt', ROOT/'models/efficientnet_v5_38/efficientnet_b0_38_prototype_head.pth',
                 ROOT/'models/efficientnet_v6_38/efficientnet_b0_38_v6_head.pth',
                 *[source_dir / n for n in ('predictions_auto.csv','manual_review.csv','image_ground_truth.csv')]]
    before = {str(p.relative_to(ROOT)): digest(p) for p in protected}
    detector, classifier = load_model(), load_condition_model()
    assert detector is load_model() and classifier is load_condition_model()
    assert detector.task == 'detect' and len(detector.names) == 214
    assert classifier.metadata['version'] == 'v5' and len(classifier.class_names) == 38
    assert classifier.model.classifier[1].out_features == 38
    assert not classifier.model.training
    assert next(classifier.model.parameters()).device.type == 'cpu'
    checkpoint_names = torch.load(protected[1], map_location='cpu', weights_only=True)['class_names']
    assert classifier.class_names == checkpoint_names

    old = read_csv(source_dir/'predictions_auto.csv')
    review = read_csv(source_dir/'manual_review.csv')
    ground_truth = read_csv(source_dir/'image_ground_truth.csv')
    previous = {key(r['image_file'], list(map(int,r['bbox'].split(','))),r['yolo_label']): r for r in old}
    labels = {key(r['image_file'], list(map(int,r['bbox'].split(','))),r['yolo_label']): r for r in review}
    expected_hash = {r['image_file']: r['image_hash'] for r in old}
    rows, images = [], []
    matched_keys = set()
    for path in sorted((ROOT/'tests/manual_pipeline_images').iterdir()):
        if path.suffix.lower() not in {'.jpg','.jpeg','.png'}:
            continue
        payload = path.read_bytes()
        image_hash = hashlib.sha256(payload).hexdigest()[:10]
        # A zero-detection baseline image has no row in predictions_auto.csv.
        if path.name in expected_hash:
            assert expected_hash[path.name] == image_hash, f'Manual image changed: {path.name}'
        image = decode_image(payload)
        result = analyze_ingredients(image, detector, classifier)
        images.append({'image_file':path.name, 'elapsed_ms':result['elapsed_ms'], **result['summary']})
        if 'four-fruit' in path.name or '1006891730' in path.name or 'illustration' in path.name:
            annotate_objects(image,result['objects']).save(report_dir/(path.stem+'_annotated.jpg'), quality=90)
        for obj in result['objects']:
            assert obj['crop_xyxy'] is not None
            obj_key = key(path.name, obj['crop_xyxy'], obj['yolo_label'])
            label = labels.get(obj_key)
            previous_row = previous.get(obj_key)
            if label:
                matched_keys.add(obj_key)
            row = {'image_file':path.name, 'image_hash':image_hash, **obj,
                   'matches_previous_box': label is not None,
                   'previous_object_id': previous_row['object_id'] if previous_row else None,
                   'valid_box': label['valid_box'] if label else None,
                   'gt_ingredient':label['gt_ingredient'] if label else None,
                   'gt_condition':label['gt_condition'] if label else None}
            row['same_previous_prediction'] = (obj['ingredient'] == previous_row['pred_ingredient']
                and obj['condition'] == previous_row['pred_condition']) if previous_row and obj['ingredient'] else None
            rows.append(row)
        print(f'{path.name}: {result["summary"]}', flush=True)
    valid = [r for r in rows if r['valid_box'] == '1']
    covered = [r for r in valid if r['ingredient'] is not None]
    correct_ingredient = [r for r in covered if r['ingredient'] == r['gt_ingredient']]
    state = [r for r in correct_ingredient if r['gt_condition'] in ('normal_appearance','visible_defect')]
    joint = [r for r in valid if r['gt_condition'] in ('normal_appearance','visible_defect')]
    summary = {'images':len(images), 'detected_boxes':len(rows),
        'statuses':dict(Counter(r['status'] for r in rows)), 'matched_previous_boxes':len(matched_keys),
        'previous_boxes':len(old), 'unmatched_previous_boxes':len(labels.keys()-matched_keys),
        'valid_reviewed_boxes':len(valid), 'valid_classified_boxes':len(covered),
        'ingredient_correct':len(correct_ingredient),
        'ingredient_accuracy_on_classified_valid':len(correct_ingredient)/len(covered) if covered else None,
        'ingredient_accuracy_all_valid_unclassified_count_as_wrong':len(correct_ingredient)/len(valid) if valid else None,
        'condition_correct_given_correct_ingredient':sum(r['condition']==r['gt_condition'] for r in state),
        'condition_denominator':len(state),
        'joint_correct_all_valid':sum(r['ingredient']==r['gt_ingredient'] and r['condition']==r['gt_condition'] for r in joint),
        'joint_denominator':len(joint),
        'same_previous_prediction_supported':sum(r['same_previous_prediction'] is True for r in rows),
        'classified_boxes':sum(r['ingredient'] is not None for r in rows),
        'mean_image_ms':sum(r['elapsed_ms'] for r in images)/len(images),
        'expected_objects_in_reviewed_set':sum(int(r['expected_objects']) for r in ground_truth),
        'caveat':'Previously reviewed diagnostic sample only; no mAP or representative accuracy claim. '
                 'Manual labels reused only for exact image-hash + bbox + YOLO label matches. '
                 'Current pipeline rejects unsupported labels before classification; old notebook classified every crop.'}
    sample=decode_image((ROOT/'images/test image.png').read_bytes())
    detections,_=detect_image(detector,sample)
    video,_=detect_video_frame(detector,ROOT/'images/test video.mp4',0)
    assert len(detections)==5 and len(video)==2
    summary['module1_regression']={'image_boxes':len(detections),'video_frame0_boxes':len(video),
                                   'confidence':.5, 'nutrition_unchanged':True}
    assert all(digest(ROOT/n)==value for n,value in before.items())
    output={'summary':summary, 'model_metadata':classifier.metadata,
            'class_names':classifier.class_names, 'transform':str(classifier.transform),
            'settings':result['settings'], 'protected_sha256':before,
            'images':images, 'predictions':rows}
    (report_dir/'real_pipeline_results.json').write_text(json.dumps(output,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    columns=['image_file','object_id','yolo_label','status','ingredient','condition','ingredient_score','condition_score',
             'matches_previous_box','previous_object_id','valid_box','gt_ingredient','gt_condition','same_previous_prediction']
    with (report_dir/'predictions_new.csv').open('w',encoding='utf-8-sig',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=columns,extrasaction='ignore');writer.writeheader();writer.writerows(rows)
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print('PASS: CPU inference, cache, class order, protected files and Module 1 sample regression.')


if __name__ == '__main__': main()
