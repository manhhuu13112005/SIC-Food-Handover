"""Real widgets/state with explicit mock uploads, canvas events and model inference."""
import copy
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from streamlit.testing.v1 import AppTest
from test_website_ui import picture, button, control, ROOT


class BoxReviewUITests(unittest.TestCase):
    def open_app(self):
        app=AppTest.from_file(str(ROOT/'tests/ui_harness.py'),default_timeout=30)
        app.session_state['fixture_cond']=picture('red')
        app.run()
        app.radio(key='navigation').set_value('Trạng thái nguyên liệu').run()
        button(app,'Phân tích bằng AI')
        return app

    def select_region(self,app,box,event_id):
        w=app.session_state['cond_workspace']
        app.session_state['fixture_canvas_event']={'event_id':event_id,'analysis_id':w['analysis_id'],
            'image_token':w['image_token'],'revision':w['revision'],'kind':'region','bbox':box,
            'target_id':app.session_state['cond_box_selected']}
        app.run()
        self.assertFalse(app.exception)

    def test_add_edit_delete_restore_and_only_changed_crop_runs(self):
        app=self.open_app()
        original=copy.deepcopy(app.session_state['cond_result'])
        control(app,'selectbox','Box cần chỉnh sửa').select(0).run()
        self.select_region(app,[12,12,30,30],'add-one')
        control(app,'selectbox','Nguyên liệu người dùng xác nhận').select('orange').run()
        control(app,'checkbox','Tôi xác nhận vùng chọn là nguyên liệu đã chọn để chạy V5').check().run()
        button(app,'Thêm box và phân tích V5')
        self.assertEqual(len(app.session_state['cond_workspace']['objects']),2)
        self.assertEqual(app.session_state['condition_crop_calls'],1)
        self.assertEqual(app.session_state['cond_result'],original)
        # Replaying the same event/rerunning must not append or re-infer.
        app.run()
        self.assertEqual(len(app.session_state['cond_workspace']['objects']),2)
        self.assertEqual(app.session_state['condition_crop_calls'],1)
        control(app,'selectbox','Box cần chỉnh sửa').select(2).run()
        self.select_region(app,[10,10,29,29],'edit-two')
        first=copy.deepcopy(app.session_state['cond_workspace']['objects'][0])
        button(app,'Áp dụng vùng / xác nhận')
        self.assertEqual(app.session_state['condition_crop_calls'],2)
        self.assertEqual(app.session_state['cond_workspace']['objects'][0],first)
        button(app,'Áp dụng vùng / xác nhận')
        self.assertEqual(app.session_state['condition_crop_calls'],2)
        button(app,'Loại box đã chọn')
        self.assertEqual(len(app.session_state['cond_workspace']['objects']),1)
        self.assertEqual(app.session_state['condition_crop_calls'],2)
        button(app,'Khôi phục box YOLO ban đầu')
        self.assertEqual(len(app.session_state['cond_workspace']['objects']),1)
        self.assertEqual(app.session_state['condition_crop_calls'],2)
        self.assertFalse(app.exception)

    def test_crop_change_invalidates_only_its_label_edits_and_reset_clears_editor(self):
        app=self.open_app()
        control(app,'selectbox','Tên nguyên liệu').select('banana').run()
        self.assertIn('1',app.session_state['cond_edits'])
        self.select_region(app,[1,1,22,22],'change-one')
        button(app,'Áp dụng vùng / xác nhận')
        self.assertNotIn('1',app.session_state['cond_edits'])
        self.assertEqual(app.session_state['cond_workspace']['objects'][0]['crop_xyxy'],[1,1,22,22])
        # Editor and corrections must survive page navigation.
        app.radio(key='navigation').set_value('Trang chủ').run()
        app.radio(key='navigation').set_value('Trạng thái nguyên liệu').run()
        self.assertFalse(app.exception)
        self.assertEqual(app.session_state['cond_workspace']['objects'][0]['crop_xyxy'],[1,1,22,22])
        app.session_state['fixture_cond']=picture('green')
        app.run()
        self.assertNotIn('cond_workspace',app.session_state)
        self.assertNotIn('cond_box_preview',app.session_state)
        button(app,'Phân tích bằng AI')
        app.session_state['fixture_cond']=None
        button(app,'Reset ảnh và kết quả')
        self.assertNotIn('cond_workspace',app.session_state)
        self.assertFalse(app.exception)

    def test_no_detection_still_allows_manual_region_after_analysis(self):
        app=self.open_app()
        app.session_state['fixture_cond_objects']=[]
        button(app,'Phân tích bằng AI')
        self.assertEqual(app.session_state['cond_workspace']['objects'],[])
        self.select_region(app,[1,1,25,25],'missed-region')
        # No automatic whole-image inference merely because a region was drawn.
        self.assertNotIn('condition_crop_calls',app.session_state)
        button(app,'Thêm box và phân tích V5')
        self.assertTrue(app.error)  # Requires explicit support confirmation.
        control(app,'selectbox','Nguyên liệu người dùng xác nhận').select('orange').run()
        control(app,'checkbox','Tôi xác nhận vùng chọn là nguyên liệu đã chọn để chạy V5').check().run()
        button(app,'Thêm box và phân tích V5')
        self.assertEqual(app.session_state['condition_crop_calls'],1)
        self.assertEqual(app.session_state['cond_workspace']['objects'][0]['origin'],'manual')
        self.assertTrue(app.get('download_button'))


if __name__ == '__main__':unittest.main()
