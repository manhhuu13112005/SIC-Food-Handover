"""Mock uploads and models, real main.py/widgets. Never imported in production."""
from io import BytesIO
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import runpy
import streamlit as st
from PIL import Image
import page1, page2, condition_page
import box_editor_ui


def uploader(*args, **kwargs):
    key=kwargs.get('key','')
    namespace=key.split('_')[0]
    payload=st.session_state.get('fixture_'+namespace)
    return BytesIO(payload) if payload else None


def infer(*args):
    st.session_state['detection_calls']=st.session_state.get('detection_calls',0)+1
    if st.session_state.get('fixture_fail'):
        raise RuntimeError('Internal synthetic failure must not leak')
    return st.session_state.get('fixture_detections',[]), Image.new('RGB',(32,32))


class Classifier:
    ingredients=['apple','banana','beef','bell_pepper','cabbage','carrot','chicken','cucumber','eggplant',
                 'fish','lettuce','mango','onion','orange','pork','potato','shrimp','strawberry','tomato']
    class_names=[name+'__'+state for name in ingredients for state in ('normal_appearance','visible_defect')]
    metadata={'version':'v5'}
    def ingredient_groups(self):
        return {name:{'normal_appearance':2*i,'visible_defect':2*i+1} for i,name in enumerate(self.ingredients)}
    def predict_ingredient(self,image):
        st.session_state['condition_crop_calls']=st.session_state.get('condition_crop_calls',0)+1
        return {'ingredient':'apple','condition':'normal_appearance','ingredient_score':.95,
                'condition_score':.8,'top3':[]}
    def predict(self,image):
        st.session_state['condition_calls']=st.session_state.get('condition_calls',0)+1
        return {'ingredient':'apple','appearance':'normal_appearance','confidence':.8,'status':'classified',
                'elapsed_ms':10,'class_count':37,'label':self.class_names[0],
                'top3':[{'ingredient':'apple','appearance':'normal_appearance','confidence':.8},
                        {'ingredient':'apple','appearance':'visible_defect','confidence':.15},
                        {'ingredient':'banana','appearance':'normal_appearance','confidence':.05}]}


def condition_infer(image, detector, classifier):
    from ingredient_pipeline import summarize_objects, load_pipeline_settings
    st.session_state['condition_calls'] = st.session_state.get('condition_calls', 0) + 1
    if st.session_state.get('fixture_cond_fail'):
        raise RuntimeError('Synthetic condition model failure')
    row = {'object_id': 1, 'bbox_xyxy': [0,0,20,20], 'crop_xyxy': [0,0,20,20],
           'yolo_label': 'Apple', 'class_id': 0, 'yolo_score': .9, 'yolo_ingredient': 'apple',
           'supported': True, 'status': 'classified', 'ingredient': 'apple',
           'condition': 'normal_appearance', 'ingredient_score': .95, 'condition_score': .8,
           'top3': Classifier().predict(image)['top3'], 'warnings': [], 'error_code': None}
    # Classifier.predict above is a fixture helper; count one pipeline call.
    st.session_state['condition_calls'] -= 1
    objects = st.session_state.get('fixture_cond_objects', [row])
    return {'objects': objects, 'summary': summarize_objects(objects),
            'supported_ingredients': Classifier.ingredients, 'elapsed_ms': 10,
            'settings': load_pipeline_settings(), 'model_metadata': {'version': 'v5'},
            'detector_class_count': 214, 'limit_reached': False}


with patch('streamlit.file_uploader',side_effect=uploader), \
     patch.object(page1,'load_model',return_value=SimpleNamespace(names={0:'Banana'})), \
     patch.object(page1,'detect_image',side_effect=infer), \
     patch.object(page2,'load_model',return_value=SimpleNamespace(names={0:'Banana'})), \
     patch.object(page2,'detect_video_frame',side_effect=infer), \
     patch.object(condition_page,'load_model',return_value=SimpleNamespace(names={0:'Apple'})), \
     patch.object(condition_page,'analyze_ingredients',side_effect=condition_infer), \
     patch.object(box_editor_ui,'load_condition_model',return_value=Classifier()), \
     patch.object(box_editor_ui,'render_box_canvas',side_effect=lambda *a,**k: st.session_state.get('fixture_canvas_event')), \
     patch.object(condition_page,'load_condition_model',return_value=Classifier()):
    runpy.run_path(str(Path(__file__).resolve().parents[1]/'main.py'),run_name='__main__')

