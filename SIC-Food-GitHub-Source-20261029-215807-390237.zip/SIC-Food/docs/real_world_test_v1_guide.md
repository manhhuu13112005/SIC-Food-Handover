# Giai đoạn C — kiểm thử độc lập V5/V6 trên Windows CPU

Công cụ nghiên cứu nằm riêng trong `research/`, không được website import. Website vẫn dùng V5; không train, không sửa checkpoint, Train/Validation hoặc nhãn kiểm duyệt cũ.

## Môi trường

Dùng môi trường `sic-food` hiện có: Python, torch/torchvision, ultralytics, Pillow, numpy, matplotlib, PyYAML và IPython/Jupyter. Không thêm thư viện vẽ canvas, sklearn, scipy, imagehash hoặc ipywidgets. Hàm pHash dùng NumPy hiện có. Không có bước tải trọng số tự động: cần cả hai checkpoint và `best.pt` tại đường dẫn đang dùng trong dự án.

```powershell
cd C:\Users\ASUS\SIC-Food
conda activate sic-food
python -m notebook Real_World_Test_V1_Review.ipynb
```

Chọn kernel của môi trường `sic-food`. Nếu chưa có Notebook frontend, mở bằng JupyterLab/VS Code Jupyter đã cài. Chương trình tương tác dùng `input()` chuẩn của Jupyter; không cần widget extension. Notebook có kiểm tra CPU, thứ tự 38 lớp và preprocessing bằng loader hiện có; không gọi loader V5 của website để nạp V6. Hai model chỉ nạp một lần trong notebook.

## Quy trình thu thập và kiểm duyệt

1. Đưa ảnh **Test mới, độc lập** vào `datasets/real_world_test_v1/images/`. Không lấy ảnh từ Train/Validation hay bộ thăm dò 18 ảnh. Ghi nguồn, phiên chụp, đối tượng, ánh sáng và thiết bị để kiểm soát trùng nguồn. Không chụp nhiều ảnh gần giống một đối tượng rồi coi là các mẫu độc lập.
2. Mở notebook, chạy setup và freeze. YOLO chạy một lần với cấu hình hiện tại, CPU, NMS theo lớp, padding 0%. Mỗi run có thư mục crop PNG, SHA-256, tọa độ và nhãn YOLO gốc. V5/V6 dùng cùng byte ảnh crop. Nhãn YOLO ngoài phạm vi vẫn giữ nguyên.
3. Chạy ô `review(...)`. Ảnh gốc hiển thị trước, ảnh đánh dấu sau: AI màu đỏ, Ground Truth màu xanh. Tọa độ theo kích thước ảnh gốc đã xoay EXIF, không theo kích thước hiển thị thu nhỏ của trình duyệt.
4. `count`: nhập tổng số đối tượng thực, bao gồm đối tượng AI bỏ sót. `object`: nhập ID thủ công (`gt001`), nguyên liệu đúng, trạng thái và bbox XYXY; nhập lại cùng ID để sửa. Tên nguyên liệu không điền sẵn từ dự đoán. Có `out_of_scope` cho đối tượng ngoài 19 loại và `uncertain` nếu không đủ bằng chứng trạng thái. `delete` chỉ xóa mục GT trong bản sửa mới.
5. `boxes`: chỉ xác nhận khi **mọi** đối tượng thực đều có GT bbox chính xác. Khi không đủ tọa độ, để false; dùng `decision` duyệt lần lượt box AI thành valid/duplicate/false_positive/uncertain. Valid cần liên kết một GT ID; không cho hai box valid trỏ cùng một đối tượng. Quyết định gắn đúng run và ID box, không tái sử dụng nhầm sau khi YOLO chạy lại. Đối tượng có GT nhưng không liên kết là bỏ sót **hoặc chưa kiểm tra** nếu duyệt box chưa xong.
6. `source`: ghi xuất xứ và phiên chụp. `save` lưu nháp; mỗi thao tác nhập thành công cũng lưu nháp. `approve` nhập người duyệt và xác nhận đã kiểm tra đủ đối tượng. `next`, `prev`, `quit` để di chuyển hoặc đóng. Sửa nhãn đã duyệt cần lý do; bản cũ được giữ. Bản nháp mới làm nhãn cũ tạm ngừng tham gia đánh giá cho tới khi approve lại.
7. Chạy inference một lần và evaluate. Có thể sửa nhãn rồi evaluate lại trên cùng dự đoán: tạo snapshot đánh giá mới, không chạy lại YOLO hay ghi đè kết quả. Để mở lại notebook, đặt `RUN = Path(r'đường dẫn run đã in')`, không chạy ô freeze thêm lần nữa.
8. Chạy audit đối chiếu Train/Validation. Xem `matches.csv`, `unverified.csv`, `audit.json`; pHash Hamming <=6 chỉ tạo ứng viên cần kiểm tra bằng mắt. Không coi không có ứng viên là bằng chứng tuyệt đối không rò rỉ. Audit liệt kê phạm vi manifest, file thiếu, số ảnh đã đọc/chưa đọc và phần xuất xứ không xác minh. Không dùng Test làm Train sau khi thấy lỗi.

Một người duyệt ghi nhãn tại một thời điểm; công cụ chưa có khóa đồng thời cho nhiều Jupyter session. Nếu nhiều thành viên tham gia, chia ảnh theo nhóm và hợp nhất bằng kiểm tra thủ công thay vì cùng sửa một ảnh.

## CLI

```powershell
python scripts/evaluate_real_world.py inventory
python scripts/evaluate_real_world.py freeze
# Lưu đường dẫn run in ra; kiểm duyệt bằng notebook trước khi đánh giá.
python scripts/evaluate_real_world.py infer --run "C:\Users\ASUS\SIC-Food\reports\real_world_test_v1\runs\RUN_ID"
python scripts/evaluate_real_world.py evaluate --run "C:\Users\ASUS\SIC-Food\reports\real_world_test_v1\runs\RUN_ID"
python scripts/evaluate_real_world.py audit
# Chỉ kiểm tra kỹ thuật; không tính accuracy:
python scripts/evaluate_real_world.py smoke
```

`run` gộp freeze/infer/evaluate cho ảnh có nhãn đã duyệt hoặc tạo báo cáo thiếu dữ liệu. `manual-freeze` tạo run crop từ GT bbox đầy đủ để đánh giá có hỗ trợ thủ công; sau đó infer/evaluate bằng đường dẫn run mới. Số liệu manual_assisted luôn tách khỏi fully_automatic. Tham số `--data`, `--output` đổi thư mục nghiên cứu; không trỏ chúng vào Train/Validation. `audit --max-references 100` chỉ là kiểm tra sơ bộ có giới hạn, không phải audit đầy đủ.

## Cách đọc báo cáo

- YOLO: tổng đối tượng, số box, nhãn ngoài phạm vi, matched/missed hoặc chưa xác minh, nhãn đúng/sai. Full GT bbox cho phép IoU .5 Precision/Recall và AP101 tại .50:.05:.95. Có localization AP không phụ thuộc nhãn và class-aware mAP riêng; không có crowd/ignore/area như bộ đánh giá COCO đầy đủ. Class-aware mAP trung bình trên các lớp GT có support. Box trùng là ứng viên IoU >=.5 với một GT đã được match, cần con người xác nhận. Duyệt bằng số lượng không sinh mAP.
- EfficientNet: chỉ crop được match một-một với GT trên ảnh đã duyệt; GT ngoài phạm vi bị loại khỏi chỉ số classifier. Ingredient accuracy giữ cả mẫu uncertain; condition accuracy chỉ mẫu biết trạng thái **và đúng nguyên liệu**; joint accuracy loại uncertain. Chẩn đoán classifier có thể bao gồm crop có nhãn YOLO sai/ngoài phạm vi; đây không phải kết quả tự động website.
- Pipeline: chỉ nhãn YOLO thuộc phạm vi mới đủ điều kiện tự động phân loại, dù công cụ chẩn đoán có chạy cả hai model trên crop ngoài phạm vi. Mẫu số ingredient là toàn bộ đối tượng GT kể cả bỏ sót; joint loại uncertain và GT ngoài phạm vi, ghi số bị loại. Đây là tỷ lệ đối tượng đúng/recall, không thay thế detection precision. Duyệt box chưa đủ thì pipeline là cận dưới tạm thời, báo rõ missed OR unverified.
- Macro F1 cố định 19 nguyên liệu /38 lớp kết hợp, zero-division=0; có thêm supported-only macro F1. Không diễn giải lớp có support=0 là model thất bại. Ma trận CSV có hàng là GT, cột dự đoán. Không có mẫu thì accuracy=null, không phải 0% hoặc 100%; không vẽ biểu đồ như thể đã đo được.
- Các bảng: `accuracy_by_ingredient.csv`, `meat_seafood.csv`, `*_classes.csv`, `*_confusion.csv`, `reviewed_crop_predictions.csv`, `errors_by_ingredient.csv`, `v5_right_v6_wrong.csv`, `v6_right_v5_wrong.csv`; ảnh minh họa lỗi trong `error_examples/`; biểu đồ khi có nhãn; `annotation_snapshot.json`, `summary.json`, `report.md` ghi phiên bản và mẫu số.

Không suy ra an toàn thực phẩm từ ảnh. Không chọn V6 chỉ vì train sau. Với Test trống/ít mẫu hoặc chưa kiểm tra rò rỉ, chưa có cơ sở chọn model nền cho Train 4. Ưu tiên thu thập cân bằng 19 nguyên liệu ×2 trạng thái, đặc biệt nhóm thịt/hải sản, nhiều phiên chụp và cảnh nhiều đối tượng. Khi có dữ liệu đủ, quyết định cải thiện detector dựa trên bỏ sót/trùng, classifier dựa trên crop hợp lệ; chọn nền bằng so sánh cặp trên chính ảnh Test và kiểm tra khả năng giữ lớp cũ. Chỉ đề xuất, chưa train.

Tham chiếu định nghĩa IoU/101 recall points và các khác biệt về area/crowd/maxDets: [COCO evaluation source](https://github.com/cocodataset/cocoapi/blob/master/PythonAPI/pycocotools/cocoeval.py). Công cụ này không tự nhận tương đương toàn bộ benchmark COCO.

GT `out_of_scope` chỉ xác nhận đối tượng ngoài 19 nguyên liệu, không xác nhận nhãn trong toàn bộ 214 lớp YOLO. Đối tượng đó vẫn tính localization và mẫu số pipeline ingredient; được loại khỏi class-aware AP và mẫu số đúng/sai nhãn YOLO, ghi rõ số chưa xác minh. Muốn đánh giá tất cả 214 lớp phải bổ sung schema GT phân loại tương ứng trong một nghiên cứu khác.

## Kiểm thử kỹ thuật

```powershell
python -m unittest discover -s tests -p "test_*.py" -v
```

Test mới dùng dữ liệu tổng hợp tạm thời để kiểm tra công thức, one-to-one, trùng/bỏ sót, uncertain, tách tự động/thủ công, lưu tiến độ, chống ghi đè và kiểm tra rò rỉ. Các test này không đo khả năng tổng quát của model.
