"""SIC-Food V5: stage 28/29/30 audit, sampled human review, manual broccoli indexing.

Commands:
 python sic_food_v5_next_steps.py audit --root C:\\Users\\ASUS\\SIC-Food
 python sic_food_v5_next_steps.py review --root C:\\Users\\ASUS\\SIC-Food
 python sic_food_v5_next_steps.py broccoli --root C:\\Users\\ASUS\\SIC-Food
 python sic_food_v5_next_steps.py refresh --root C:\\Users\\ASUS\\SIC-Food

Does not train, change/checkpoint models, remove images, auto-approve labels, or repartition splits.
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import random
from collections import Counter, defaultdict
from pathlib import Path

import pandas as pd
from PIL import Image, ImageOps

CLASSES = ('broccoli__normal_appearance','broccoli__visible_defect')
EXT = {'.jpg','.jpeg','.png','.webp','.bmp'}


def paths(root):
    output=root/'datasets'/'efficientnet_v5_40'
    reports=root/'datasets'/'external_v5'/'reports'
    review=root/'datasets'/'external_v5'/'review'
    output.mkdir(parents=True,exist_ok=True)
    reports.mkdir(parents=True,exist_ok=True)
    review.mkdir(parents=True,exist_ok=True)
    return output,reports,review


def save_no_overwrite(df, location):
    if location.exists():
        print('PRESERVED (already exists):',location)
        return
    df.to_csv(location,index=False,encoding='utf-8-sig')
    print('CREATED:',location)


def read_manifest(root):
    output,_,_=paths(root)
    location=output/'v5_candidate_manifest_stage27.csv'
    if not location.exists():
        raise FileNotFoundError(f'Missing Stage27 manifest: {location}')
    df=pd.read_csv(location,dtype={'path':str,'target_class':str,'origin':str,'image_group':str})
    needed={'path','target_class','origin','original_split','image_group','review_status'}
    if not needed.issubset(df.columns):
        raise ValueError('Stage27 manifest lacks: '+str(needed-set(df.columns)))
    return df


def audit(root):
    output,reports,_=paths(root)
    df=read_manifest(root)
    classes=json.loads((output/'class_names_40.json').read_text(encoding='utf-8'))
    counts=df['target_class'].value_counts().reindex(classes,fill_value=0)
    missing=counts[counts==0]
    print('=== V5 STAGE 28 DATA AUDIT ===')
    print('Rows:',len(df),'Labels:',int((counts>0).sum()),'/',len(classes))
    print('Missing labels:',list(missing.index))
    print('Missing file paths:',sum(not Path(p).is_file() for p in df['path'].astype(str)))
    print('Repeated paths:',df['path'].duplicated().sum())
    print('\nSource counts:')
    print(df['origin'].value_counts().to_string())
    print('\nReview-status counts (not proof of approval):')
    print(df['review_status'].fillna('missing').value_counts().to_string())
    print('\nProvisional image group counts per source:')
    print(df.groupby('origin')['image_group'].nunique().to_string())
    print('\nOriginal source splits:')
    print(pd.crosstab(df['origin'],df['original_split']).to_string())
    print('\nNOTICE: legacy_37 image_group was assigned from file path, not verified original capture session.')
    print('NOTICE: cabbage and LOCBEEF/BrinjalFruitX use coarse provisional source groups.')
    print('NOTICE: Shrimp original test contains fresh but no spoiled; DO NOT reuse splits blindly.')
    protected=reports/'v5_locbeef_protected_test_index.csv'
    if protected.exists():
        idx=pd.read_csv(protected)
        print('LOCBEEF protected test index:',len(idx))
    else:
        print('WARNING: LOCBEEF protected test index not found.')
    if 'locbeef' in set(df['origin']):
        leaked=df[(df['origin']=='locbeef') & (df['original_split'].str.lower()=='test')]
        print('LOCBEEF test included in candidates (must be zero):',len(leaked))
    hash_path=output/'v5_crop_sha256.csv'
    if hash_path.exists():
        hashed=pd.read_csv(hash_path)
        if {'sha256','target_class'}.issubset(hashed.columns):
            print('V5 crop rows in exact duplicate groups:',int(hashed.duplicated('sha256',keep=False).sum()))
            print('Hash groups with conflicting labels:',int((hashed.groupby('sha256')['target_class'].nunique()>1).sum()))
    readiness=pd.DataFrame({'target_class':classes,'candidate_count':counts.values})
    readiness.to_csv(reports/'v5_stage28_readiness_snapshot.csv',index=False,encoding='utf-8-sig')
    print('Snapshot:',reports/'v5_stage28_readiness_snapshot.csv')
    print('READINESS: NOT cleared for 40-class training, evaluation splits are not approved.')


def review(root,per_class=25):
    _,reports,review_dir=paths(root)
    required=(
        (reports/'v5_large_import_candidates.csv','large'),
        (reports/'v5_cabbage_candidates.csv','cabbage'),
    )
    rows=[]
    rng=random.Random(2026)
    for location,which in required:
        if not location.exists():
            print('MISSING:',location);continue
        df=pd.read_csv(location,keep_default_na=False)
        if which=='large':
            necessary={'path','proposed_target_class','source','source_split'}
            if not necessary.issubset(df.columns):
                raise ValueError(f'Large import schema mismatch: {necessary-set(df.columns)}')
            df=df[df['source_split'].str.lower()!='test'].copy()
            df['target_class']=df['proposed_target_class']
        else:
            if not {'path','target_class','source'}.issubset(df.columns):
                raise ValueError('Cabbage schema mismatch')
        for (source,cls),chunk in df.groupby(['source','target_class']):
            # Random examples from the stored candidate labels, not a pre-approved training set.
            available=[str(p) for p in chunk['path'] if Path(str(p)).is_file()]
            rng.shuffle(available)
            for p in available[:per_class]:
                rows.append({'source':source,'target_class':cls,'crop_path':p,
                             'review_status':'pending','review_note':'',
                             'review_question':'Is actual ingredient/visible status correct? Check original source.'})
    report=review_dir/'v5_large_cabbage_manual_review.csv'
    save_no_overwrite(pd.DataFrame(rows,columns=['source','target_class','crop_path','review_status','review_note','review_question']),report)
    print('New review samples (if not already generated):',len(rows))
    print('Review file:',report)
    print('This is a SAMPLE audit, not wholesale label approval.')


def broccoli(root):
    _,reports,_=paths(root)
    base=root/'datasets'/'external_v5'/'manual_broccoli'
    records=[]; sha_labels=defaultdict(set); bad=[]; groups=Counter()
    for label in CLASSES:
        folder=base/label
        folder.mkdir(parents=True,exist_ok=True)
        files=sorted(p for p in folder.rglob('*') if p.is_file() and p.suffix.lower() in EXT)
        for file in files:
            try:
                with Image.open(file) as im:
                    w,h=im.size
                    if min(w,h)<64: raise ValueError('image smaller than 64 px on one side')
                    im.verify()
                checksum=hashlib.sha256()
                with file.open('rb') as f:
                    for block in iter(lambda:f.read(1024*1024),b''):
                        checksum.update(block)
                relative=file.relative_to(folder)
                # A direct file has UNKNOWN photo session; all such files are one conservative group.
                session=relative.parts[0] if len(relative.parts)>1 else 'unverified_direct_files'
                # Prefix by session but NOT class, so sibling states from the same session remain grouped.
                source_group=f'manual_broccoli::{session}'
                groups[source_group]+=1
                digest=checksum.hexdigest()
                sha_labels[digest].add(label)
                records.append({'path':str(file),'target_class':label,'origin':'manual_broccoli',
                                'original_split':'unassigned','image_group':source_group,
                                'source_file':str(relative).replace('\\','/'),
                                'sha256':digest,'review_status':'pending','review_note':'needs photo & label review'})
            except Exception as e:
                bad.append({'path':str(file),'error':str(e)})
    target=reports/'v5_manual_broccoli_candidates.csv'
    pd.DataFrame(records,columns=['path','target_class','origin','original_split','image_group','source_file','sha256','review_status','review_note']).to_csv(target,index=False,encoding='utf-8-sig')
    pd.DataFrame(bad,columns=['path','error']).to_csv(reports/'v5_manual_broccoli_errors.csv',index=False,encoding='utf-8-sig')
    print('=== BROCCOLI INVENTORY ===')
    print('Good-format image files:',len(records),'Corrupt/small:',len(bad))
    print('Counts:',dict(Counter(r['target_class'] for r in records)))
    print('Unverified source groups:',dict(groups))
    print('SHA256 conflicting-label groups:',sum(len(labels)>1 for labels in sha_labels.values()))
    print('Candidate manifest:',target)
    print('No broccoli source photo is automatically approved. No final train/val/test has been created.')


def refresh(root):
    output,reports,_=paths(root)
    df=read_manifest(root)
    extra=reports/'v5_manual_broccoli_candidates.csv'
    if extra.exists():
        b=pd.read_csv(extra,keep_default_na=False)
        if len(b):
            rows=b[['path','target_class','origin','original_split','image_group','review_status']].copy()
            rows['exists']=rows['path'].map(lambda p:Path(p).is_file())
            rows['split_assignment']='unassigned'
            df=pd.concat([df,rows],ignore_index=True)
    df=df.drop_duplicates(subset=['path'],keep='first')
    classes=json.loads((output/'class_names_40.json').read_text(encoding='utf-8'))
    counts=df['target_class'].value_counts().reindex(classes,fill_value=0)
    target=output/'v5_candidate_manifest_stage30_with_broccoli.csv'
    df.to_csv(target,index=False,encoding='utf-8-sig')
    print('Candidate rows:',len(df),'Labels with candidates:',int((counts>0).sum()),'/',len(classes))
    print('Missing classes:',list(counts[counts==0].index))
    print('Pending / unverified labels:',int(df['review_status'].isin(['pending','legacy_unverified']).sum()))
    print('Saved (NOT final Train):',target)
    print('Do NOT train on this manifest as-is; original test splits and group leakage unresolved.')


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode',choices=['audit','review','broccoli','refresh'])
    parser.add_argument('--root',type=Path,default=Path(r'C:\Users\ASUS\SIC-Food'))
    parser.add_argument('--per-class',type=int,default=25)
    args=parser.parse_args()
    root=args.root.resolve()
    if args.mode=='audit':audit(root)
    elif args.mode=='review':review(root,max(1,min(args.per_class,100)))
    elif args.mode=='broccoli':broccoli(root)
    elif args.mode=='refresh':refresh(root)

if __name__=='__main__':main()
