"""Module 2: a single automatic detector/crop/V5 workflow with review overlays."""
import json
import logging

import streamlit as st
from app_state import upload, reset_results, clear_input, save_condition_edit
from model_loader import load_model, load_condition_model
from image_service import decode_image
from ingredient_pipeline import analyze_ingredients, annotate_objects, effective_result
from ingredient_pipeline import summarize_objects
from box_review import start_review, export_review
from box_editor_ui import render_box_tools
from ui_components import food_name, APPEARANCES, page_intro, empty_state

LOG = logging.getLogger(__name__)
STATES = {**APPEARANCES, 'uncertain': 'Chưa xác định'}
REVIEW = {'pending': 'Chưa xác nhận', 'confirmed': 'Đã xác nhận', 'needs_review': 'Cần xem lại'}
STATUS = {'classified': 'Đã phân loại · chưa xác nhận', 'low_confidence': 'Cần kiểm tra · điểm thấp',
          'disagreement': 'Cần kiểm tra · bất đồng nguyên liệu', 'error': 'Cần kiểm tra · lỗi crop/suy luận',
          'unsupported': 'Ngoài phạm vi hỗ trợ'}


def _edit(object_id, field, label, options, default, format_func):
    values = st.session_state.get('cond_edits', {}).get(str(object_id), {})
    value = values.get(field, default)
    if value not in options:
        value = options[0]
    key = f'cond_field_{object_id}_{field}'
    return st.selectbox(label, options, index=options.index(value), format_func=format_func,
                        key=key, on_change=save_condition_edit, args=(str(object_id), field, key))


def render_object(row, image, ingredients):
    object_id = row['object_id']
    with st.container(border=True):
        preview, detail = st.columns([1, 2], gap='medium')
        with preview:
            if row['crop_xyxy']:
                crop = image.crop(row['crop_xyxy'])
                crop.thumbnail((384, 384))
                st.image(crop, caption=f'Crop đối tượng {object_id:02d}', width='stretch')
            else:
                st.caption('Không có crop hợp lệ.')
        with detail:
            name = food_name(row['ingredient']) if row['ingredient'] else (row['yolo_label'] or 'Vùng thủ công')
            st.subheader(f'{object_id:02d} · {name}')
            source = 'Box thêm thủ công' if row.get('origin') == 'manual' else 'Box YOLO đã sửa vùng' if row.get('geometry_edited') else 'Box YOLO gốc'
            st.caption(source)
            if row['yolo_label'] is not None:
                st.caption(f'YOLO gốc: {row["yolo_label"]} · điểm {row["yolo_score"]:.1%}')
            else:
                st.caption('Không có nhãn/điểm YOLO cho box thêm thủ công.')
            if row.get('manual_confirmation'):
                st.caption('Người dùng xác nhận: ' + food_name(row['manual_confirmation']['ingredient']))
            if row['status'] == 'classified':
                st.caption(STATUS[row['status']])
            elif row['status'] == 'unsupported':
                st.info(STATUS[row['status']])
                st.caption('Muốn chạy V5 cho vùng này: mở Quản lý vùng nguyên liệu, chọn box, chọn nguyên liệu và xác nhận.')
            else:
                st.warning(STATUS[row['status']])
            if row['ingredient']:
                st.write(f'**Dự đoán V5 của crop hiện tại:** {food_name(row["ingredient"])} · {STATES[row["condition"]]}')
                first, second = st.columns(2)
                first.metric('Điểm nguyên liệu', f'{row["ingredient_score"]:.1%}')
                second.metric('Điểm trạng thái có điều kiện', f'{row["condition_score"]:.1%}')
            for warning in row['warnings']:
                st.caption(warning)
            if row['top3']:
                with st.expander(f'Top-3 nhãn AI · đối tượng {object_id:02d}'):
                    for candidate in row['top3']:
                        st.progress(float(candidate['confidence']),
                            text=f'{food_name(candidate["ingredient"])} · {STATES[candidate["appearance"]]} · {candidate["confidence"]:.1%}')
        with st.expander(f'Kiểm tra và chỉnh sửa · đối tượng {object_id:02d}'):
            st.caption('Bản sửa nhãn được lưu riêng; dự đoán V5 của crop hiện tại được giữ nguyên. Kết quả YOLO ban đầu nằm trong JSON.')
            _edit(object_id, 'ingredient', 'Tên nguyên liệu', ['uncertain'] + ingredients,
                  row['ingredient'] or 'uncertain',
                  lambda name: 'Chưa xác định' if name == 'uncertain' else food_name(name))
            _edit(object_id, 'condition', 'Trạng thái bề ngoài',
                  ['uncertain', 'normal_appearance', 'visible_defect'], row['condition'] or 'uncertain', STATES.get)
            _edit(object_id, 'review', 'Xác nhận kết quả', list(REVIEW), 'pending', REVIEW.get)
        value = effective_result(row, st.session_state.get('cond_edits', {}).get(str(object_id)))
        if value['source'] == 'user':
            st.caption(f'Bản người dùng: {food_name(value["ingredient"]) if value["ingredient"] != "uncertain" else "Chưa xác định"}'
                       f' · {STATES[value["condition"]]} · {REVIEW[value["review"]]}')


def app():
    page_intro('02 / QUAN SÁT TỪNG ĐỐI TƯỢNG', 'Nhận diện nguyên liệu & trạng thái thực phẩm',
        'Sử dụng YOLO để phát hiện từng nguyên liệu và EfficientNet-B0 để đánh giá tên nguyên liệu, dấu hiệu bề ngoài.')
    st.caption('YOLO Detection → Crop → EfficientNet-B0 V5 · 19 nguyên liệu / 38 nhãn · CPU')
    left, right = st.columns([1, 1.3], gap='large')
    with left:
        with st.container(border=True):
            st.subheader('Tải ảnh nguyên liệu')
            payload = upload('cond', 'Chọn ảnh JPG, JPEG hoặc PNG', ['jpg', 'jpeg', 'png'])
            image = None
            if payload:
                try:
                    image = decode_image(payload)
                    st.image(image, caption=st.session_state.get('cond_filename'), width='stretch')
                except ValueError as error:
                    reset_results('cond')
                    st.error(str(error))
            else:
                empty_state('Một ảnh, nhiều nguyên liệu', 'Chọn ảnh rõ nét. Tối đa 20 MB / 25 triệu pixel.')
            st.button('Reset ảnh và kết quả', on_click=clear_input, args=('cond',), key='cond_clear')
            if st.button('Phân tích bằng AI', type='primary', disabled=image is None, width='stretch'):
                reset_results('cond')
                try:
                    with st.spinner('Đang phát hiện và phân tích từng nguyên liệu…'):
                        detector = load_model()
                        classifier = load_condition_model()
                        result = analyze_ingredients(image, detector, classifier)
                    st.session_state['cond_result'] = result
                except Exception as error:
                    LOG.exception('Ingredient pipeline failed')
                    if isinstance(error, (RuntimeError, ImportError)):
                        st.error(f'Không chạy được pipeline: {error}')
                    else:
                        st.error('Không phân tích được ảnh. Kiểm tra cấu hình và checkpoint V5; xem log để biết chi tiết.')
        st.caption('Xanh: bề ngoài bình thường · Đỏ: có dấu hiệu bất thường · Vàng: cần kiểm tra / ngoài phạm vi.')
        st.caption('Các điểm dự đoán chưa hiệu chỉnh; ngưỡng cảnh báo chỉ là tham số thử nghiệm.')
    result = st.session_state.get('cond_result')
    workspace = None
    objects = []
    if result and image is not None:
        if 'cond_workspace' not in st.session_state:
            st.session_state['cond_workspace'] = start_review(result, st.session_state.get('cond_token'))
        workspace = st.session_state['cond_workspace']
        objects = workspace['objects']
    with right:
        if result and image is not None:
            edits = st.session_state.get('cond_edits', {})
            st.subheader('Đối tượng trong ảnh')
            if objects:
                st.image(annotate_objects(image, objects, edits),
                         caption='Số trên bounding box khớp với từng thẻ kết quả bên dưới', width='stretch')
            else:
                st.info('Chưa phát hiện được nguyên liệu. Thử ảnh rõ hơn hoặc góc chụp khác.')
            if result['limit_reached']:
                st.warning(f'Đã chạm giới hạn {result["settings"]["max_detections"]} box mỗi ảnh. Có thể còn đối tượng chưa được xử lý.')
            st.caption(f'CPU · {result["elapsed_ms"]/1000:.2f} giây · V5 · không tự ước lượng số đối tượng bỏ sót')
        else:
            empty_state('Kết quả từng nguyên liệu', 'Nhấn Phân tích bằng AI để xem bounding box và đánh giá từng đối tượng.')
    if result and image is not None:
        render_box_tools(image, workspace)
        st.subheader('Tổng quan vùng đang giữ')
        labels = [('detected', 'Box YOLO'), ('supported', 'Trong phạm vi'), ('classified', 'Đã phân loại'),
                  ('visible_defect', 'Dự đoán bất thường'), ('needs_review', 'Cần kiểm tra'), ('unsupported', 'Ngoài phạm vi')]
        for column, (key, label) in zip(st.columns(6), labels):
            column.metric('Vùng đang giữ' if key == 'detected' else label, summarize_objects(objects)[key])
        st.caption(f'YOLO ban đầu: {len(result["objects"])} box · Vùng đang giữ: {len(objects)}. '
                   'Tổng quan theo crop hiện tại, gồm dự đoán tạm. Bản sửa nhãn được ghi riêng trên từng thẻ.')
        for row in objects:
            render_object(row, image, result['supported_ingredients'])
        exported = export_review(workspace,st.session_state.get('cond_edits', {}))
        st.download_button('Tải kết quả và bản sửa (JSON)', json.dumps(exported, ensure_ascii=False, indent=2, allow_nan=False),
                           'nguyen_lieu_v5.json', 'application/json', key='cond_export')
        with st.expander('Phạm vi và giới hạn'):
            st.write(', '.join(food_name(name) for name in result['supported_ingredients']))
            st.caption('Món ăn đã chế biến hoặc nhãn YOLO ngoài danh sách sẽ không được ép phân loại. '
                       'YOLO có thể tạo box trùng hoặc bỏ sót; không tự gộp các đối tượng. '
                       'Có thể thêm vùng thủ công khi bị bỏ sót, hoặc xác nhận nguyên liệu cho nhãn YOLO sai. '
                       'Không có chế độ phân loại tự động toàn ảnh.')
    st.info('Kết quả phân loại trạng thái dựa trên đặc điểm quan sát được từ hình ảnh, '
            'không thay thế kiểm định chất lượng hoặc an toàn thực phẩm.')
