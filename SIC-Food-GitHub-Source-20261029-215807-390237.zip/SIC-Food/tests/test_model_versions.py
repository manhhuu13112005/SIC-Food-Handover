"""Model checkpoint contract regression tests; generate synthetic weights, never use user datasets."""
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch
from PIL import Image
from torchvision.models import efficientnet_b0
from condition_service import load_classifier_file


INGREDIENTS = [
    'apple', 'banana', 'bell_pepper', 'beef', 'cabbage', 'carrot', 'chicken',
    'cucumber', 'eggplant', 'fish', 'lettuce', 'mango', 'onion', 'orange',
    'pork', 'potato', 'shrimp', 'strawberry', 'tomato'
]
CLASSES_38 = [f'{i}__{state}' for i in INGREDIENTS
              for state in ('normal_appearance', 'visible_defect')]


class ModelVersionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.previous_threads = torch.get_num_threads()
        torch.set_num_threads(1)
        cls.workdir = tempfile.TemporaryDirectory()

    @classmethod
    def tearDownClass(cls):
        cls.workdir.cleanup()
        torch.set_num_threads(cls.previous_threads)

    @classmethod
    def make_checkpoint(cls, version, classes=CLASSES_38):
        model = efficientnet_b0(weights=None)
        model.classifier[1] = torch.nn.Linear(model.classifier[1].in_features, len(classes))
        metadata = {
            'v5': 'provisional_head_training',
            'v6': 'v6_head_finetuning',
            'legacy37': 'prototype_frozen_backbone'
        }
        package = {
            'model_state_dict': model.state_dict(),
            'class_names': list(classes),
            'num_classes': len(classes),
            'training_type': metadata[version],
        }
        if version == 'legacy37':
            package['pretrained_weights'] = 'IMAGENET1K_V1'
        file = Path(cls.workdir.name) / f'{version}.pth'
        torch.save(package, file)
        return file

    def test_v5_load_preprocess_and_predict(self):
        file = self.make_checkpoint('v5')
        classifier = load_classifier_file(file, expected_classes=38, expected_version='v5')
        self.assertEqual(len(classifier.class_names), 38)
        self.assertEqual(classifier.metadata['ingredient_count'], 19)
        self.assertEqual(classifier.metadata['version'], 'v5')
        self.assertIn('Resize((224,224))', classifier.metadata['preprocessing'])
        self.assertFalse(classifier.model.training)
        self.assertEqual(classifier.model.classifier[1].out_features, 38)
        self.assertEqual(classifier.transform(Image.new('RGB', (300, 100))).shape, (3, 224, 224))
        result = classifier.predict(Image.new('RGB', (300, 100)))
        self.assertEqual(len(result['probabilities']), 38)
        self.assertEqual(len(result['top3']), 3)

    def test_v6_load_and_preprocess(self):
        file = self.make_checkpoint('v6')
        classifier = load_classifier_file(file, expected_classes=38, expected_version='v6')
        self.assertEqual(classifier.metadata['version'], 'v6')
        self.assertEqual(classifier.model.classifier[1].out_features, 38)
        self.assertIn('Resize((224,224))', classifier.metadata['preprocessing'])

    def test_legacy37_backward_compatibility(self):
        classes = CLASSES_38[:-1]
        file = self.make_checkpoint('legacy37', classes)
        classifier = load_classifier_file(file, expected_classes=37, expected_version='legacy37')
        self.assertEqual(classifier.model.classifier[1].out_features, 37)
        self.assertIn('CenterCrop224', classifier.metadata['preprocessing'])

    def test_version_mismatch_is_rejected(self):
        file = self.make_checkpoint('v5')
        with self.assertRaisesRegex(ValueError, 'Chọn model v6'):
            load_classifier_file(file, expected_classes=38, expected_version='v6')
        with self.assertRaisesRegex(ValueError, '37 lớp'):
            load_classifier_file(file, expected_classes=37)

    def test_original_legacy_checkpoint_format(self):
        model = efficientnet_b0(weights=None)
        model.classifier[1] = torch.nn.Linear(model.classifier[1].in_features, 2)
        file = Path(self.workdir.name) / 'legacy_original.pth'
        torch.save({
            'architecture': 'efficientnet_b0',
            'image_size': 224,
            'state_dict': model.state_dict(),
            'class_names': ['tomato_fresh', 'tomato_defect'],
        }, file)
        classifier = load_classifier_file(file)
        self.assertEqual(classifier.metadata['version'], 'legacy_format')
        self.assertEqual(classifier.model.classifier[1].out_features, 2)

    def test_wrong_training_contract_is_rejected(self):
        file = self.make_checkpoint('v5')
        package = torch.load(file, map_location='cpu', weights_only=True)
        package['training_type'] = 'unknown'
        torch.save(package, file)
        with self.assertRaisesRegex(ValueError, 'training_type'):
            load_classifier_file(file)


if __name__ == '__main__':
    unittest.main()
