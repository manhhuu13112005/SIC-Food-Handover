"""Independent, append-only Test evaluation. No training or website mutations."""
from __future__ import annotations
import csv
import hashlib
import json
import math
import uuid
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from PIL import Image, ImageOps, ImageDraw
from .evaluation_metrics import classifier_metrics, detection_metrics, match_boxes, ratio, iou

PROJECT = Path(__file__).resolve().parents[1]
STATES = ('normal_appearance', 'visible_defect', 'uncertain')
EXTENSIONS = {'.jpg', '.jpeg', '.png', '.webp', '.bmp', '.tif', '.tiff'}
WEIGHTS = {'v5': 'models/efficientnet_v5_38/efficientnet_b0_38_prototype_head.pth',
           'v6': 'models/efficientnet_v6_38/efficientnet_b0_38_v6_head.pth'}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''):
            h.update(chunk)
    return h.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def write_json(path, data):
    """Exclusive creation: a rerun cannot replace a snapshot or reviewed labels."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False)


def write_csv(path, rows, fields):
    with Path(path).open('x', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)


def identifier():
    return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ') + '_' + uuid.uuid4().hex[:8]


def image_rgb(path):
    with Image.open(path) as image:
        return ImageOps.exif_transpose(image).convert('RGB')


def contained(root, relative):
    path = (Path(root) / relative).resolve()
    if not path.is_relative_to(Path(root).resolve()):
        raise ValueError('Path escapes data directory')
    return path


def inventory(data):
    root = Path(data) / 'images'
    root.mkdir(parents=True, exist_ok=True)
    rows, errors = [], []
    for path in sorted(root.rglob('*')):
        if path.suffix.lower() not in EXTENSIONS or not path.is_file():
            continue
        try:
            relative = path.relative_to(root).as_posix()
            contained(root, relative)
            img = image_rgb(path)
            sha = digest(path)
            rows.append(dict(image_id=hashlib.sha256(relative.encode()).hexdigest()[:16] + '_' + sha[:16],
                             path=relative, sha256=sha, pixel_sha256=hashlib.sha256(img.tobytes()+str(img.size).encode()).hexdigest(),
                             width=img.width, height=img.height))
        except Exception as e:
            errors.append(dict(path=str(path), error=str(e)))
    return dict(images=rows, errors=errors)


def load_models(project=PROJECT):
    import torch
    from condition_service import load_classifier_file
    torch.set_num_threads(min(4, torch.get_num_threads()))
    models = {v: load_classifier_file(Path(project)/p, expected_classes=38, expected_version=v)
              for v, p in WEIGHTS.items()}
    if list(models['v5'].class_names) != list(models['v6'].class_names):
        raise ValueError('V5/V6 class order differs; comparison stopped')
    if set(models['v5'].ingredient_groups()) != set(models['v6'].ingredient_groups()):
        raise ValueError('Ingredient contracts differ')
    if repr(models['v5'].transform) != repr(models['v6'].transform):
        raise ValueError('Preprocessing differs; shared-crop comparison stopped')
    return models


def model_contract(models, project=PROJECT):
    return {v: dict(metadata=m.metadata, class_names=m.class_names,
                    checkpoint_sha256=digest(Path(project)/WEIGHTS[v]),
                    transform=repr(m.transform), architecture=type(m.model).__name__)
            for v, m in models.items()}


def latest_annotation(data, image_id, reviewed_only=False):
    paths = sorted((Path(data)/'annotations'/image_id).glob('*.json'))
    if not paths:
        return None
    # A newer draft correction must not silently leave an older reviewed annotation active.
    record = read_json(paths[-1])
    return record if not reviewed_only or record['status'] == 'reviewed' else None


def validate_annotation(record, image, ingredients):
    if record['image_id'] != image['image_id'] or record['image_sha256'] != image['sha256']:
        raise ValueError('Annotation belongs to different image content')
    if record.get('status') not in ('draft', 'reviewed'):
        raise ValueError('Invalid status')
    ids = set()
    for obj in record.get('objects', []):
        if not obj['id'] or obj['id'] in ids:
            raise ValueError('Duplicate/empty ground truth id')
        ids.add(obj['id'])
        if obj.get('ingredient') not in [*ingredients, 'out_of_scope'] or obj.get('condition') not in STATES:
            raise ValueError('Ground truth must be entered manually using supported labels')
        box = obj.get('bbox')
        if box is not None:
            if len(box) != 4 or not all(isinstance(x, (int, float)) and math.isfinite(x) for x in box):
                raise ValueError('Invalid bbox')
            x1,y1,x2,y2 = box
            if not (0 <= x1 < x2 <= image['width'] and 0 <= y1 < y2 <= image['height']):
                raise ValueError('Bounding box outside image or empty')
        elif record.get('bbox_complete'):
            raise ValueError('Complete bbox annotation requires every object box')
    if record['status'] == 'reviewed':
        if not record.get('reviewer', '').strip():
            raise ValueError('Reviewer required')
        if type(record.get('actual_count')) is not int or record['actual_count'] < 0 or record['actual_count'] != len(ids):
            raise ValueError('Actual count must equal individually labeled object count')
    valid_targets = set()
    for item in record.get('detection_reviews', []):
        if item['decision'] not in ('valid', 'duplicate', 'false_positive', 'uncertain'):
            raise ValueError('Invalid detection review')
        if item['decision'] == 'valid':
            key = (item['run_id'], item['gt_id'])
            if item['gt_id'] not in ids or key in valid_targets:
                raise ValueError('Each ground truth object may match only one valid prediction per run')
            valid_targets.add(key)
    keys = [(r['run_id'], r['detection_id']) for r in record.get('detection_reviews', [])]
    if len(keys) != len(set(keys)):
        raise ValueError('Duplicate prediction review')


def save_annotation(data, record, image, ingredients, correction_reason=''):
    validate_annotation(record, image, ingredients)
    previous = latest_annotation(data, image['image_id'])
    if previous and previous['status'] == 'reviewed' and not correction_reason.strip():
        raise ValueError('Explicit correction reason required to revise a reviewed annotation')
    # Windows wall clock can return the same timestamp for consecutive saves.
    # A sequence prefix keeps the latest draft deterministic, regardless of UUID sorting.
    revision = f"{len(list((Path(data)/'annotations'/image['image_id']).glob('*.json')))+1:08d}_" + identifier()
    saved = dict(record, revision=revision, previous_revision=previous['revision'] if previous else None,
                 correction_reason=correction_reason)
    write_json(Path(data)/'annotations'/image['image_id']/(revision+'.json'), saved)
    return saved


def freeze(data, output, ingredients, *, project=PROJECT, manual=False, detector=None):
    """Run detector exactly once per image, or freeze reviewed manual boxes separately."""
    from ingredient_pipeline import crop_bounds, supported_ingredient
    inv = inventory(data)
    if inv['errors']:
        raise ValueError(f"Unreadable images: {inv['errors']}")
    settings = read_json(Path(project)/'config/ingredient_pipeline.json')
    if detector is None and not manual and inv['images']:
        from ultralytics import YOLO
        from detection_service import detect_ingredients
        model = YOLO(str(Path(project)/'best.pt'))
        if model.task != 'detect':
            raise ValueError('YOLO checkpoint is not a detector')
        detector = lambda img: detect_ingredients(model, img, **{k: settings[k] for k in
                     ('confidence','image_size','iou','agnostic_nms','max_detections')})
    run = Path(output)/'runs'/identifier()
    (run/'crops').mkdir(parents=True, exist_ok=False)
    crops, annotations = [], {}
    for row in inv['images']:
        image = image_rgb(contained(Path(data)/'images', row['path']))
        annotation = latest_annotation(data, row['image_id'], True)
        if manual:
            if not annotation or not annotation.get('bbox_complete'):
                continue
            validate_annotation(annotation, row, ingredients)
            annotations[row['image_id']] = annotation
            detections = [dict(bbox=o['bbox'], original_label='', confidence=1., gt_id=o['id']) for o in annotation['objects']]
        else:
            detections = sorted(detector(image), key=lambda d: (tuple(d['bbox']), d.get('class_id', -1), -d['confidence']))
        for index, detection in enumerate(detections):
            box = crop_bounds(detection['bbox'], image.size, padding=0.)
            crop_id = f"{row['image_id']}_{index+1:03d}"
            path = run/'crops'/(crop_id+'.png')
            image.crop(box).save(path)
            label = detection['original_label']
            # Detection metrics use the original floating-point box; only raster crop
            # extraction uses the website's integer truncation convention.
            crops.append(dict(id=crop_id, image_id=row['image_id'], bbox=list(detection['bbox']), crop_bbox=list(box), raw_bbox=detection['bbox'],
                              original_label=label, confidence=float(detection['confidence']),
                              canonical_label=supported_ingredient(label, ingredients, settings['aliases']),
                              source='manual_gt' if manual else 'yolo_auto', gt_id=detection.get('gt_id'),
                              crop_path=path.relative_to(run).as_posix(), crop_sha256=digest(path)))
    manifest = dict(run_id=run.name, scope='manual_assisted' if manual else 'fully_automatic',
                    settings=settings, padding=0., images=inv['images'], crops=crops,
                    manual_annotations=annotations, yolo_sha256=digest(Path(project)/'best.pt') if not manual else None)
    write_json(run/'frozen.json', manifest)
    return run


def infer(run, models, project=PROJECT):
    run = Path(run)
    if (run/'predictions.json').exists():
        raise FileExistsError('Predictions already frozen; create another run to repeat inference')
    frozen = read_json(run/'frozen.json')
    predictions = []
    for crop in frozen['crops']:
        path = contained(run, crop['crop_path'])
        if digest(path) != crop['crop_sha256']:
            raise ValueError('Frozen crop was modified')
        image = image_rgb(path)
        for version, model in models.items():
            result = model.predict_ingredient(image)
            predictions.append(dict(crop_id=crop['id'], version=version, **result))
    write_json(run/'predictions.json', dict(frozen_sha256=digest(run/'frozen.json'),
                                          contracts=model_contract(models, project), predictions=predictions))
    return predictions


def _plot_matrix(path, metrics, title):
    if not metrics['n']:
        return
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(12, 10))
    shown = ax.imshow(metrics['confusion_matrix'], cmap='Blues')
    ax.set(xticks=range(len(metrics['labels'])), yticks=range(len(metrics['labels'])),
           xticklabels=metrics['labels'], yticklabels=metrics['labels'], xlabel='Predicted', ylabel='Manual ground truth', title=title)
    plt.setp(ax.get_xticklabels(), rotation=90, fontsize=7)
    plt.setp(ax.get_yticklabels(), fontsize=7)
    fig.colorbar(shown, ax=ax)
    fig.tight_layout()
    fig.savefig(path, dpi=130)
    plt.close(fig)


def evaluate(data, run, ingredients):
    run = Path(run)
    frozen, inference = read_json(run/'frozen.json'), read_json(run/'predictions.json')
    if digest(run/'frozen.json') != inference['frozen_sha256']:
        raise ValueError('Frozen manifest changed after inference')
    for c in frozen['crops']:
        if digest(contained(run, c['crop_path'])) != c['crop_sha256']:
            raise ValueError('Frozen crop changed after inference')
    output = run/'evaluations'/identifier()
    output.mkdir(parents=True)
    annotations = {}
    for im in frozen['images']:
        # Refuse evaluation of stale image content, even if old labels exist.
        if digest(contained(Path(data)/'images', im['path'])) != im['sha256']:
            raise ValueError('Test image changed; freeze again')
        ann = (frozen['manual_annotations'].get(im['image_id']) if frozen['scope']=='manual_assisted'
               else latest_annotation(data, im['image_id'], True))
        if ann:
            validate_annotation(ann, im, ingredients)
            annotations[im['image_id']] = ann
    write_json(output/'annotation_snapshot.json', annotations)
    gt = [dict(o, image_id=i, label=o['ingredient']) for i,a in annotations.items() for o in a['objects']]
    crops = [dict(c, label=c['canonical_label'] or '__unsupported__') for c in frozen['crops'] if c['image_id'] in annotations]
    complete = bool(annotations) and all(a.get('bbox_complete') for a in annotations.values())
    mapping, reviewed_counts = {}, Counter()
    if frozen['scope'] == 'manual_assisted':
        by_id = {(g['image_id'],g['id']):g for g in gt}
        mapping = {c['id']:by_id[(c['image_id'],c['gt_id'])] for c in crops}
    elif complete:
        mapping = {c['id']:g for c,g,_ in match_boxes(crops, gt) if g is not None}
    else:
        by_id = {(g['image_id'],g['id']):g for g in gt}
        by_crop = {c['id']:c for c in crops}
        for image_id, annotation in annotations.items():
            for review in annotation.get('detection_reviews', []):
                if review['run_id'] != frozen['run_id']:
                    continue
                c = by_crop.get(review['detection_id'])
                if c is None or c['image_id'] != image_id:
                    raise ValueError('Review references unknown detection')
                reviewed_counts[review['decision']] += 1
                if review['decision']=='valid':
                    mapping[c['id']] = by_id[(image_id,review['gt_id'])]
    label_reviewable = [c for c in crops if c['id'] in mapping and mapping[c['id']]['ingredient'] in ingredients]
    label_correct = sum(c['canonical_label']==mapping[c['id']]['ingredient'] for c in label_reviewable)
    yolo = dict(status='not_applicable_manual_assisted' if frozen['scope']=='manual_assisted' else 'full_bbox_iou' if complete else 'manual_review_only',
                reviewed_images=len(annotations), total_images=len(frozen['images']), actual_objects=len(gt),
                detected_on_reviewed_images=len(crops), detected_all_images=len(frozen['crops']),
                matched_objects=len(mapping), missed_or_unverified_objects=len(gt)-len(mapping),
                label_correct=label_correct, label_wrong=len(label_reviewable)-label_correct,
                label_denominator=len(label_reviewable), out_of_scope_label_unverified=len(mapping)-len(label_reviewable),
                unsupported_labels=dict(Counter(c['original_label'] for c in crops if not c['canonical_label'])),
                manual_decisions=dict(reviewed_counts), manual_unreviewed_boxes=len(crops)-sum(reviewed_counts.values()) if not complete else None)
    if complete and frozen['scope']=='fully_automatic':
        yolo['iou_metrics'] = detection_metrics(crops, gt)
        yolo['unmatched_boxes'] = len(crops)-len(mapping)
        yolo['duplicate_candidates_iou50'] = sum(any(
            iou(c['bbox'],g['bbox'])>=.5
            for g in gt if g['image_id']==c['image_id']) for c in crops if c['id'] not in mapping)
    elif frozen['scope']=='fully_automatic':
        fully_reviewed = bool(annotations) and sum(reviewed_counts.values())==len(crops) and not reviewed_counts['uncertain']
        yolo['manual_review_complete'] = fully_reviewed
        yolo['manual_precision'] = ratio(len(mapping),len(crops)) if fully_reviewed else None
        yolo['manual_recall'] = ratio(len(mapping),len(gt)) if fully_reviewed else None
        yolo['manual_missed_objects'] = len(gt)-len(mapping) if fully_reviewed else None
    per_image=[]
    for im in frozen['images']:
        image_id=im['image_id']
        cs=[c for c in frozen['crops'] if c['image_id']==image_id]
        matches=[c for c in cs if c['id'] in mapping]
        ann=annotations.get(image_id)
        per_image.append(dict(image_id=image_id,path=im['path'],reviewed=bool(ann),
            actual_count=ann['actual_count'] if ann else None,detected=len(cs),matched=len(matches) if ann else None,
            missed_or_unverified=ann['actual_count']-len(matches) if ann else None,
            unsupported=sum(not c['canonical_label'] for c in cs),
            correct_labels=sum(c['canonical_label']==mapping[c['id']]['ingredient'] for c in matches if mapping[c['id']]['ingredient'] in ingredients),
            wrong_labels=sum(c['canonical_label']!=mapping[c['id']]['ingredient'] for c in matches if mapping[c['id']]['ingredient'] in ingredients)))
    write_csv(output/'yolo_per_image.csv',per_image,['image_id','path','reviewed','actual_count','detected','matched','missed_or_unverified','unsupported','correct_labels','wrong_labels'])
    rows, summaries, e2e = [], {}, {}
    predictions = {(p['version'],p['crop_id']):p for p in inference['predictions']}
    for version in ('v5','v6'):
        evaluated = []
        for c in crops:
            if c['id'] not in mapping:
                continue
            g, p = mapping[c['id']], predictions[(version,c['id'])]
            evaluated.append(dict(version=version, crop_id=c['id'], image_id=c['image_id'],
                                  gt_id=g['id'], ingredient=g['ingredient'], condition=g['condition'],
                                  pred_ingredient=p['ingredient'], pred_condition=p['condition'],
                                  auto_eligible=bool(c['canonical_label']), crop_path=c['crop_path'],
                                  ingredient_correct=g['ingredient']==p['ingredient'],
                                  joint_correct=g['ingredient']==p['ingredient'] and g['condition']==p['condition']))
        rows.extend(evaluated)
        summaries[version] = classifier_metrics(evaluated, ingredients)
        known_gt = [g for g in gt if g['ingredient'] in ingredients and g['condition']!='uncertain']
        # Automatic gate reproduces the website: unsupported YOLO labels never enter EfficientNet.
        eligible = [r for r in evaluated if frozen['scope']=='manual_assisted' or r['auto_eligible']]
        e2e[version] = dict(scope=frozen['scope'], ingredient_correct=sum(r['ingredient_correct'] for r in eligible),
                            actual_objects_denominator=len(gt), ingredient_recall=ratio(sum(r['ingredient_correct'] for r in eligible),len(gt)),
                            joint_correct=sum(r['joint_correct'] for r in eligible if r['condition']!='uncertain' and r['ingredient'] in ingredients),
                            joint_denominator=len(known_gt),
                            joint_recall=ratio(sum(r['joint_correct'] for r in eligible if r['condition']!='uncertain' and r['ingredient'] in ingredients),len(known_gt)),
                            uncertain_excluded=sum(g['condition']=='uncertain' for g in gt),
                            out_of_scope_joint_excluded=sum(g['ingredient'] not in ingredients for g in gt))
        for kind in ('ingredient','joint'):
            metrics = summaries[version][kind]
            write_csv(output/f'{version}_{kind}_classes.csv', metrics['per_class'], ['label','support','predicted','precision','recall','f1'])
            write_csv(output/f'{version}_{kind}_confusion.csv', [dict(truth=l, **dict(zip(metrics['labels'],r))) for l,r in zip(metrics['labels'],metrics['confusion_matrix'])], ['truth',*metrics['labels']])
            _plot_matrix(output/f'{version}_{kind}_confusion.png', metrics, f'{version.upper()} {kind} (n={metrics["n"]})')
    fields = ['version','crop_id','image_id','gt_id','ingredient','condition','pred_ingredient','pred_condition','auto_eligible','ingredient_correct','joint_correct','crop_path']
    write_csv(output/'reviewed_crop_predictions.csv', rows, fields)
    write_csv(output/'errors_by_ingredient.csv', [r for r in rows if not r['ingredient_correct'] or (r['condition']!='uncertain' and not r['joint_correct'])], fields)
    pairs = {(r['version'],r['crop_id']):r for r in rows}
    for good, bad in [('v5','v6'),('v6','v5')]:
        selected = [r for r in rows if r['version']==good and r['condition']!='uncertain' and r['joint_correct'] and not pairs[(bad,r['crop_id'])]['joint_correct']]
        write_csv(output/f'{good}_right_{bad}_wrong.csv', selected, fields)
    per_ingredient = []
    for version in ('v5','v6'):
        for name in ingredients:
            subset = [r for r in rows if r['version']==version and r['ingredient']==name]
            known = [r for r in subset if r['condition']!='uncertain']
            right = [r for r in known if r['ingredient_correct']]
            per_ingredient.append(dict(version=version,ingredient=name,support=len(subset),
                normal_support=sum(r['condition']=='normal_appearance' for r in subset),
                defect_support=sum(r['condition']=='visible_defect' for r in subset),
                uncertain=sum(r['condition']=='uncertain' for r in subset),
                ingredient_accuracy=ratio(sum(r['ingredient_correct'] for r in subset),len(subset)),
                condition_accuracy_given_correct=ratio(sum(r['joint_correct'] for r in right),len(right)),
                joint_accuracy=ratio(sum(r['joint_correct'] for r in known),len(known))))
    write_csv(output/'accuracy_by_ingredient.csv',per_ingredient,list(per_ingredient[0]) if per_ingredient else ['ingredient'])
    write_csv(output/'meat_seafood.csv',[r for r in per_ingredient if r['ingredient'] in ('beef','pork','chicken','fish','shrimp')],list(per_ingredient[0]) if per_ingredient else ['ingredient'])
    _comparison_plot(output, per_ingredient)
    _error_examples(run, output, rows)
    summary = dict(scope=frozen['scope'], yolo=yolo, classifiers=summaries, pipeline=e2e,
                   reviewed_images=len(annotations), pending_images=len(frozen['images'])-len(annotations),
                   diagnostic_note='Classifier metrics include matched supported GT crops, even if original YOLO label was unsupported. Auto pipeline retains the YOLO eligibility gate.',
                   audit_required='Run audit separately; metrics alone do not establish Test independence.')
    summary['matching_complete'] = complete or frozen['scope']=='manual_assisted' or (
        bool(annotations) and sum(reviewed_counts.values())==len(crops) and not reviewed_counts['uncertain'])
    summary['interpretation'] = 'Final for reviewed subset' if summary['matching_complete'] else 'Provisional: incomplete box review; unmatched means missed OR unverified, pipeline recall is a lower bound'
    write_json(output/'summary.json', summary)
    report = ['# Independent real-world Test V1', '',f'Scope: **{frozen["scope"]}**.',
              f'Images: {len(frozen["images"])}; reviewed: {len(annotations)}; actual objects: {len(gt)}.',
              '', '## Data availability',
              'Insufficient independent reviewed data; no V5/V6 winner or Train 4 base model can be selected.' if not rows else
              'Results describe this reviewed subset only. Complete the leakage audit before interpreting independence. No general accuracy claim.',
              '', summary['interpretation'], '', '## YOLO', '```json', json.dumps(yolo,indent=2), '```',
              '', '## Classifiers on shared frozen, matched crops',
              '| Model | Ingredient n / accuracy | Known-state n / joint accuracy | Condition given correct ingredient | Uncertain excluded |',
              '|---|---|---|---|---|']
    for v,s in summaries.items():
        report.append(f'| {v} | {s["ingredient"]["n"]} / {s["ingredient"]["accuracy"]} | {s["joint"]["n"]} / {s["joint"]["accuracy"]} | {s["condition_given_correct_ingredient"]} (n={s["condition_denominator"]}) | {s["uncertain_excluded"]} |')
    report += ['', 'Macro F1 uses the fixed 19 / 38 label set (zero-division=0); supported-only macro F1 is also exported. Zero-support classes are not evidence of failure.',
               '', '## End-to-end pipeline', '```json', json.dumps(e2e,indent=2), '```',
               '', '## Train 4 proposal (no training performed)',
               'Collect more independent, reviewed images for zero/low-support classes first. Do not choose V5 or V6 from absent or tiny Test evidence. Website stays on V5.',
               'Use errors_by_ingredient.csv, meat_seafood.csv and condition confusion tables to prioritize acquisition. Localization misses/duplicates indicate a detector data problem; errors on valid shared crops indicate classifier work.',
               'For a future fine-tune: keep a frozen independent Test, split by capture session/source, preserve old-class replay data, use balanced sampling and a small learning rate, compare old-class validation before accepting a checkpoint. Never add this Test to training.',
               '', '## Limits',
               'No crowd/ignore/area COCO protocol. AP uses one-to-one confidence matching and 101-point interpolation at IoU .50:.05:.95. Manual-only annotations never produce mAP.',
               'Localization matching is label-independent; class-aware AP is separately exported. Duplicate candidates require human confirmation. Appearance labels cannot establish food safety.',
               'Old exploratory 18-image results are excluded. Unmatched/duplicate predictions are excluded from classifier crop accuracy but count against YOLO precision. Pipeline recall denominator includes missed objects; unsupported GT is reported separately for joint scoring.']
    (output/'report.md').write_text('\n'.join(report)+'\n',encoding='utf-8')
    return output


def _comparison_plot(output, rows):
    if not any(r['support'] for r in rows):
        return
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,ax = plt.subplots(figsize=(14,5))
    names = [r['ingredient'] for r in rows if r['version']=='v5']
    for v,offset in [('v5',-.2),('v6',.2)]:
        values = [r['ingredient_accuracy'] if r['ingredient_accuracy'] is not None else float('nan') for r in rows if r['version']==v]
        ax.bar([i+offset for i in range(len(names))],values,width=.4,label=v)
    ax.set(xticks=range(len(names)),xticklabels=names,ylim=(0,1),ylabel='Ingredient accuracy on reviewed crops')
    plt.setp(ax.get_xticklabels(),rotation=60,ha='right')
    ax.legend(); fig.tight_layout(); fig.savefig(output/'comparison.png',dpi=130); plt.close(fig)


def _error_examples(run, output, rows):
    errors = [r for r in rows if not r['ingredient_correct'] or (r['condition']!='uncertain' and not r['joint_correct'])]
    if not errors:
        return
    target = output/'error_examples'; target.mkdir()
    # One labeled panel per error, with original crop retained in immutable run/crops.
    for r in errors:
        crop = image_rgb(contained(run,r['crop_path']))
        crop.thumbnail((400,300))
        panel = Image.new('RGB',(600, max(100,crop.height)+65),'white'); panel.paste(crop,(0,65))
        ImageDraw.Draw(panel).text((5,5),f"{r['version']} / {r['crop_id']}\nGT: {r['ingredient']} {r['condition']}\nAI: {r['pred_ingredient']} {r['pred_condition']}",fill='black')
        panel.save(target/f"{r['version']}_{r['crop_id']}.png")
