# SIC-Food — source chia sẻ cho nhóm

Bản source nhẹ của dự án hiện tại, gồm website, notebook, test và công cụ nghiên cứu.
Không chứa dataset, checkpoint, cache, môi trường Python, ảnh/video kiểm thử thực tế,
backup, kết quả training hoặc các bản ZIP bàn giao cũ.

## Hiện trạng

- **Module 1:** YOLO nhận diện món ăn trong ảnh/video; xác nhận món, nhập gram, tính dinh dưỡng và xuất JSON.
- **Module 2:** một luồng YOLO → box → crop → EfficientNet B0 **V5**, 38 lớp/19 nguyên liệu.
  Có thêm/sửa/xóa/khôi phục box, giữ riêng kết quả YOLO gốc và xác nhận thủ công.
- **Nghiên cứu:** so sánh V5/V6 offline trên crop chung, Jupyter kiểm duyệt GT, kiểm tra trùng dữ liệu và xuất chỉ số.
  Website vẫn dùng V5. Bộ Test độc lập mới chưa có ảnh/nhãn, chưa kết luận model nào tốt hơn và chưa train tiếp.
- Dữ liệu dinh dưỡng/config JSON là dữ liệu cần cho ứng dụng, được giữ trong bản này.

## Cấu trúc

```text
main.py                       Điểm chạy Streamlit
page1.py, page2.py             Module 1
condition_page.py             Module 2
ingredient_pipeline.py        YOLO → crop → V5
box_review.py, box_editor*    Quản lý box và kết quả chỉnh sửa
components/box_editor/        HTML/CSS/JS local của canvas
*_service.py, model_loader.py Xử lý ảnh, model, dinh dưỡng
config/                       Cấu hình và hồ sơ dinh dưỡng
research/                     Công cụ Test độc lập V5/V6
scripts/                      Dataset, training và đóng gói (chỉ là source)
tests/                        Unit/AppTest, JavaScript và script kiểm tra thật
*.ipynb                       Notebook đã bỏ output trong bản sao
docs/                         Hướng dẫn và tài liệu lịch sử
models/README.md              Danh sách weights cần lấy riêng
SHARING_MANIFEST.json          Kiểm kê file/SHA-256 và phạm vi loại bỏ
```

## Chạy website trên Windows CPU

Dùng Python 3.11. Mở PowerShell tại thư mục có main.py:

```powershell
py -3.11 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
.venv\Scripts\python.exe -m streamlit run main.py
```

Không cần dataset để chạy website. Không có weights thì xem giao diện và nhập món thủ công;
các chức năng AI cần lấy checkpoint riêng theo models/README.md. Ứng dụng không tự tải weights khi mở.
Các dependency chưa được khóa hoàn toàn; kết quả kiểm thử ở máy tác giả không bảo đảm mọi môi trường cài mới.

## Notebook và kiểm thử

```powershell
.venv\Scripts\python.exe -m pip install -r requirements-research.txt
.venv\Scripts\python.exe -m jupyterlab
.venv\Scripts\python.exe -m unittest discover -s tests -p "test_*.py" -v
node --test tests/box_editor_geometry.test.mjs
```

Notebook gốc giữ nguyên; bản chia sẻ chỉ bỏ output, execution count và widget state.
Một số notebook có ROOT/đường dẫn tuyệt đối của máy tác giả: sửa theo nơi bạn giải nén.
Không cần chạy notebook training để mở website. Các notebook tải dữ liệu/train/audit cần tài nguyên riêng;
không chạy tất cả cell nếu chỉ muốn đọc source.

Các test `test_*.py` dùng fixture/mock và không cần dataset hoặc weights thật.
Các script `check_*.py` và `evaluate_real_world.py smoke` cần weights và ảnh/video bên ngoài gói.
Xem docs/website_usage.md, docs/module2_box_editor_delivery.md và docs/real_world_test_v1_guide.md.
Các số liệu trong docs là kết quả lịch sử có phạm vi riêng; không phải accuracy mới của bản chia sẻ này.

## Đưa lên GitHub cho nhóm

1. Giải nén ZIP và mở thư mục **SIC-Food** có main.py.
2. Tạo repository trên GitHub; chọn **Private** nếu chỉ muốn các thành viên nhóm xem.
3. Dùng GitHub Desktop → File → Add local repository → chọn thư mục SIC-Food;
   nếu chưa là Git repository, chọn tạo repository tại thư mục này, rồi commit và Publish repository.
   Hoặc trên repository GitHub chọn Add file → Upload files và tải nội dung bên trong SIC-Food.
4. Kiểm tra có cả `.gitignore`; không cần đưa file ZIP lên repository.
5. Trong Settings → Collaborators, mời tài khoản GitHub của các bạn cùng nhóm.

Giữ .gitignore để dataset/model/cache không lọt vào các commit sau. Weights/dataset chia sẻ riêng qua
kho lưu trữ của nhóm; chưa có đường dẫn tải công khai V5/V6 được cấu hình trong gói.

## Tạo lại bản source nhẹ

```powershell
python scripts/package_github_source.py
```

Lệnh tạo thư mục và ZIP mới trong dist/, không xóa hoặc sửa dataset/model/source hiện có.
