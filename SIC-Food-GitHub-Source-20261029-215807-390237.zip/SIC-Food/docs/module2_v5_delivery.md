# Bàn giao Module 2 — YOLO → Crop → EfficientNet V5

Ngày thực hiện: **29/10/2026**, source chính `C:\Users\ASUS\SIC-Food`.

## A. Source đã thay đổi

### Hiện trạng được xác minh trước khi sửa

Source đã có tích hợp loader V5 trước phiên này: `model_loader.py` mặc định V5; `condition_service.py` phân biệt metadata V5/V6/legacy37 và dùng Resize((224,224)) cho V5. Tuy nhiên `condition_page.py` vẫn gọi classifier trên toàn ảnh, chưa nối YOLO → crop. README vẫn mô tả website 37 lớp cũ. Do đó đã tái sử dụng loader hiện có và mở rộng service, không viết lại bộ nạp model khác.

Import graph sau thay đổi:

```text
main.py
  ├─ page1.py → page2.py (video) → detection_service.detect_image + nutrition_service
  └─ condition_page.py
       ├─ app_state + image_service
       ├─ model_loader.load_model / load_condition_model (cache CPU)
       └─ ingredient_pipeline.analyze_ingredients
            ├─ detection_service.detect_ingredients (YOLO có khóa)
            └─ ConditionClassifier.predict_ingredient (V5 có khóa)
```

### Các file sửa

| File | Lý do |
| --- | --- |
| `condition_page.py` | Thay phân loại toàn ảnh bằng một pipeline; ảnh box, thẻ crop, Top-3, tổng quan, sửa/xác nhận riêng và xuất JSON |
| `condition_service.py` | Tái sử dụng loader/preprocessing; thêm gộp hai trạng thái theo nguyên liệu và khóa inference, giữ API predict cũ cho caller offline |
| `model_loader.py` | Module 2 bắt buộc V5, từ chối env chọn V6/legacy37; không gây lỗi ngay khi import làm hỏng Module 1 |
| `detection_service.py` | Thêm entry YOLO riêng cho Module 2, tái sử dụng khóa/normalize; giữ nguyên detect_image của Module 1 |
| `app_state.py` | Callback chỉnh sửa Module 2 tách khỏi logic nutrition; reset thêm metadata cũ |
| `main.py` | Cập nhật mô tả trang chủ/sidebar theo pipeline mới |
| `README.md` | Cách chạy CMD/Jupyter, contract V5, baseline, test và giới hạn hiện tại |
| `tests/ui_harness.py` | Fixture pipeline mới; mock được ghi rõ, không dùng trong production |
| `tests/test_website_ui.py` | Chuyển kỳ vọng từ luồng toàn ảnh cũ sang pipeline; thêm kiểm thử sửa/reset/ảnh mới/lỗi, dùng timeout 30 giây |
| `tests/check_website_models.py` | Entry CLI tương thích gọi kiểm tra V5 mới, không còn ghi đè báo cáo legacy37 |

### Các file mới

- `ingredient_pipeline.py`: orchestration, alias/geometry/uncertainty, output contract, annotation và overlay người dùng.
- `config/ingredient_pipeline.json`: tham số riêng Module 2, alias minh bạch.
- `tests/test_ingredient_pipeline.py`: 10 test synthetic về công thức, crop, nhiều box, unsupported, bất đồng, lỗi riêng crop, giới hạn và hồi quy conf Module 1.
- `tests/check_ingredient_pipeline.py`: chạy model thật trên bộ ảnh thủ công, đối chiếu box/nhãn đã duyệt và kiểm tra hash bảo vệ.
- Báo cáo này và kết quả mới trong `reports/module2_v5_20261029/`.

Không sửa `page1.py`, `page2.py`, `nutrition_service.py`, `food_items.json`, `config/nutrition_profiles.json`, notebook hoặc checkpoint/dataset. Không thêm dependency. `ui_components.py` được sao lưu dự phòng nhưng cuối cùng không cần sửa.

### Sao lưu và bảo toàn

Đã sao lưu riêng các file dự kiến sửa trước khi chỉnh tại:

`backups/module2_v5_20261029_153636/`

`source_hashes.json` ghi source trước sửa; `protected_hashes.json` ghi 30 file bảo vệ gồm weights, notebook, dữ liệu dinh dưỡng, source Module 1, manifest Train/Validation và bảng kiểm duyệt. Đối chiếu cuối: **30/30 khớp hash**. Không chỉnh source trong bản handover hoặc các backup cũ.

## B. Pipeline thực tế

1. Decode ảnh có giới hạn, EXIF transpose và RGB bằng service hiện có.
2. Một lần gọi YOLO cho ảnh: `conf=0.25`, `imgsz=640`, `device=cpu`, `iou=0.7`, `agnostic_nms=False`, `max_det=50`. Đã kiểm tra cấu hình mặc định của Ultralytics cài trên máy: IoU 0,7 và NMS theo lớp. Giới hạn 50 là bảo vệ CPU/RAM riêng website; mặc định thư viện là 300.
3. Sắp ID theo `(x1,y1,x2,y2,class_id,-score)` — trái sang phải là ưu tiên đầu tiên, sau đó trên xuống dưới khi cùng x. Không theo thứ tự YOLO.
4. Lấy danh sách hỗ trợ từ `class_names` của V5 và kiểm tra đúng 19 nhóm, mỗi nhóm hai trạng thái. Alias chỉ chứa tên tương đương như bell pepper/bell peppers; không fuzzy match Steak/Pork Satay/Chicken Rice/Apple Pie sang nguyên liệu.
5. Nhãn ngoài phạm vi giữ `unsupported`, không chạy V5. Bbox không hợp lệ giữ dòng `error`, bỏ qua suy luận.
6. Clip bbox vào ảnh, crop padding mặc định 0%; tọa độ pixel dùng int như notebook. Padding nghiên cứu chỉ thay qua config, không tự bật.
7. Suy luận từng crop lần lượt, không giữ toàn bộ tensor/crop lớn trong session. Model chỉ nạp qua cache, không nạp mỗi box. Crop hiển thị được tái tạo từ ảnh và tọa độ, thumbnail tối đa 384×384.
8. Gộp softmax hai trạng thái để chọn nguyên liệu; chọn trạng thái có điểm lớn nhất trong nhóm đã chọn; điểm trạng thái có điều kiện = điểm lớp / tổng điểm nhóm. Top-3 vẫn theo 38 nhãn gốc.
9. Hai điểm dưới ngưỡng thử nghiệm 0,6 hoặc bất đồng giữa YOLO/V5 được cảnh báo. `disagreement` ưu tiên status khi cùng có điểm thấp; cả hai cảnh báo vẫn được giữ. Không coi ngưỡng là calibration.

Output mỗi box có cùng các trường: `object_id`, `bbox_xyxy`, `crop_xyxy`, `yolo_label`, `class_id`, `yolo_score`, `yolo_ingredient`, `supported`, `status`, `ingredient`, `condition`, `ingredient_score`, `condition_score`, `top3`, `warnings`, `error_code`. Không dự đoán được thì ingredient/condition/score là null, không tự điền trạng thái bình thường.

Giữ box trùng/chồng nhau để người dùng kiểm tra; không tự bật class-agnostic NMS hoặc tự gộp theo loại. Không phát hiện được thì dừng với thông báo chưa phát hiện nguyên liệu; không fallback toàn ảnh. Không suy ra số đối tượng bỏ sót trên ảnh upload bất kỳ.

### Checkpoint xác minh

- File: `models/efficientnet_v5_38/efficientnet_b0_38_prototype_head.pth`.
- `num_classes=38`, `epoch=2`, `training_type=provisional_head_training`, `validation_scope=provisional_group_split`, `val_macro_f1=0.96983693053433` là metadata lịch sử, không phải chỉ số triển khai mới.
- Checkpoint không có giá trị pretrained_weights như legacy37; không áp nhầm contract/preprocessing legacy37.
- CPU `torch.load(..., weights_only=True)`, `efficientnet_b0(weights=None)`, head `[38,1280]`, strict state dict, eval/inference_mode.
- Thứ tự 38 lớp khớp nguyên vẹn checkpoint; 19 nguyên liệu, có tôm, không có broccoli.
- Preprocessing: EXIF/RGB → Resize((224,224)) Bilinear → ToTensor → mean `[0.485,0.456,0.406]`, std `[0.229,0.224,0.225]`.
- Không dùng hoặc suy luận với checkpoint V6. Loader offline vẫn giữ khả năng đọc các phiên bản nghiên cứu để không phá caller/test hiện có; website yêu cầu V5.

## C. Giao diện website

Module 2 **chỉ có một chế độ tự động**. Không tab một/nhiều nguyên liệu và không nút phân loại trực tiếp toàn ảnh.

- Upload JPG/JPEG/PNG, preview, một nút **Phân tích bằng AI**, spinner và Reset.
- Ảnh box đánh số khớp thẻ crop; xanh bình thường, đỏ bất thường, vàng cần kiểm tra/ngoài phạm vi.
- Mỗi thẻ: YOLO label/score, nguyên liệu/trạng thái V5, hai điểm, Top-3, cảnh báo; không gọi điểm là xác suất AI đúng.
- Sửa tên, trạng thái, xác nhận/cần xem lại sau suy luận. Lưu `cond_edits` riêng, không sửa kết quả AI gốc hoặc weights. Đổi tên/trạng thái bỏ xác nhận cũ.
- Đổi ảnh/xóa/Reset xóa đúng kết quả cũ. Phân tích lại không nhân đôi kết quả. Chuyển trang giữ kết quả/bản sửa trong session.
- Tổng quan là số liệu AI gốc, bao gồm dự đoán tạm; bản sửa được hiển thị riêng. Có xuất JSON chứa cả hai và kết quả sau sửa.
- Không lưu ảnh người dùng trên đĩa trong luồng website.

Đã kiểm tra bằng trình duyệt thật: trang chủ → Module 2 → upload ảnh bốn quả táo → phân tích thật → bốn box/bốn thẻ → sửa trạng thái đối tượng 02 và xác nhận. Dự đoán AI gốc vẫn giữ nguyên; thời gian phân tích hiển thị không thay đổi khi sửa. Tab sau đó cũng hiển thị ảnh nhiều chuối với từng kết quả riêng.

Ảnh minh chứng:

- `reports/module2_v5_20261029/website_boxes.jpg`: bốn box; đối tượng 02 đỏ là **bản sửa thử nghiệm của người dùng**, không phải kết luận AI gốc.
- `reports/module2_v5_20261029/website_pipeline.jpg`: thẻ crop trên giao diện nhiều chuối.

Không xác nhận đã kiểm thử trên điện thoại thật hoặc toàn bộ trình duyệt. Việc chọn file qua browser ban đầu timeout, sau đó upload bằng nút Streamlit thành công; đó là vấn đề công cụ điều khiển, không phải một lần upload đã đạt ngay từ đầu.

## D. Kiểm thử

### Kết quả cuối

| Kiểm tra | Kết quả |
| --- | --- |
| `python -B -m unittest discover -s tests -p "test_*.py"` | **69/69 PASS**, 14,315 giây, ngoài sandbox Windows |
| Chạy riêng 64 test ngoài UI với TEMP/TMP trong workspace | **64/64 PASS**, 6,523 giây |
| Chạy riêng 5 AppTest | **5/5 PASS**, 5,449 giây, ngoài sandbox |
| AST root/tests | **29 file PASS** |
| Checkpoint V5, thứ tự nhãn, CPU, classifier 38, cache object | **PASS** |
| Hash 30 file bảo vệ trước/sau | **30/30 khớp** |
| Streamlit startup và `/_stcore/health` | **200, ok**, cổng 8502 |
| Browser upload/inference/crop/correction thật | **PASS các bước nêu ở C** |
| Module 1 ảnh/video model thật | **5 box ảnh / 2 box video frame 0**, conf 0,5 |
| Module 1 dinh dưỡng/navigation/session trong AppTest | **PASS**, chuối 150 g → 133,50 kcal; source/data dinh dưỡng khớp hash |

Không có test cuối cùng FAIL. Các lỗi synthetic inference in ra log được cố ý tạo để kiểm tra lỗi riêng crop/model; test vẫn kiểm tra UI không có exception không xử lý.

Một lần kiểm tra script thật ban đầu dừng vì ảnh có 0 detection không có hàng trong CSV baseline, nên không có image_hash trong bảng predictions. Đã sửa logic đối chiếu chỉ yêu cầu hash khi baseline có hàng; không bỏ kiểm tra hash của 63 box được tái sử dụng. Lần chạy cuối đạt đầy đủ.

Sandbox chặn socket localhost bằng WinError 10013; health được kiểm tra lại ngoài sandbox và trả 200. AppTest chạy ngoài sandbox theo giới hạn Windows đã biết, không giả lập PASS. Không huấn luyện hoặc cài thêm thư viện.

### Bộ ảnh thật và đối chiếu bảng thủ công

Đọc 18 JPG/JPEG/PNG từ `tests/manual_pipeline_images`; ảnh WEBP ngoài phạm vi upload Module 2 không nằm trong lần này. So sánh với `reports/pipeline_v5_test/predictions_auto.csv` và `manual_review.csv` theo image hash + bbox pixel + YOLO label, không gán Ground Truth bằng Object ID đơn thuần.

| Chỉ tiêu lần chạy mới | Giá trị |
| --- | ---: |
| Số ảnh | 18 |
| Box YOLO | 63 |
| Box khớp baseline cũ | 63/63 |
| Box đã được duyệt hợp lệ trong baseline | 55 |
| Box được V5 phân loại theo chính sách mới | 60 |
| Box unsupported | 3 |
| Status classified / low_confidence / disagreement | 53 / 3 / 4 |
| Box error trên bộ ảnh này | 0 |
| Dự đoán V5 trùng notebook trên crop đã chạy V5 | 60/60 |
| Crop hợp lệ thuộc phần được phân loại | 54/55 |
| Đúng nguyên liệu trên crop hợp lệ đã phân loại | 50/54 = **92,59%** |
| Đúng nguyên liệu trên tất cả crop hợp lệ, coi unclassified là chưa đúng | 50/55 = **90,91%** |
| Đúng trạng thái khi đúng nguyên liệu | 44/50 = **88,00%** |
| Đúng cả nguyên liệu và trạng thái trên tất cả crop hợp lệ | 44/55 = **80,00%** |
| Thời gian trung bình pipeline CPU/ảnh | khoảng **477 ms**, không gồm tải model |

Chính sách mới từ chối 3 nhãn ngoài phạm vi: **Peach** (box hợp lệ, GT apple), **Lemon** và **Grapefruit** (hai box không hợp lệ). Notebook cũ chạy EfficientNet trên tất cả crop, nên có thể sửa lại nhãn Peach thành apple; website mới tuân thủ yêu cầu không ép phân loại nhãn ngoài phạm vi. Đây là nguyên nhân một dự đoán đúng trong baseline không còn được tính là đã phân loại, không phải model V5 bị thay đổi hoặc tự giảm chất lượng.

YOLO baseline giữ nguyên 55 box hợp lệ, 8 sai/trùng và 64 đối tượng GT trong bộ ảnh đã duyệt. Vì 63/63 box tái tạo đúng, cấu hình mới không tạo một phép đo detection độc lập khác. Không hiển thị các chỉ số này trên UI như accuracy đảm bảo.

Không suy rộng những tỷ lệ trên thành benchmark tổng quát, mAP hoặc chứng nhận an toàn. Ảnh minh họa/ảnh nguồn mạng trong bộ thử cũng không thay thế dữ liệu chụp thực tế độc lập.

Chi tiết: `reports/module2_v5_20261029/real_pipeline_results.json`, `predictions_new.csv`, ảnh annotation mẫu. Các bảng duyệt và Ground Truth cũ giữ nguyên hash.

## E. Hướng dẫn chạy

CMD Windows trong môi trường `sic-food`:

```bat
cd /d "C:\Users\ASUS\SIC-Food"
python -m streamlit run main.py --server.port 8502
```

Website đã được khởi động tại http://127.0.0.1:8502 trong phiên thực hiện. Dùng server hiện có hoặc dừng server đó trước khi khởi động lại cùng cổng.

Cách khởi động bằng Jupyter, quản lý subprocess và các biến môi trường được ghi đầy đủ trong README root. Không chạy notebook training để mở website. Module 2 cần cả `best.pt` lẫn checkpoint V5 đúng đường dẫn.

## F. Hạn chế còn lại và hướng xử lý không cần training mới

1. Detector món ăn 214 nhãn có thể nhầm nguyên liệu, tạo box trùng hoặc bỏ sót. Giữ baseline class-aware NMS; có thể nghiên cứu IoU/agnostic NMS bằng config trên tập review riêng, không mặc định bật từ một ảnh.
2. Chính sách lọc nhãn bảo thủ chặn cả crop nguyên liệu thực nếu YOLO gọi nhầm thành nhãn ngoài phạm vi. Có thể bổ sung vẽ/chỉnh box thủ công trong cùng pipeline ở bước sau; hiện chưa có tính năng này.
3. V5 chưa có OOD hoặc hiệu chỉnh điểm. Tiếp tục duyệt crop/ảnh ngoài miền và chọn ngưỡng cảnh báo bằng tập riêng; chưa cần training lại để thu thập bằng chứng.
4. Dataset nghiên cứu vẫn còn audit chưa hoàn tất; việc tích hợp website không giải quyết hoặc sửa các manifest đó. V5 là model đã được người dùng chỉ định cho module hiện tại, không phải tuyên bố V5 đã được kiểm định đầy đủ.
5. Nhiều box có thể chậm; đã giới hạn 50, xử lý từng crop và cache model. Chưa batch inference; giữ tuần tự để cô lập lỗi crop và giới hạn RAM trên CPU.
6. Session chỉ lưu RAM, không có tài khoản/lịch sử bền vững. Bản sửa tải JSON không tự huấn luyện model.
7. Crop rất dài/che khuất có thể thiếu tín hiệu sau resize vuông. Cho phép thử padding qua config; mặc định vẫn 0% đúng baseline đã yêu cầu.
8. Chưa kiểm thử điện thoại thật, mọi trình duyệt hoặc tải đồng thời nhiều người dùng. Có khóa inference chung nhưng chưa có benchmark tải hệ thống.

Không cần training mới để dùng phiên bản Module 2 này hoặc để thực hiện các bước kiểm tra/cải thiện giao diện và cấu hình nêu trên.
