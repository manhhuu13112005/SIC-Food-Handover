"""Compact box tools embedded in the existing Module 2 workflow."""
import streamlit as st

from box_editor_component import preview_data, render_box_canvas
from box_review import update_box, delete_box, restore_boxes, validate_canvas_event
from model_loader import load_condition_model
from ui_components import food_name


def _row(workspace, target):
    return next((r for r in workspace['objects'] if r['object_id'] == target), None)


def _seed_controls(workspace):
    ids = [r['object_id'] for r in workspace['objects']]
    previous = st.session_state.get('cond_box_bound')
    fallback = previous[2] if previous and previous[0] == workspace['analysis_id'] else (ids[0] if ids else 0)
    target = st.session_state.get('cond_box_selected', fallback)
    if target not in [0] + ids:
        target = 0
    st.session_state['cond_box_selected'] = target
    binding = (workspace['analysis_id'], workspace['revision'], target)
    required = ['cond_box_'+name for name in ('x1','y1','x2','y2','ingredient','confirm')]
    if st.session_state.get('cond_box_bound') != binding or any(key not in st.session_state for key in required):
        row = _row(workspace, target)
        bounds = row['crop_xyxy'] if row and row['crop_xyxy'] else [0,0,0,0]
        for name,value in zip(('x1','y1','x2','y2'),bounds):
            st.session_state['cond_box_'+name] = int(value)
        st.session_state['cond_box_ingredient'] = ''
        st.session_state['cond_box_confirm'] = False
        st.session_state['cond_box_bound'] = binding
    return target


def _clear_corrections(object_ids):
    for object_id in object_ids:
        st.session_state.get('cond_edits', {}).pop(str(object_id), None)
        for key in list(st.session_state):
            if key.startswith(f'cond_field_{object_id}_'):
                del st.session_state[key]


def _commit(workspace, changed_ids, message):
    st.session_state['cond_workspace'] = workspace
    _clear_corrections(changed_ids)
    st.session_state['cond_box_notice'] = message
    st.rerun()


def render_box_tools(image, workspace):
    with st.expander('Quản lý vùng nguyên liệu · thêm / sửa / xóa box'):
        st.caption('AI đã chạy trước. Chỉnh vùng ở đây chỉ chạy lại V5 cho crop thay đổi; không chạy lại YOLO. '
                   'Nhãn YOLO và kết quả ban đầu luôn được giữ riêng.')
        if st.session_state.get('cond_box_notice'):
            st.success(st.session_state.pop('cond_box_notice'))
        target = _seed_controls(workspace)
        preview = st.session_state.get('cond_box_preview')
        if preview is None:
            preview = preview_data(image)
            st.session_state['cond_box_preview'] = preview
        draft = [st.session_state['cond_box_'+name] for name in ('x1','y1','x2','y2')]
        event = render_box_canvas(preview, image.size, workspace, target or None, draft,
                                 key='cond_box_canvas_'+workspace['analysis_id'])
        event = validate_canvas_event(event, workspace, image.size)
        if event and event['kind'] == 'region' and event['target_id'] != target:
            event = None
        if event and event['event_id'] != st.session_state.get('cond_box_event_seen'):
            st.session_state['cond_box_event_seen'] = event['event_id']
            if event['kind'] == 'select':
                st.session_state['cond_box_selected'] = event['object_id']
                target = _seed_controls(workspace)
            else:
                for name,value in zip(('x1','y1','x2','y2'),event['bbox']):
                    st.session_state['cond_box_'+name] = value
            st.rerun()
        ids = [r['object_id'] for r in workspace['objects']]
        target = st.selectbox('Box cần chỉnh sửa', [0] + ids, key='cond_box_selected',
            format_func=lambda value: '＋ Thêm box mới' if value == 0 else
                f'Box {value:02d} · ' + ('Thêm thủ công' if _row(workspace,value).get('origin') == 'manual'
                                       else (_row(workspace,value).get('yolo_label') or 'YOLO')))
        if st.session_state['cond_box_bound'][2] != target:
            # A new target needs seeded coordinates before its inputs are rendered.
            st.rerun()
        columns = st.columns(4)
        coords = [column.number_input(label, min_value=0, max_value=int(limit), step=1, key='cond_box_'+name)
                  for column,label,name,limit in zip(columns,('Trái (x1)','Trên (y1)','Phải (x2)','Dưới (y2)'),
                       ('x1','y1','x2','y2'),(image.width,image.height,image.width,image.height))]
        row = _row(workspace,target)
        if row and row.get('yolo_label'):
            st.caption(f'YOLO gốc: {row["yolo_label"]} · ID gốc {row.get("yolo_object_id",target)}. '
                       'Chọn tên bên dưới là xác nhận của người dùng, không đổi nhãn YOLO.')
        confirmation = st.selectbox('Nguyên liệu người dùng xác nhận',
            [''] + workspace['original_analysis']['supported_ingredients'], key='cond_box_ingredient',
            format_func=lambda name: 'Chưa chọn / giữ tham chiếu hiện tại' if not name else food_name(name))
        confirmed = st.checkbox('Tôi xác nhận vùng chọn là nguyên liệu đã chọn để chạy V5', key='cond_box_confirm')
        if not target:
            st.caption('Thêm box: kéo vùng trên ảnh (hoặc nhập tọa độ), chọn nguyên liệu và đánh dấu xác nhận.')
        elif row and not row.get('supported'):
            st.info('Box đang ngoài phạm vi. Có thể sửa vùng mà chưa phân loại; để chạy V5, chọn nguyên liệu và xác nhận thủ công.')
        first,second,third = st.columns(3)
        apply = first.button('Thêm box và phân tích V5' if not target else 'Áp dụng vùng / xác nhận',
                             type='primary', key='cond_box_apply')
        remove = second.button('Loại box đã chọn', disabled=not target, key='cond_box_delete')
        restore = third.button('Khôi phục box YOLO ban đầu', key='cond_box_restore')
        try:
            if apply:
                if confirmation and not confirmed:
                    raise ValueError('Hãy đánh dấu xác nhận trước khi dùng nguyên liệu đã chọn.')
                if not target and not (confirmation and confirmed):
                    raise ValueError('Box mới cần chọn nguyên liệu và xác nhận thủ công.')
                classifier = load_condition_model()
                with st.spinner('Đang cập nhật crop thay đổi…'):
                    updated, changed = update_box(workspace,image,classifier,target or None,coords,
                                                 confirmation or None,confirmed)
                if changed:
                    _commit(updated,changed,f'Đã cập nhật box {changed[0]:02d}. Các box khác giữ nguyên kết quả.')
                else:
                    st.info('Vùng và tham chiếu không thay đổi; không chạy lại V5.')
            if remove:
                _commit(delete_box(workspace,target),[target],f'Đã loại box {target:02d}; YOLO gốc vẫn được lưu.')
            if restore:
                all_ids = [r['object_id'] for r in workspace['objects']]
                _commit(restore_boxes(workspace),all_ids,'Đã khôi phục box và kết quả YOLO/V5 ban đầu; không chạy lại model.')
        except (ValueError, RuntimeError, ImportError) as error:
            st.error(str(error))
