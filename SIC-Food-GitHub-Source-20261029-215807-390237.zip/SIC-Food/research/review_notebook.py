"""Resumable Jupyter reviewer using IPython display and plain input; no widget dependency."""
import copy
from pathlib import Path
from PIL import ImageDraw
from .real_world_test import (inventory, latest_annotation, read_json, image_rgb,
                              save_annotation, STATES)


def review(data, ingredients, run=None, start=0, input_fn=input, display_fn=None):
    if display_fn is None:
        from IPython.display import display
        display_fn = display
    images = inventory(data)['images']
    frozen = read_json(Path(run)/'frozen.json') if run else None
    print('Ground truth is entered manually. AI labels are never copied into the form.')
    print('Ingredients:', ', '.join([*ingredients,'out_of_scope']))
    print('States:', ', '.join(STATES))
    index = start
    while 0 <= index < len(images):
        im = images[index]
        record = copy.deepcopy(latest_annotation(data,im['image_id']) or dict(
            image_id=im['image_id'],image_sha256=im['sha256'],status='draft',reviewer='',
            actual_count=None,bbox_complete=False,objects=[],detection_reviews=[],
            source_provenance='',capture_session=''))
        picture = image_rgb(Path(data)/'images'/im['path'])
        display_fn(picture)
        annotated = picture.copy(); draw = ImageDraw.Draw(annotated)
        boxes = [c for c in frozen['crops'] if c['image_id']==im['image_id']] if frozen else []
        for number,c in enumerate(boxes,1):
            draw.rectangle(c['bbox'],outline='red',width=3)
            draw.text(c['bbox'][:2],f"AI {number}: {c['original_label']}",fill='red',stroke_width=1,stroke_fill='white')
        for obj in record['objects']:
            if obj.get('bbox'):
                draw.rectangle(obj['bbox'],outline='lime',width=2)
                draw.text(obj['bbox'][:2],f"GT {obj['id']}: {obj['ingredient']}",fill='green')
        display_fn(annotated)
        print(f'{index+1}/{len(images)} {im["path"]} [{im["width"]} x {im["height"]}]')
        print(record)
        print('Commands: count, object, delete, boxes, source, decision, save, approve, next, prev, quit')
        command = input_fn('Command: ').strip().lower()
        if command=='quit': return
        if command=='next': index += 1; continue
        if command=='prev': index=max(0,index-1); continue
        reason = ''
        if record['status']=='reviewed':
            reason = input_fn('Reason for explicit correction of reviewed label (blank cancels): ').strip()
            if not reason: continue
        try:
            if command=='count':
                record['actual_count']=int(input_fn('Actual object count (include missed objects): '))
            elif command=='object':
                obj_id=input_fn('Manual object ID (e.g. gt001; same ID edits): ').strip()
                name=input_fn('True ingredient (no AI default): ').strip()
                state=input_fn('True condition (or uncertain): ').strip()
                raw=input_fn('GT bbox x1,y1,x2,y2 in displayed original pixels; blank = unknown: ').strip()
                obj=dict(id=obj_id,ingredient=name,condition=state,bbox=[float(v) for v in raw.split(',')] if raw else None)
                record['objects']=[o for o in record['objects'] if o['id']!=obj_id]+[obj]
            elif command=='delete':
                obj_id=input_fn('GT ID to remove: ').strip()
                record['objects']=[o for o in record['objects'] if o['id']!=obj_id]
                record['detection_reviews']=[r for r in record['detection_reviews'] if r.get('gt_id')!=obj_id]
            elif command=='boxes':
                record['bbox_complete']=input_fn('Every real object has an accurate GT bbox? type yes: ').strip()=='yes'
            elif command=='source':
                record['source_provenance']=input_fn('Source / collection details: ').strip()
                record['capture_session']=input_fn('Capture session or group ID: ').strip()
            elif command=='decision':
                if not frozen or frozen['scope']!='fully_automatic':
                    print('Open an automatic frozen run to review detections.'); continue
                number=int(input_fn('AI box number shown in red: '))
                if not 1 <= number <= len(boxes): raise ValueError('Unknown AI box')
                c=boxes[number-1]
                choice=input_fn('valid / duplicate / false_positive / uncertain: ').strip()
                gt_id=input_fn('Matched manual GT ID (required for valid): ').strip()
                record['detection_reviews']=[r for r in record['detection_reviews'] if not (r['run_id']==frozen['run_id'] and r['detection_id']==c['id'])]
                record['detection_reviews'].append(dict(run_id=frozen['run_id'],detection_id=c['id'],decision=choice,gt_id=gt_id))
            elif command not in ('save','approve'):
                continue
            record['status']='reviewed' if command=='approve' else 'draft'
            if command=='approve':
                record['reviewer']=input_fn('Reviewer name: ').strip()
                if input_fn('Confirm every real object was independently labeled; type yes: ').strip()!='yes': continue
            save_annotation(data,record,im,ingredients,reason)
            print('Saved new revision. Previous versions retained.')
        except (ValueError,KeyError) as e:
            print('Not saved:',e)
