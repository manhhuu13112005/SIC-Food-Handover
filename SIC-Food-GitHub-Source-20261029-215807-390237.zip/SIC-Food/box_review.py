"""Transactional, session-only box review. Never re-run YOLO or mutate its snapshot."""
from copy import deepcopy
from datetime import datetime, timezone
import math
from uuid import uuid4

from ingredient_pipeline import (classify_object, crop_bounds, summarize_objects,
                                 validate_classifier, validate_settings)


def start_review(analysis, image_token):
    objects = deepcopy(analysis['objects'])
    for row in objects:
        row.update(origin='yolo', yolo_object_id=row['object_id'], geometry_edited=False,
                   manual_confirmation=None, crop_revision=0)
    return {'analysis_id': uuid4().hex, 'image_token': image_token, 'revision': 0,
            'original_analysis': deepcopy(analysis), 'objects': objects,
            'next_object_id': max((r['object_id'] for r in objects), default=0)+1,
            'removed_objects': [], 'history': []}


def _event(workspace, action, **details):
    workspace['revision'] += 1
    workspace['history'].append({'revision': workspace['revision'], 'action': action,
        'at_utc': datetime.now(timezone.utc).isoformat(), **details})


def _find(workspace, object_id):
    return next((r for r in workspace['objects'] if r['object_id'] == object_id), None)


def _checked_bbox(bbox, image_size):
    # Reject out-of-image user coordinates instead of silently changing their intent.
    if not isinstance(bbox, (list, tuple)) or len(bbox) != 4:
        raise ValueError('Cần bốn tọa độ vùng chọn.')
    if not all(isinstance(v, (int, float)) and not isinstance(v, bool) and math.isfinite(v) for v in bbox):
        raise ValueError('Tọa độ phải là số hữu hạn.')
    x1, y1, x2, y2 = bbox
    width, height = image_size
    if not (0 <= x1 < x2 <= width and 0 <= y1 < y2 <= height):
        raise ValueError('Vùng chọn phải nằm trong ảnh và có chiều rộng/cao lớn hơn 0.')
    return list(crop_bounds(bbox, image_size, 0))


def update_box(workspace, image, classifier, object_id, bbox,
               confirmed_ingredient=None, user_confirmed=False):
    """Apply exactly one changed crop; unchanged results remain byte-for-byte intact.

    object_id=None adds a manual region. Unsupported YOLO labels need an explicit
    manual confirmation; that assertion is recorded, never substituted for YOLO.
    """
    supported = validate_classifier(classifier)
    settings = workspace['original_analysis']['settings']
    validate_settings(settings)
    box = _checked_bbox(bbox, image.size)
    old = _find(workspace, object_id) if object_id is not None else None
    if object_id is not None and old is None:
        raise ValueError('Box đã bị xóa hoặc không tồn tại.')
    if confirmed_ingredient is not None and (not user_confirmed or confirmed_ingredient not in supported):
        raise ValueError('Cần xác nhận thủ công một nguyên liệu thuộc 19 loại V5.')
    if old is None and len(workspace['objects']) >= settings['max_detections']:
        raise ValueError('Đã đạt giới hạn số box; xóa box không liên quan trước khi thêm.')
    reference = confirmed_ingredient or ((old or {}).get('manual_confirmation') or {}).get('ingredient')
    reference = reference or (old.get('yolo_ingredient') if old else None)
    if reference is None and old is None:
        raise ValueError('Box ngoài phạm vi hoặc box mới cần xác nhận nguyên liệu trước khi chạy V5.')
    current_confirmation = (old or {}).get('manual_confirmation')
    current_reference = (current_confirmation or {}).get('ingredient') or (old or {}).get('yolo_ingredient')
    new_crop = list(crop_bounds(box, image.size, settings['padding']))
    if old and old['crop_xyxy'] == new_crop and current_reference == reference:
        if confirmed_ingredient and not current_confirmation:
            result = deepcopy(workspace)
            row = _find(result,object_id)
            row['manual_confirmation'] = {'ingredient':confirmed_ingredient,'confirmed':True,
                                          'at_utc':datetime.now(timezone.utc).isoformat()}
            _event(result,'confirm_ingredient',object_id=object_id,
                   manual_confirmation=deepcopy(row['manual_confirmation']),inference_reused=True)
            return result,[object_id]
        return workspace, []
    result = deepcopy(workspace)
    if old is None:
        object_id = result['next_object_id']
        result['next_object_id'] += 1
        row = {'object_id': object_id, 'bbox_xyxy': box, 'yolo_label': None,
               'yolo_score': None, 'class_id': None, 'yolo_ingredient': None,
               'origin': 'manual', 'yolo_object_id': None, 'geometry_edited': False,
               'manual_confirmation': None, 'crop_revision': 0}
    else:
        row = deepcopy(old)
        row['bbox_xyxy'] = box
        original = _find({'objects': result['original_analysis']['objects']}, object_id)
        row['geometry_edited'] = row['origin'] == 'yolo' and (not original or box != original['crop_xyxy'])
    if confirmed_ingredient is not None:
        row['manual_confirmation'] = {'ingredient': confirmed_ingredient, 'confirmed': True,
                                      'at_utc': datetime.now(timezone.utc).isoformat()}
    row = classify_object(image, row, classifier, settings, reference)
    row['crop_revision'] += 1
    if old:
        result['objects'] = [row if r['object_id'] == object_id else r for r in result['objects']]
    else:
        result['objects'].append(row)
    _event(result, 'add_box' if old is None else 'update_box', object_id=object_id,
           bbox_before=old['bbox_xyxy'] if old else None, bbox_after=box,
           manual_confirmation=deepcopy(row['manual_confirmation']), inference_status=row['status'])
    return result, [object_id]


def delete_box(workspace, object_id):
    row = _find(workspace, object_id)
    if row is None:
        raise ValueError('Box đã bị xóa hoặc không tồn tại.')
    result = deepcopy(workspace)
    result['objects'] = [r for r in result['objects'] if r['object_id'] != object_id]
    result['removed_objects'].append(deepcopy(row))
    _event(result, 'delete_box', object_id=object_id, removed=deepcopy(row))
    return result


def restore_boxes(workspace):
    initial = start_review(workspace['original_analysis'], workspace['image_token'])
    # Analysis identity and monotonically increasing IDs/revision survive restore.
    initial.update(analysis_id=workspace['analysis_id'], next_object_id=workspace['next_object_id'],
                   revision=workspace['revision'], history=deepcopy(workspace['history']))
    _event(initial, 'restore_yolo')
    return initial


def export_review(workspace, edits=None):
    from ingredient_pipeline import effective_result
    edits = edits or {}
    active_ids = {str(r['object_id']) for r in workspace['objects']}
    return {'schema_version': 2, 'analysis_id': workspace['analysis_id'],
        'image_token': workspace['image_token'], 'revision': workspace['revision'],
        'original_yolo_analysis': deepcopy(workspace['original_analysis']),
        'working_objects': deepcopy(workspace['objects']),
        'working_summary': summarize_objects(workspace['objects']),
        'removed_objects': deepcopy(workspace['removed_objects']), 'history': deepcopy(workspace['history']),
        'user_edits': {k:deepcopy(v) for k,v in edits.items() if k in active_ids},
        'effective_results': [{'object_id':r['object_id'], **effective_result(r, edits.get(str(r['object_id'])))}
                              for r in workspace['objects']]}


def validate_canvas_event(event, workspace, image_size):
    """Treat browser payloads as untrusted and reject stale analysis/revision data."""
    if not isinstance(event, dict):
        return None
    if (event.get('analysis_id') != workspace['analysis_id'] or event.get('revision') != workspace['revision']
            or event.get('image_token') != workspace['image_token']):
        return None
    nonce = event.get('event_id')
    if not isinstance(nonce, str) or not 1 <= len(nonce) <= 100:
        return None
    if event.get('kind') == 'select':
        object_id = event.get('object_id')
        if isinstance(object_id, int) and not isinstance(object_id, bool) and _find(workspace, object_id):
            return {'event_id': nonce, 'kind': 'select', 'object_id': object_id}
    if event.get('kind') == 'region':
        target = event.get('target_id',0)
        if not isinstance(target,int) or isinstance(target,bool) or (target != 0 and not _find(workspace,target)):
            return None
        try:
            box = _checked_bbox(event.get('bbox'), image_size)
        except (ValueError, TypeError):
            return None
        return {'event_id': nonce, 'kind': 'region', 'bbox': box, 'target_id':target}
    return None
