# Đánh giá SIC-Food — 28/10/2026

## Kết luận

Dự án hiện có một website Streamlit chạy được trên CPU và một nhánh nghiên cứu dữ liệu/model đã tiến tới V6. Website đủ cho demo các luồng chính đã kiểm thử. Chưa đủ bằng chứng để xem đây là hệ thống đánh giá chất lượng thực phẩm đã được kiểm định hoặc sản phẩm dinh dưỡng có dữ liệu chuẩn hóa.

Khoảng cách lớn nhất nằm ở chất lượng dữ liệu, đánh giá độc lập và đồng bộ phiên bản nghiên cứu với website. V6 mới hơn nhưng chưa chứng minh tốt hơn V5. Không nên thay checkpoint website chỉ vì số phiên bản cao hơn.

## Phạm vi và giới hạn rà soát

- Mã ứng dụng tại project root, 7 script trong scripts/, 2 script fast-track, bộ tests/, cấu hình JSON/TOML, README và báo cáo liên quan.
- Kiểm tra cú pháp toàn bộ 34 file Python trong root/scripts/tests/efficientnet_37_fasttrack.
- Khảo sát 10 notebook tại root; đọc các luồng chuẩn bị dữ liệu, huấn luyện, đánh giá và audit liên quan, đối chiếu output lưu với manifest/checkpoint/CSV thực tế. Kiểm tra AST các cell Python thuần; bỏ qua cell chứa lệnh magic/shell. Không chạy lại notebook vì có thao tác tải dữ liệu/huấn luyện/ghi đè báo cáo.
- Phân biệt mã hiện hành với backups/, handover/, SIC-Food-Handover-GitHub/ và _handover_tools/. Các bản đóng gói/lịch sử không được coi là nguồn chạy hiện tại; chưa so sánh từng dòng của mọi bản sao.
- Không duyệt trực quan từng ảnh trong toàn bộ dataset, không huấn luyện lại, không chạy đánh giá đầy đủ hàng nghìn ảnh. Số liệu V5/V6 dưới đây là kết quả đã lưu, không phải một lần đánh giá mới.
- Không sửa code chức năng, notebook, checkpoint hoặc dữ liệu dinh dưỡng. Thêm báo cáo này và dùng thư mục reports/runtime_audit_tmp cho kiểm thử.

## Kiến trúc đang hoạt động

| Thành phần | Hiện trạng |
| --- | --- |
| main.py | Trang chủ và điều hướng ba trang |
| page1.py + page2.py | YOLO nhận diện ảnh hoặc một frame video; sửa món, nhập gram, tính khẩu phần |
| condition_page.py | EfficientNet phân loại ảnh một nguyên liệu/crop; Top-3 và cảnh báo điểm thấp |
| detection_service.py | Giữ từng bounding box riêng; khóa inference khi dùng model cache chung |
| condition_service.py | Nạp checkpoint, kiểm tra nhãn/shape, preprocessing, softmax, inference CPU |
| nutrition_service.py | Tính per_100g × grams / 100; kiểm tra hồ sơ, xác nhận và dữ liệu thiếu |
| app_state.py | Giữ input/kết quả/sửa khẩu phần trong session; reset khi đổi input |
| scripts/ và notebook | Chuẩn bị/crop dữ liệu, kiểm tra trùng, duyệt nhãn, huấn luyện và so sánh model |

Website hiện không nối tự động YOLO → EfficientNet. Hàm classify_detections còn được giữ cho caller offline/legacy, nhưng không nằm trong luồng website mặc định. Video chỉ phân tích frame được chọn, chưa tracking hay xử lý toàn bộ video.

## Những phần đã hoàn thành

1. Giao diện tiếng Việt, upload ảnh/video, preview, bounding box đánh số, nhập món thủ công và xuất JSON khẩu phần.
2. YOLO thực tế có 214 nhãn; giữ nhiều box cùng tên thành nhiều mục riêng.
3. EfficientNet website có 37 lớp, đọc thứ tự lớp từ checkpoint; đúng preprocessing fast-track, strict load, eval/inference_mode và cache.
4. Hai module có thể hoạt động độc lập khi model còn lại thiếu/hỏng. Có thông báo lỗi và chế độ nhập món thủ công khi YOLO không dùng được.
5. Giới hạn ảnh 20 MB/25 triệu pixel; kiểm tra nội dung ảnh, EXIF và RGB; giới hạn video 64 MB.
6. Công thức dinh dưỡng có chặn gram không hợp lệ, không tự điền dữ liệu thiếu bằng 0, đánh dấu tổng chưa đầy đủ và yêu cầu chấp nhận dữ liệu chưa kiểm chứng.
7. Công cụ dataset có SHA256/pHash, nhóm nguồn, kiểm tra ZIP, crop và báo cáo cách ly. Đây là nền tảng nghiên cứu đáng kể, dù chất lượng nhãn chưa hoàn tất.
8. Đã huấn luyện checkpoint V5 và V6 38 lớp. V6 bổ sung 163 ảnh pork vào train sau các bước lọc; có bảng so sánh theo lớp với V5.
9. Đã có quy trình audit thủ công, điều tra nhóm beef/chicken và xuất manifest ứng viên sau cách ly.

## Kiểm tra thực thi trong lần rà soát này

| Kiểm tra | Kết quả mới |
| --- | --- |
| AST 34 file Python | Đạt |
| 48 test logic/dataset/image/model/service | Đạt, khoảng 15,7 giây; đặt TEMP/TMP trong workspace |
| 3 test AppTest giao diện | Đạt ngoài sandbox, đặt default_timeout=30 trong tiến trình kiểm tra; khoảng 4,6 giây |
| Model YOLO thật + ảnh mẫu | Nạp được; 5 box: Waffle, Pasta, Banana, Avocado, Avocado |
| Model YOLO thật + video mẫu frame 0 | Nạp/đọc được; 2 box |
| EfficientNet website thật | Nạp được; đầu ra 37 lớp; predict hoạt động |
| Checkpoint V5/V6 | Đọc metadata được, đều 38 lớp, epoch 2 |
| Manifest V5 | Train 33.354, val 3.407; không thiếu file; giao đường dẫn/SHA256 lưu trong manifest bằng 0 |
| Manifest V6 | Train 33.517, val 3.407; không thiếu file; giao đường dẫn/SHA256 lưu trong manifest bằng 0 |

Lệnh discover nguyên bản trong sandbox phát sinh lỗi thư mục tạm/codec và treo ở AppTest, nên đã dừng. Khi chạy 48 test với thư mục tạm được phép ghi, các lỗi đó không tái xuất hiện. Ba test UI chạy ngoài sandbox ban đầu có 1 timeout ở mức mặc định 3 giây; cả 3 đạt khi đặt mặc định 30 giây trong runner. Đây là khác biệt điều kiện chạy, không phải sửa test rồi tuyên bố mã gốc luôn đạt. Stack trace synthetic inference trong test là lỗi được cố ý mô phỏng.

Chưa kiểm tra lại website bằng trình duyệt thật trong lần này. Ảnh chụp và kết quả browser tại docs/website_validation.md là bằng chứng lịch sử ngày 17/10, không phải kết quả mới ngày 28/10.

## Các vấn đề ưu tiên

### 1. Dữ liệu và tiêu chí chất lượng chưa chốt — ưu tiên cao nhất

Manifest train V5 còn 22.772 dòng legacy_unverified và 10.582 pending. V6 kế thừa các dòng đó và thêm 163 approved. Nhãn trạng thái cũ trên manifest có thể chưa phản ánh quyết định trong bảng audit riêng, vì vậy không thể kết luận tất cả các dòng này chưa từng được xem. Tuy nhiên chưa có một manifest cuối cùng hợp nhất rõ ràng toàn bộ quyết định duyệt/cách ly.

reports/dataset_audit/audit_quarantine_summary.csv ghi 32 mẫu chicken train và 29 mẫu beef validation được cách ly trong các file clean_candidate. Nhóm chicken 400 mẫu còn 368 needs_review; 29 exclude_from_large_cut_dataset, 2 needs_condition_verification, 1 exclude_bad_image.

Điều tra cuối phân biệt unsuitable_shape với sai trạng thái: nhiều mẫu không phù hợp mục tiêu thịt miếng lớn, không đồng nghĩa toàn bộ mẫu bị sai nhãn tươi/hỏng. Cần xác định sản phẩm phục vụ mọi hình dạng thực phẩm hay chỉ một nhóm hình dạng trước khi quyết định loại dữ liệu.

Notebook V6 đang huấn luyện bằng train_manifest_v6_candidate.csv và val_manifest_v6_unchanged.csv, không dùng các file clean_candidate mới trong reports/dataset_audit/. Chưa có bằng chứng từ checkpoint/history cho thấy model đã được huấn luyện lại sau audit.

Việc cần làm: hợp nhất quyết định audit vào manifest có phiên bản; xử lý nhóm chưa duyệt; kiểm tra nhóm nguồn và gần trùng; cố định test độc lập. Không xem giao SHA256 bằng 0 là đủ để chứng minh độc lập theo phiên chụp/nguồn.

### 2. V6 chưa vượt V5; một số lớp còn yếu

| Model nghiên cứu | Validation accuracy lưu | Macro-F1 lưu |
| --- | ---: | ---: |
| V5 38 lớp | 98,4150% | 0,96984 |
| V6 38 lớp | 98,3270% | 0,96750 |

Các số này dùng validation provisional 3.407 ảnh; không phải độ chính xác ngoài thực tế hoặc test độc lập cuối cùng.

Theo bảng so sánh: hai lớp pork không cải thiện F1; eggplant normal khoảng 0,6047 → 0,5833; eggplant defect khoảng 0,8189 → 0,7967; onion defect khoảng 0,8889 → 0,8571. Shrimp normal tăng khoảng 0,8475 → 0,8621 nhưng support chỉ 30 ảnh. Cần chọn model theo chất lượng từng lớp và tập đánh giá phù hợp, không chỉ accuracy tổng.

### 3. Website và model nghiên cứu chưa tương thích

model_loader.py mặc định checkpoint 37 và gọi expected_classes=37. condition_service.py yêu cầu metadata fast-track training_type=prototype_frozen_backbone và pretrained_weights=IMAGENET1K_V1 khi gặp model_state_dict.

Checkpoint V5 dùng provisional_head_training; V6 dùng v6_head_finetuning; cả hai không có trường pretrained_weights phù hợp loader hiện hành. Chỉ đổi SIC_CONDITION_MODEL_PATH sang V5/V6 sẽ không đủ.

Preprocessing V5/V6 trong notebook là Resize((224,224)); model 37 dùng Resize cạnh ngắn 256 + CenterCrop 224. Adapter model phải lưu và chọn đúng preprocessing theo phiên bản. Giao diện/README/test cũng đang gắn số 37.

V5/V6 có 19 nguyên liệu × 2 trạng thái, có tôm nhưng không có broccoli. Đây là thay đổi tập nhãn, không đơn thuần thêm một lớp vào 37 lớp cũ.

### 4. Dinh dưỡng thiếu nguồn và có lỗi ID cụ thể

47/47 hồ sơ có verification_status=unverified và preparation_state=unknown. Chọn raw hoặc cooked không tìm được hồ sơ phù hợp hiện tại. Các nguyên liệu pork, shrimp, cabbage, mushroom chưa có hồ sơ.

Lỗi xác nhận bằng mã/data: map_label('Bell pepper') trả ingredient_id=bell_pepper; hồ sơ sẵn có là legacy_bell pepper với ingredient_id='bell pepper'. Bộ lọc page1.py so sánh ID chính xác nên kết quả YOLO ớt chuông không truy ra hồ sơ này; catalog còn đồng thời chứa cả hai ID.

Chỉ 43/214 tên nhãn YOLO khớp class_mapping hiện tại sau lower/strip. Đây là độ phủ ánh xạ, không phải 43/214 đo accuracy. Phần còn lại thường về unknown và cần người dùng chọn lại món nếu có trong catalog.

Việc cần làm: chuẩn hóa ID/alias, bổ sung kiểm tra liên kết catalog–mapping–profile, thêm nguồn dinh dưỡng và trạng thái chế biến rõ ràng. Không tự thay dữ liệu bằng số ước đoán.

### 5. Khả năng tái lập và bảo trì

- runtime.txt ghi Python 3.10.12; devcontainer dùng 3.11; README mô tả môi trường sic-food 3.11. Cần thống nhất môi trường chạy được hỗ trợ.
- requirements.txt không khóa phần lớn phiên bản; không khai báo đầy đủ nhu cầu nghiên cứu như pandas/tqdm/scikit-learn/scipy/ipywidgets. Nên tách dependency runtime và research, kèm môi trường đã xác nhận.
- Đường dẫn tuyệt đối Windows xuất hiện nhiều trong notebook/script; SIC_Food_System_Test.ipynb đang kiểm tra bản SIC-Food-Handover-GitHub/SIC-Food, không kiểm tra root hiện tại, và chủ yếu kiểm tra file/thư viện tồn tại.
- Không có Git tại root. Nhiều bản sao và manifest các stage làm khó xác định nguồn chuẩn. Cần version control cho code/config, chính sách riêng cho weights/dataset lớn, và model registry/manifest phiên bản.
- .gitignore hiện bỏ models/*.pt nhưng không bao phủ các checkpoint .pth và mô hình lồng sâu; cần rà soát trước khi đưa dự án vào Git để tránh thêm nhầm dữ liệu lớn.
- README và docs website vẫn mô tả mốc 37 lớp ngày 17/10; cần bổ sung trạng thái nghiên cứu V5/V6 và audit mới, giữ rõ model nào đang phục vụ.
- Test UI dùng mặc định 3 giây cho nhiều lần .run(); lần này đã có timeout thực tế. Nên đặt thời gian chờ nhất quán để bộ test dễ tái lập.

### 6. Giới hạn tính năng hiện tại

Chưa có tài khoản/lưu lịch sử bền vững/database người dùng; session RAM có thể mất khi tải lại hoặc restart. Chưa có nút xóa từng món trong khẩu phần; chỉ có bỏ chọn include hoặc reset input. Chưa có crop tương tác ở trang trạng thái, tracking video, định lượng gram từ ảnh hoặc phát hiện ảnh ngoài tập nhãn. Các mục này cần ưu tiên theo mục tiêu sản phẩm, không mặc định tất cả đều là lỗi phải sửa ngay.

Ngưỡng softmax 0,6 chưa được hiệu chỉnh; không có OOD. Ảnh ngoài phạm vi vẫn có thể nhận điểm cao. Dự đoán trạng thái hình ảnh chưa đủ căn cứ kết luận an toàn thực phẩm.

## Thứ tự khắc phục đề xuất

1. Chốt phạm vi sản phẩm và tiêu chí nhãn/hình dạng; chọn code/model/dataset chuẩn, đưa code vào quản lý phiên bản.
2. Sửa lỗi ID ớt chuông và kiểm tra toàn vẹn catalog–mapping–nutrition; ổn định môi trường/test.
3. Hợp nhất audit, xử lý nhóm chicken chưa duyệt, cố định train/val/test và dữ liệu nguồn độc lập.
4. Đánh giá lại V5/V6 theo lớp trên dữ liệu sau audit; xử lý eggplant, shrimp normal và nhóm ít mẫu; chọn model đủ bằng chứng.
5. Xây contract checkpoint có version và preprocessing; cập nhật loader/UI/test để tích hợp model được chọn.
6. Chuẩn hóa nguồn dinh dưỡng, bổ sung trạng thái raw/cooked và nguyên liệu còn thiếu.
7. Sau đó mới mở rộng lưu lịch sử, crop tương tác, xử lý video và triển khai cho nhiều người dùng theo nhu cầu.
