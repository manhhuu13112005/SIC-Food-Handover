# Checkpoint được chia sẻ riêng

Gói source không chứa model weights hoặc dataset.

| Mục đích | Đường dẫn đặt file |
|---|---|
| YOLO Detection 214 nhãn, website hai module | `best.pt` ở thư mục gốc |
| EfficientNet B0 V5 38 lớp, website Module 2 | `models/efficientnet_v5_38/efficientnet_b0_38_prototype_head.pth` |
| EfficientNet B0 V6 38 lớp, chỉ so sánh offline | `models/efficientnet_v6_38/efficientnet_b0_38_v6_head.pth` |
| Legacy 37 lớp, chỉ nghiên cứu cũ | `models/efficientnet_37_fasttrack/efficientnet_b0_37_prototype.pth` |

Để chạy website chỉ cần YOLO và V5; V6/legacy là tùy chọn nghiên cứu.
Lấy đúng file từ người quản lý dự án. Không thay V5 bằng V6 bằng cách đổi tên file.
Có thể cấu hình đường dẫn qua SIC_MODEL_PATH / SIC_CONDITION_MODEL_PATH.
Module 2 yêu cầu SIC_CONDITION_MODEL_VERSION=v5 (mặc định).
Không cần train lại hoặc tải dataset để phục vụ suy luận.
