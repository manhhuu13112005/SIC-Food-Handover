"""Create a current source-only sharing folder + ZIP without changing project inputs."""
from pathlib import Path
import ast
import hashlib
import json
import re
import zipfile
from datetime import datetime

ROOT = Path(__file__).resolve().parents[1]

IGNORE = '''# Python, local environment and credentials
__pycache__/
*.py[cod]
.ipynb_checkpoints/
.venv/
venv/
env/
.conda/
.env
.env.*
!.env.example
.streamlit/secrets.toml
*.pem
*.key
.DS_Store
Thumbs.db
*.log
.idea/
.vscode/

# Local data, checkpoints and generated artifacts
datasets/
*.pt
*.pth
*.ckpt
*.onnx
*.safetensors
*.h5
*.hdf5
models/*
!models/README.md
runs/
reports/
training_results/
backups/
dist/
build/
*.egg-info/
handover/
_handover_tools/
SIC-Food-Handover-GitHub/
tests/manual_pipeline_images/
tests/efficientnet_37_images/
node_modules/
*.zip
*.7z
*.rar
*.tar
*.gz
'''

README = '''# SIC-Food — source chia sẻ cho nhóm

Bản source nhẹ của dự án hiện tại, gồm website, notebook, test và công cụ nghiên cứu.
Không chứa dataset, checkpoint, cache, môi trường Python, ảnh/video kiểm thử thực tế,
backup, kết quả training hoặc các bản ZIP bàn giao cũ.

## Hiện trạng

- **Module 1:** YOLO nhận diện món ăn trong ảnh/video; xác nhận món, nhập gram, tính dinh dưỡng và xuất JSON.
- **Module 2:** một luồng YOLO → box → crop → EfficientNet B0 **V5**, 38 lớp/19 nguyên liệu.
  Có thêm/sửa/xóa/khôi phục box, giữ riêng kết quả YOLO gốc và xác nhận thủ công.
- **Nghiên cứu:** so sánh V5/V6 offline trên crop chung, Jupyter kiểm duyệt GT, kiểm tra trùng dữ liệu và xuất chỉ số.
  Website vẫn dùng V5. Bộ Test độc lập mới chưa có ảnh/nhãn, chưa kết luận model nào tốt hơn và chưa train tiếp.
- Dữ liệu dinh dưỡng/config JSON là dữ liệu cần cho ứng dụng, được giữ trong bản này.

## Cấu trúc

```text
main.py                       Điểm chạy Streamlit
page1.py, page2.py             Module 1
condition_page.py             Module 2
ingredient_pipeline.py        YOLO → crop → V5
box_review.py, box_editor*    Quản lý box và kết quả chỉnh sửa
components/box_editor/        HTML/CSS/JS local của canvas
*_service.py, model_loader.py Xử lý ảnh, model, dinh dưỡng
config/                       Cấu hình và hồ sơ dinh dưỡng
research/                     Công cụ Test độc lập V5/V6
scripts/                      Dataset, training và đóng gói (chỉ là source)
tests/                        Unit/AppTest, JavaScript và script kiểm tra thật
*.ipynb                       Notebook đã bỏ output trong bản sao
docs/                         Hướng dẫn và tài liệu lịch sử
models/README.md              Danh sách weights cần lấy riêng
SHARING_MANIFEST.json          Kiểm kê file/SHA-256 và phạm vi loại bỏ
```

## Chạy website trên Windows CPU

Dùng Python 3.11. Mở PowerShell tại thư mục có main.py:

```powershell
py -3.11 -m venv .venv
.venv\\Scripts\\python.exe -m pip install -r requirements.txt
.venv\\Scripts\\python.exe -m streamlit run main.py
```

Không cần dataset để chạy website. Không có weights thì xem giao diện và nhập món thủ công;
các chức năng AI cần lấy checkpoint riêng theo models/README.md. Ứng dụng không tự tải weights khi mở.
Các dependency chưa được khóa hoàn toàn; kết quả kiểm thử ở máy tác giả không bảo đảm mọi môi trường cài mới.

## Notebook và kiểm thử

```powershell
.venv\\Scripts\\python.exe -m pip install -r requirements-research.txt
.venv\\Scripts\\python.exe -m jupyterlab
.venv\\Scripts\\python.exe -m unittest discover -s tests -p "test_*.py" -v
node --test tests/box_editor_geometry.test.mjs
```

Notebook gốc giữ nguyên; bản chia sẻ chỉ bỏ output, execution count và widget state.
Một số notebook có ROOT/đường dẫn tuyệt đối của máy tác giả: sửa theo nơi bạn giải nén.
Không cần chạy notebook training để mở website. Các notebook tải dữ liệu/train/audit cần tài nguyên riêng;
không chạy tất cả cell nếu chỉ muốn đọc source.

Các test `test_*.py` dùng fixture/mock và không cần dataset hoặc weights thật.
Các script `check_*.py` và `evaluate_real_world.py smoke` cần weights và ảnh/video bên ngoài gói.
Xem docs/website_usage.md, docs/module2_box_editor_delivery.md và docs/real_world_test_v1_guide.md.
Các số liệu trong docs là kết quả lịch sử có phạm vi riêng; không phải accuracy mới của bản chia sẻ này.

## Đưa lên GitHub cho nhóm

1. Giải nén ZIP và mở thư mục **SIC-Food** có main.py.
2. Tạo repository trên GitHub; chọn **Private** nếu chỉ muốn các thành viên nhóm xem.
3. Dùng GitHub Desktop → File → Add local repository → chọn thư mục SIC-Food;
   nếu chưa là Git repository, chọn tạo repository tại thư mục này, rồi commit và Publish repository.
   Hoặc trên repository GitHub chọn Add file → Upload files và tải nội dung bên trong SIC-Food.
4. Kiểm tra có cả `.gitignore`; không cần đưa file ZIP lên repository.
5. Trong Settings → Collaborators, mời tài khoản GitHub của các bạn cùng nhóm.

Giữ .gitignore để dataset/model/cache không lọt vào các commit sau. Weights/dataset chia sẻ riêng qua
kho lưu trữ của nhóm; chưa có đường dẫn tải công khai V5/V6 được cấu hình trong gói.

## Tạo lại bản source nhẹ

```powershell
python scripts/package_github_source.py
```

Lệnh tạo thư mục và ZIP mới trong dist/, không xóa hoặc sửa dataset/model/source hiện có.
'''

MODELS = '''# Checkpoint được chia sẻ riêng

Gói source không chứa model weights hoặc dataset.

| Mục đích | Đường dẫn đặt file |
|---|---|
| YOLO Detection 214 nhãn, website hai module | `best.pt` ở thư mục gốc |
| EfficientNet B0 V5 38 lớp, website Module 2 | `models/efficientnet_v5_38/efficientnet_b0_38_prototype_head.pth` |
| EfficientNet B0 V6 38 lớp, chỉ so sánh offline | `models/efficientnet_v6_38/efficientnet_b0_38_v6_head.pth` |
| Legacy 37 lớp, chỉ nghiên cứu cũ | `models/efficientnet_37_fasttrack/efficientnet_b0_37_prototype.pth` |

Để chạy website chỉ cần YOLO và V5; V6/legacy là tùy chọn nghiên cứu.
Lấy đúng file từ người quản lý dự án. Không thay V5 bằng V6 bằng cách đổi tên file.
Có thể cấu hình đường dẫn qua SIC_MODEL_PATH / SIC_CONDITION_MODEL_PATH.
Module 2 yêu cầu SIC_CONDITION_MODEL_VERSION=v5 (mặc định).
Không cần train lại hoặc tải dataset để phục vụ suy luận.
'''


def build():
    entries, originals, notebooks = {}, {}, []

    def add(path, target=None):
        path = Path(path)
        payload = path.read_bytes()
        name = target or path.relative_to(ROOT).as_posix()
        entries[name] = payload
        originals[path] = hashlib.sha256(payload).hexdigest()

    for path in sorted(ROOT.glob('*.py')):
        add(path)
    for name in ('food_items.json','requirements.txt','.streamlit/config.toml'):
        add(ROOT/name)
    for folder, extensions in (
        ('components',{'.html','.css','.js','.mjs'}), ('research',{'.py'}),
        ('scripts',{'.py'}), ('tests',{'.py','.mjs'}),
        ('config',{'.json','.yaml','.yml'}), ('efficientnet_37_fasttrack',{'.py','.md'}),
        ('docs',{'.md','.json','.csv'}),
    ):
        for path in sorted((ROOT/folder).rglob('*')):
            rel=path.relative_to(ROOT)
            if not path.is_file() or path.suffix not in extensions:
                continue
            if any(p in {'__pycache__','node_modules','manual_pipeline_images','efficientnet_37_images'} for p in rel.parts):
                continue
            if path.name.startswith('state_sources_v4_before_'):
                continue
            add(path)
    if (ROOT/'tests/fixtures/invalid.png').exists():
        add(ROOT/'tests/fixtures/invalid.png')
    add(ROOT/'README.md','docs/website_usage.md')
    # Preserve a small research handover, not generated results/images/logs.
    phase_c=ROOT/'reports/real_world_test_v1/phase_c_delivery.md'
    if phase_c.exists():
        add(phase_c,'docs/phase_c_delivery_history.md')
    for path in sorted(ROOT.glob('*.ipynb')):
        if path.name=='Untitled.ipynb':
            continue
        raw=path.read_bytes(); originals[path]=hashlib.sha256(raw).hexdigest()
        document=json.loads(raw.decode('utf-8-sig'))
        document.get('metadata',{}).pop('widgets',None)
        for cell in document.get('cells',[]):
            cell['metadata']={}
            if cell['cell_type']=='code':
                cell['outputs']=[]; cell['execution_count']=None
        payload=(json.dumps(document,ensure_ascii=False,indent=1)+'\n').encode('utf-8')
        entries[path.name]=payload
        notebooks.append(dict(path=path.name,original_bytes=len(raw),shared_bytes=len(payload)))
    entries['README.md']=README.encode('utf-8')
    entries['.gitignore']=IGNORE.encode('utf-8')
    entries['models/README.md']=MODELS.encode('utf-8')
    entries['requirements-research.txt']=b'-r requirements.txt\npandas\nmatplotlib\nscikit-learn\nscipy\ntqdm\nipywidgets\nipykernel\njupyterlab\nImageHash\nkagglehub\n'
    patterns=[rb'hf_[A-Za-z0-9]{20,}',rb'gh[pousr]_[A-Za-z0-9]{20,}',
              rb'github_pat_[A-Za-z0-9_]{30,}',rb'AKIA[A-Z0-9]{16}',
              rb'AIza[A-Za-z0-9_-]{30,}',rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----',
              rb'(?i)(?:api[_-]?key|access[_-]?token|password|secret)\s*=\s*["\x27]([^"\x27\n]{12,})["\x27]']
    for name,payload in entries.items():
        if len(payload)>5*1024*1024:
            raise ValueError(f'Oversized source: {name}')
        if name.endswith('.py'):
            ast.parse(payload.decode('utf-8-sig'),filename=name)
        if name.endswith(('.py','.ipynb','.json','.yaml','.yml','.toml','.md','.txt')):
            if any(re.search(pattern,payload) for pattern in patterns):
                raise ValueError(f'Possible credential; inspect locally before sharing: {name}')
    for path,sha in originals.items():
        if hashlib.sha256(path.read_bytes()).hexdigest()!=sha:
            raise ValueError(f'Source changed during packaging: {path.name}')
    stamp=datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    destination=ROOT/'dist'/('SIC-Food-GitHub-Source-'+stamp)
    source=destination/'SIC-Food'
    source.mkdir(parents=True,exist_ok=False)
    manifest=dict(created_local=datetime.now().isoformat(),purpose='Current source-only team review',
        excluded=['datasets (all)','model weights and caches','images/video media','generated reports/logs',
                  'backups','old handover copies and archives','Python environments','notebook outputs','Untitled.ipynb'],
        originals_unchanged=True,notebooks=notebooks,
        files=[dict(path=n,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for n,b in sorted(entries.items())])
    entries['SHARING_MANIFEST.json']=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
    archive_path=destination.with_suffix('.zip')
    with zipfile.ZipFile(archive_path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name,payload in sorted(entries.items()):
            target=source/name; target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(payload)
            archive.writestr('SIC-Food/'+name,payload)
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist())==len(entries)
        for name,payload in entries.items():
            assert archive.read('SIC-Food/'+name)==payload
            assert not any(part in {'datasets','__pycache__','backups'} for part in Path(name).parts)
            assert Path(name).suffix not in {'.pt','.pth','.ckpt','.pyc','.zip','.mp4'}
        for item in notebooks:
            doc=json.loads(entries[item['path']]); original=json.loads((ROOT/item['path']).read_text(encoding='utf-8-sig'))
            assert [c['source'] for c in doc['cells']]==[c['source'] for c in original['cells']]
            assert all(not c.get('outputs') and c.get('execution_count') is None for c in doc['cells'] if c['cell_type']=='code')
    sha=hashlib.sha256(archive_path.read_bytes()).hexdigest()
    archive_path.with_suffix('.zip.sha256').write_text(f'{sha}  {archive_path.name}\n',encoding='ascii')
    result=dict(zip=str(archive_path),folder=str(source),file_count=len(entries),zip_bytes=archive_path.stat().st_size,
                source_bytes=sum(len(x) for x in entries.values()),notebook_original_bytes=sum(n['original_bytes'] for n in notebooks),
                notebook_shared_bytes=sum(n['shared_bytes'] for n in notebooks),sha256=sha,verification='PASS')
    (destination/'PACKAGE_VERIFICATION.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    build()
