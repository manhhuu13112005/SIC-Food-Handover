"""Read-only exact/pixel/perceptual duplicate audit with explicit coverage."""
import csv
import hashlib
from pathlib import Path
from .real_world_test import inventory, image_rgb, digest, identifier, write_json, write_csv

MANIFESTS = (
    'datasets/efficientnet_v5_38/train_manifest_stage45.csv',
    'datasets/efficientnet_v5_38/val_manifest_stage45.csv',
    'datasets/efficientnet_v6_38/train_manifest_v6_candidate.csv',
    'datasets/efficientnet_v6_38/val_manifest_v6_unchanged.csv',
)


def audit(data, output, project, max_references=None, radius=6, manifests=None):
    from scripts.bulk_state_dataset import phash, BKTree
    project = Path(project)
    inv = inventory(data)
    destination = Path(output)/'audits'/identifier()
    destination.mkdir(parents=True)
    sources, references, missing_manifests = [], {}, []
    for relative in MANIFESTS if manifests is None else manifests:
        path = project/relative
        if not path.exists():
            missing_manifests.append(str(path)); continue
        with path.open(encoding='utf-8-sig',newline='') as f:
            records = list(csv.DictReader(f))
        sources.append(dict(path=str(path),sha256=digest(path),rows=len(records)))
        for r in records:
            raw = r.get('path','')
            if not raw:
                continue
            p = Path(raw)
            if not p.is_absolute():
                p = project/p
            references.setdefault(str(p.resolve()),set()).add(str(path))
    matches, failures, examined = [], [], 0
    tree, by_hash, by_sha, by_pixel, test_phashes = BKTree(), {}, {}, {}, {}
    for row in inv['images']:
        image = image_rgb(Path(data)/'images'/row['path'])
        value = int(phash(image),16)
        test_phashes[row['image_id']] = value
        tree.insert(value)
        by_hash.setdefault(value,[]).append(row['image_id'])
        by_sha.setdefault(row['sha256'],[]).append(row['image_id'])
        by_pixel.setdefault(row['pixel_sha256'],[]).append(row['image_id'])
    # No need to read tens of thousands of training images if Test is empty.
    if inv['images']:
        for index,(name, origins) in enumerate(sorted(references.items())):
            if max_references is not None and index >= max_references:
                break
            try:
                path = Path(name)
                image = image_rgb(path)
                sha = digest(path)
                pixel = hashlib.sha256(image.tobytes()+str(image.size).encode()).hexdigest()
                value = int(phash(image),16)
                examined += 1
                for test_id in by_sha.get(sha,[]):
                    matches.append(dict(image_id=test_id,reference=name,type='exact_bytes',distance=0))
                for test_id in by_pixel.get(pixel,[]):
                    matches.append(dict(image_id=test_id,reference=name,type='exact_decoded_pixels',distance=0))
                for candidate,distance in tree.query(value,radius):
                    for test_id in by_hash[candidate]:
                        matches.append(dict(image_id=test_id,reference=name,type='near_candidate_manual_review_required',distance=distance))
            except Exception as e:
                failures.append(dict(path=name,error=str(e)))
    within_test = []
    for i,a in enumerate(inv['images']):
        for b in inv['images'][i+1:]:
            if a['sha256']==b['sha256'] or a['pixel_sha256']==b['pixel_sha256']:
                within_test.append(dict(image_id=a['image_id'],reference=b['image_id'],type='within_test_exact',distance=0))
            else:
                distance=(test_phashes[a['image_id']]^test_phashes[b['image_id']]).bit_count()
                if distance<=radius:
                    within_test.append(dict(image_id=a['image_id'],reference=b['image_id'],type='within_test_near_candidate',distance=distance))
    # Old exploratory data are checked for overlap only; never used as labels or accuracy evidence.
    old_overlap = []
    old_dir = project/'tests/manual_pipeline_images'
    if inv['images'] and old_dir.exists():
        for path in sorted(old_dir.iterdir()):
            if not path.is_file(): continue
            try:
                value = int(phash(image_rgb(path)),16)
                for candidate,distance in tree.query(value,radius):
                    for test_id in by_hash[candidate]:
                        old_overlap.append(dict(image_id=test_id,reference=str(path),type='old_exploratory_overlap_candidate',distance=distance))
            except Exception as e:
                failures.append(dict(path=str(path),error=str(e)))
    write_csv(destination/'matches.csv',matches+within_test+old_overlap,['image_id','reference','type','distance'])
    write_csv(destination/'unverified.csv',failures,['path','error'])
    result = dict(status='SKIPPED_NO_TEST_IMAGES' if not inv['images'] else 'CANDIDATES_FOUND' if matches else 'NO_MATCH_IN_EXAMINED_REFERENCES',
                  test_images=len(inv['images']),test_inventory=inv,manifest_sources=sources,
                  missing_manifests=missing_manifests,unique_reference_paths=len(references),examined=examined,
                  unreadable=len(failures),unexamined=len(references)-examined-len([f for f in failures if f['path'] in references]),
                  max_references=max_references,phash_radius=radius,match_rows=len(matches),within_test_exact=within_test,
                  old_exploratory_candidates=old_overlap,
                  independence_confirmed=False,
                  limitations=['Near matches need visual review; pHash is not proof of independence.',
                               'Only listed V5/V6 manifest sources are covered. Other original sources, capture sessions and provenance are unverified.',
                               'No Test images means no leakage conclusion. Missing or limited references remain unverified.'])
    write_json(destination/'audit.json',result)
    return destination
