# Food AI · SIC-Food

Website Streamlit trên CPU, gồm hai module:

- **Module 1 — Món ăn & dinh dưỡng:** YOLO nhận diện ảnh hoặc một frame video, người dùng xác nhận món và nhập gram để tính khẩu phần. Giữ ngưỡng YOLO 0,5 và logic dinh dưỡng hiện có.
- **Module 2 — Nguyên liệu & trạng thái:** một luồng duy nhất **YOLO → Bounding box → Crop → EfficientNet-B0 V5 → từng nguyên liệu/trạng thái**. Một đối tượng hay nhiều đối tượng đều qua pipeline này; không có chế độ phân loại trực tiếp toàn ảnh.

Không training, không tự tải weights, không đọc dataset/notebook khi phục vụ website.

## Chạy trên Windows

Trong Anaconda Prompt hoặc CMD đã kích hoạt môi trường `sic-food`:

```bat
conda activate sic-food
cd /d "C:\Users\ASUS\SIC-Food"
python -m streamlit run main.py --server.port 8502
```

Mở http://127.0.0.1:8502. Nếu server đã chạy tại cổng này, dùng phiên hiện có.
Môi trường đã kiểm tra là Python 3.11; các thư viện hiện có khai báo tại `requirements.txt`. Không cần cài lại hoặc nâng CUDA/PyTorch cho lần tích hợp này.

Từ Jupyter trong kernel có Streamlit/Torch/Torchvision/Ultralytics:

```python
import subprocess, sys
from pathlib import Path

root = Path(r"C:\Users\ASUS\SIC-Food")
with (root / "streamlit.log").open("a", encoding="utf-8") as log:
    server = subprocess.Popen(
        [sys.executable, "-m", "streamlit", "run", str(root / "main.py"),
         "--server.address", "127.0.0.1", "--server.port", "8502"],
        cwd=root, stdout=log, stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW,
    )
print("http://127.0.0.1:8502")
# Dừng riêng server do cell này tạo khi cần:
# server.terminate()
# server.wait(timeout=15)
```

## Checkpoint

- YOLO Detection: `best.pt`, 214 nhãn.
- Module 2: `models/efficientnet_v5_38/efficientnet_b0_38_prototype_head.pth`, 38 nhãn, 19 nguyên liệu × hai trạng thái.
- V6 và legacy37 giữ cho nghiên cứu/offline; website Module 2 từ chối khi chọn phiên bản khác V5, không fallback âm thầm.

Có thể đặt `SIC_MODEL_PATH` và `SIC_CONDITION_MODEL_PATH` tới file cục bộ; đường dẫn tương đối tính từ project root.
`SIC_CONDITION_MODEL_VERSION` phải là `v5` (mặc định). Thiếu/sai checkpoint được báo lỗi; Module 1 vẫn có nhập món thủ công khi không có YOLO.

V5 được nạp CPU bằng `weights_only=True`, kiến trúc `efficientnet_b0(weights=None)`, classifier 38 đầu ra, strict state dict, eval/inference_mode. Thứ tự nhãn đọc từ checkpoint, không sắp xếp lại.

**Preprocessing V5:** EXIF transpose → RGB → Resize((224,224)) Bilinear → ToTensor → ImageNet Normalize mean `[0.485,0.456,0.406]`, std `[0.229,0.224,0.225]`. Không dùng Resize256/CenterCrop224 của legacy37.

## Sử dụng Module 2

1. Chọn **Trạng thái nguyên liệu**, tải JPG/JPEG/PNG tối đa 20 MB/25 triệu pixel.
2. Bấm **Phân tích bằng AI**; không cần xác nhận trước khi chạy.
3. Xem ảnh đánh số bounding box và từng thẻ crop/nhãn/điểm/Top-3.
4. Mở **Kiểm tra và chỉnh sửa** của đúng đối tượng để sửa tên, trạng thái hoặc xác nhận/cần xem lại.
5. Tải JSON gồm dự đoán AI gốc, bản sửa và kết quả sau sửa nếu cần.

Sửa nhãn/trạng thái hiển thị không chạy lại model. Sửa vùng crop chỉ chạy lại V5 cho vùng thay đổi, không chạy lại YOLO. Bản sửa lưu riêng trong session và không làm thay đổi checkpoint.
Đổi ảnh, xóa ảnh hoặc Reset xóa kết quả và bản sửa cũ. Chạy phân tích lại cùng ảnh cũng bắt đầu kết quả mới.
Chuyển trang giữ kết quả trong phiên; reload tab hoặc restart có thể mất phiên.

YOLO giữ từng box riêng, kể cả box chồng nhau. ID được sắp theo `(x1,y1,x2,y2,class_id,-score)`: ưu tiên trái sang phải, sau đó trên xuống dưới khi cùng x; không theo thứ tự nội bộ model.
Chỉ nhãn YOLO trùng tên nguyên liệu hoặc alias tương đương rõ ràng mới qua V5. Lemon, món chế biến và nhãn ngoài phạm vi giữ `unsupported`, không ép phân loại.
Không có box thì báo **Chưa phát hiện được nguyên liệu**, không tự chạy EfficientNet toàn ảnh. Có thể bổ sung vùng trong cùng pipeline bằng công cụ bên dưới.

### Thêm, sửa và loại bounding box

Sau khi phân tích tự động, mở **Quản lý vùng nguyên liệu · thêm / sửa / xóa box**:

1. **Chọn box:** nhấp vào vùng trên ảnh hoặc dùng danh sách **Box cần chỉnh sửa**. Với box trùng nhau, dùng danh sách để chọn chính xác ID.
2. **Sửa vùng:** chọn box, kéo một hình chữ nhật mới bao quanh nguyên liệu; có thể sửa tiếp bốn tọa độ pixel. Bấm **Áp dụng vùng / xác nhận**.
3. **Thêm vùng bị bỏ sót:** chọn **＋ Thêm box mới**, kéo vùng, chọn nguyên liệu trong 19 loại và đánh dấu xác nhận, rồi bấm **Thêm box và phân tích V5**.
4. **Sửa nhãn YOLO sai:** với Peach thực tế là táo, chọn box, chọn Táo trong **Nguyên liệu người dùng xác nhận**, đánh dấu xác nhận và áp dụng. YOLO gốc vẫn là Peach; kết quả V5 là dự đoán độc lập, có thể bất đồng với người dùng.
5. **Loại box:** chọn ID rồi bấm **Loại box đã chọn**. Chỉ loại khỏi danh sách đang giữ, không xóa snapshot YOLO gốc.
6. **Khôi phục:** bấm **Khôi phục box YOLO ban đầu** để trở về box/kết quả ban đầu, bỏ vùng thêm/sửa và nhãn chỉnh sửa. Không chạy lại model.

Kéo vùng chỉ tạo bản nháp; chưa chạy V5 cho đến khi bấm áp dụng. Vùng/loại tham chiếu không đổi thì tái sử dụng kết quả. Các crop khác giữ nguyên cả kết quả và bản sửa nhãn. ID không đánh lại khi xóa hoặc kéo box, vì vậy có thể có khoảng trống trong dãy số; ảnh và thẻ dùng cùng ID.

Box được ghi rõ **YOLO gốc**, **YOLO đã sửa vùng**, hoặc **thêm thủ công**. JSON schema 2 có snapshot YOLO/V5 ban đầu, box hiện tại, box đã loại, xác nhận thủ công và lịch sử thao tác. Các bản sửa chỉ lưu trong RAM của phiên, không đưa vào dataset.

Canvas sử dụng component V2 có sẵn trong Streamlit 1.65 và HTML/CSS/JavaScript cục bộ, không thêm thư viện hoặc dùng CDN. Có thể dùng tọa độ số nếu thao tác kéo không thuận tiện. Chi tiết kiểm thử và giới hạn: [bàn giao quản lý box](docs/module2_box_editor_delivery.md).

## Cấu hình và ý nghĩa điểm

`config/ingredient_pipeline.json` điều khiển riêng Module 2:

| Tham số | Baseline |
| --- | --- |
| confidence | 0,25 |
| image_size | 640 |
| iou | 0,7, giá trị mặc định Ultralytics đã xác minh trên môi trường hiện tại |
| agnostic_nms | false; giữ NMS theo lớp |
| padding | 0%; crop clip theo kích thước ảnh, int tọa độ như notebook |
| max_detections | 50 mỗi ảnh; cảnh báo khi chạm giới hạn |
| ingredient/condition warning threshold | 0,6 / 0,6; **tham số thử nghiệm chưa hiệu chỉnh** |

Điểm nguyên liệu = tổng softmax của hai trạng thái cùng nguyên liệu.
Điểm trạng thái có điều kiện = điểm lớp trạng thái được chọn / điểm nguyên liệu.
Top-3 vẫn theo 38 nhãn gốc, nên lớp đứng đầu Top-3 có thể khác nguyên liệu được chọn bằng tổng hai trạng thái.
Các điểm không phải xác suất AI đúng hoặc độ chính xác đã kiểm định.

`classified` nghĩa là đã phân loại, chưa phải người dùng xác nhận. `low_confidence`, `disagreement`, `error` đều cần kiểm tra.
`unsupported` nghĩa là không chạy V5 cho nhãn đó. Lỗi riêng một crop không ngăn các crop còn lại.
Tổng quan trên giao diện tính theo các crop đang giữ, gồm dự đoán tạm; số box YOLO ban đầu được ghi riêng và bản sửa nhãn được ghi trên thẻ.

## Module 1

Giữ hỗ trợ ảnh JPG/JPEG/PNG/WEBP hoặc video MP4/MOV/AVI (tối đa 64 MB, chọn một frame).
Mỗi box là một khẩu phần riêng; có thể thêm món thủ công, chọn hồ sơ, nhập gram và xác nhận.
Công thức `per_100g × grams / 100`; không tự điền dữ liệu thiếu bằng 0 hoặc suy gram từ ảnh.
47 hồ sơ hiện còn `unverified` và preparation `unknown`; cần chấp nhận dùng dữ liệu chưa kiểm chứng để ước tính.
Chọn raw/cooked có thể không còn hồ sơ phù hợp. Không sửa dữ liệu dinh dưỡng trong lần phát triển Module 2.

## Cấu trúc

```text
main.py                       Trang chủ, điều hướng
page1.py, page2.py             Module 1 ảnh/video và dinh dưỡng
condition_page.py             Module 2: upload, ảnh box, thẻ crop và chỉnh sửa
ingredient_pipeline.py        YOLO → lọc alias → crop → V5 → warnings/summary/annotation
box_review.py                 Snapshot gốc, thay đổi box và cập nhật crop riêng lẻ
box_editor_ui.py              Điều khiển chọn/thêm/sửa/loại/khôi phục trong Module 2
box_editor_component.py       Component canvas V2 từ assets cục bộ
components/box_editor/        HTML/CSS/JavaScript để kéo vùng trên ảnh
condition_service.py          Loader EfficientNet, preprocessing, phân loại/gộp điểm
detection_service.py          YOLO có khóa inference; cấu hình hai module tách biệt
model_loader.py               Đường dẫn/cache CPU; Module 2 bắt buộc V5
app_state.py                  Session và callback bản sửa riêng
image_service.py              Decode ảnh, EXIF/RGB và giới hạn an toàn
nutrition_service.py          Logic dinh dưỡng giữ nguyên
config/ingredient_pipeline.json Cấu hình riêng Module 2
tests/                        Unit, AppTest và script CPU thật
docs/module2_v5_delivery.md    Báo cáo triển khai và giới hạn
reports/module2_v5_20261029/   Kết quả thật mới; không ghi đè bảng kiểm duyệt cũ
```

## Kiểm thử

```bat
python -B -m unittest discover -s tests -p "test_*.py"
python -B tests/check_ingredient_pipeline.py
python -B tests/check_box_review_models.py
node --test tests/box_editor_geometry.test.mjs
```

Unit/AppTest dùng fixture/mock; script `check_ingredient_pipeline.py` dùng hai checkpoint thật và 18 ảnh JPG/PNG tại `tests/manual_pipeline_images`, đọc các bảng kiểm duyệt trong `reports/pipeline_v5_test` mà không sửa chúng.
`check_website_models.py` là entry tương thích gọi kiểm tra V5 mới; kết quả 37 lớp cũ trong docs là lịch sử riêng.
Trên sandbox Windows, thư mục TEMP hoặc AppTest có thể bị hạn chế; xem điều kiện thực thi và kết quả cụ thể trong báo cáo bàn giao.

## Giới hạn và khôi phục

Model có thể bỏ sót, tạo box trùng, nhầm nguyên liệu hoặc không nhận diện đồ vật ngoài tập nhãn. Công cụ sửa box hỗ trợ người dùng khắc phục vùng chọn nhưng không bảo đảm V5 đoán đúng. Chưa có OOD/calibration, tracking video Module 2 hay lịch sử bền vững.
**Bề ngoài bình thường không đồng nghĩa an toàn để ăn; có dấu hiệu bất thường không tự động chứng minh thực phẩm đã hỏng.**

Bản sao các file trước sửa nằm trong `backups/module2_v5_20261029_153636/` với hash file bảo vệ. Khi khôi phục chỉ phục hồi source cần thiết, không ghi đè model/dataset. Các tài liệu ngày 17/10 và bản chia sẻ GitHub ngày 28/10 là snapshot cũ, chưa phản ánh pipeline Module 2 hiện tại.

Bản sao trước khi thêm công cụ box: `backups/module2_box_editor_20261029_160614/`. Node chỉ cần để chạy test hình học JavaScript, không cần để phục vụ website.
