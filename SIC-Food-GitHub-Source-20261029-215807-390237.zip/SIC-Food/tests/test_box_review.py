"""Box operations and incremental inference with deterministic synthetic fixtures."""
import copy
import json
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from PIL import Image
from test_ingredient_pipeline import classifier, detection
from ingredient_pipeline import analyze_ingredients
from box_review import (start_review, update_box, delete_box, restore_boxes, export_review,
                        validate_canvas_event)


class BoxReviewTests(unittest.TestCase):
    def setUp(self):
        self.image=Image.new('RGB',(100,100))
        self.classifier=classifier()
        self.detector=SimpleNamespace(names={0:'Apple'})

    def workspace(self, boxes=None):
        boxes=boxes if boxes is not None else [detection(box=[1,1,20,20]),detection(box=[30,1,50,20])]
        with patch('ingredient_pipeline.detect_ingredients',return_value=boxes):
            self.analysis=analyze_ingredients(self.image,self.detector,self.classifier)
        self.classifier.predict_ingredient.reset_mock()
        return start_review(self.analysis,'image-A')

    def test_four_correct_apples_have_stable_ids_and_untouched_snapshot(self):
        w=self.workspace([detection(box=[x,1,x+10,20]) for x in (1,20,40,70)])
        before=copy.deepcopy(w)
        unchanged, changed=update_box(w,self.image,self.classifier,2,[20,1,30,20])
        self.assertIs(unchanged,w)
        self.assertEqual(changed,[])
        self.classifier.predict_ingredient.assert_not_called()
        self.assertEqual(w,before)

    def test_duplicate_deletion_runs_no_models_and_restore_is_exact(self):
        w=self.workspace([detection(),detection()])
        after=delete_box(w,2)
        self.assertEqual([r['object_id'] for r in after['objects']],[1])
        self.assertEqual(len(after['removed_objects']),1)
        self.assertEqual(len(w['objects']),2)
        self.assertEqual(after['original_analysis'],self.analysis)
        restored=restore_boxes(after)
        self.assertEqual(restored['objects'],w['objects'])
        self.classifier.predict_ingredient.assert_not_called()

    def test_missing_orange_added_only_new_crop_is_inferred(self):
        w=self.workspace()
        before=copy.deepcopy(w['objects'])
        self.classifier.predict_ingredient.return_value={'ingredient':'orange','condition':'normal_appearance',
            'ingredient_score':.9,'condition_score':.8,'top3':[]}
        added,changed=update_box(w,self.image,self.classifier,None,[60,10,95,50],'orange',True)
        self.assertEqual(changed,[3])
        self.assertEqual(added['objects'][:2],before)
        self.classifier.predict_ingredient.assert_called_once()
        row=added['objects'][2]
        self.assertEqual(row['origin'],'manual')
        self.assertEqual(row['ingredient'],'orange')
        self.assertIsNone(row['yolo_label'])
        self.assertTrue(row['manual_confirmation']['confirmed'])
        self.assertEqual(len(w['objects']),2)

    def test_peach_is_not_apple_until_user_confirms_and_v5_stays_independent(self):
        w=self.workspace([detection('Peach')])
        self.assertEqual(w['objects'][0]['status'],'unsupported')
        self.classifier.predict_ingredient.assert_not_called()
        with self.assertRaises(ValueError):update_box(w,self.image,self.classifier,1,[0,0,20,20],'apple',False)
        done,_=update_box(w,self.image,self.classifier,1,[0,0,20,20],'apple',True)
        self.assertEqual(done['objects'][0]['yolo_label'],'Peach')
        self.assertEqual(done['original_analysis']['objects'][0]['status'],'unsupported')
        self.assertEqual(done['objects'][0]['manual_confirmation']['ingredient'],'apple')
        self.assertEqual(done['objects'][0]['ingredient'],'apple')
        # V5 may disagree with the human assertion; never overwrite its prediction.
        self.classifier.predict_ingredient.return_value=dict(self.classifier.predict_ingredient.return_value,ingredient='banana')
        changed,_=update_box(done,self.image,self.classifier,1,[0,0,21,20])
        self.assertEqual(changed['objects'][0]['ingredient'],'banana')
        self.assertEqual(changed['objects'][0]['status'],'disagreement')

    def test_only_changed_box_loses_old_classification(self):
        w=self.workspace()
        original=copy.deepcopy(w)
        done,changed=update_box(w,self.image,self.classifier,1,[1,1,25,20])
        self.assertEqual(changed,[1])
        self.classifier.predict_ingredient.assert_called_once()
        self.assertEqual(done['objects'][1],original['objects'][1])
        self.assertTrue(done['objects'][0]['geometry_edited'])
        self.assertEqual(w,original)
        again,changed=update_box(done,self.image,self.classifier,1,[1,1,25,20])
        self.assertIs(again,done)
        self.assertEqual(changed,[])
        self.assertEqual(self.classifier.predict_ingredient.call_count,1)

    def test_delete_add_restore_does_not_reuse_manual_ids(self):
        w=self.workspace([])
        w,_=update_box(w,self.image,self.classifier,None,[0,0,10,10],'apple',True)
        w=delete_box(w,1)
        w,_=update_box(w,self.image,self.classifier,None,[20,20,40,40],'orange',True)
        self.assertEqual(w['objects'][0]['object_id'],2)
        w=restore_boxes(w)
        self.assertEqual(w['objects'],[])
        w,_=update_box(w,self.image,self.classifier,None,[20,20,40,40],'orange',True)
        self.assertEqual(w['objects'][0]['object_id'],3)

    def test_unsupported_geometry_edit_does_not_force_classification(self):
        w=self.workspace([detection('Apple Pie')])
        done,changed=update_box(w,self.image,self.classifier,1,[1,1,15,15])
        self.assertEqual(changed,[1])
        self.assertEqual(done['objects'][0]['status'],'unsupported')
        self.classifier.predict_ingredient.assert_not_called()

    def test_invalid_input_is_transactional_and_limit_is_enforced(self):
        w=self.workspace()
        before=copy.deepcopy(w)
        for box in ([0,0,0,20],[-1,0,10,10],[0,0,101,20],[0,0,float('nan'),20]):
            with self.assertRaises(ValueError):update_box(w,self.image,self.classifier,1,box)
        with self.assertRaises(ValueError):update_box(w,self.image,self.classifier,None,[1,1,10,10])
        with self.assertRaises(ValueError):delete_box(w,99)
        w['original_analysis']['settings']['max_detections']=2
        with self.assertRaises(ValueError):update_box(w,self.image,self.classifier,None,[60,1,80,20],'apple',True)
        w['original_analysis']['settings']['max_detections']=before['original_analysis']['settings']['max_detections']
        self.assertEqual(w,before)
        self.classifier.predict_ingredient.assert_not_called()

    def test_export_has_original_working_removed_and_human_decisions(self):
        w=self.workspace()
        w=delete_box(w,2)
        w,_=update_box(w,self.image,self.classifier,None,[60,10,90,30],'orange',True)
        data=export_review(w,{'1':{'condition':'visible_defect'},'2':{'condition':'normal_appearance'}})
        self.assertEqual(len(data['original_yolo_analysis']['objects']),2)
        self.assertEqual(len(data['working_objects']),2)
        self.assertEqual(len(data['removed_objects']),1)
        self.assertNotIn('2',data['user_edits'])
        self.assertEqual(data['history'][1]['action'],'add_box')
        json.dumps(data,allow_nan=False)

    def test_stale_or_malformed_canvas_payload_cannot_change_boxes(self):
        w=self.workspace()
        payload={'event_id':'one','analysis_id':w['analysis_id'],'image_token':'image-A','revision':0,
                 'kind':'region','bbox':[1,1,20,20]}
        self.assertEqual(validate_canvas_event(payload,w,self.image.size)['bbox'],[1,1,20,20])
        for mutation in [{'revision':1},{'image_token':'image-B'},{'analysis_id':'old'},
                         {'bbox':[0,0,1000,20]},{'bbox':[True,0,20,20]},{'event_id':[]}]:
            self.assertIsNone(validate_canvas_event(dict(payload,**mutation),w,self.image.size))
        select=dict(payload,kind='select',object_id=2)
        self.assertEqual(validate_canvas_event(select,w,self.image.size)['object_id'],2)
        self.assertIsNone(validate_canvas_event(dict(select,object_id=True),w,self.image.size))

    def test_same_crop_confirmation_is_recorded_without_rerunning_v5(self):
        w=self.workspace()
        confirmed,changed=update_box(w,self.image,self.classifier,1,[1,1,20,20],'apple',True)
        self.assertEqual(changed,[1])
        self.assertEqual(confirmed['objects'][0]['manual_confirmation']['ingredient'],'apple')
        self.classifier.predict_ingredient.assert_not_called()

    def test_late_label_callback_for_removed_widget_is_ignored(self):
        from app_state import save_condition_edit
        state={'cond_workspace':{'objects':[]},'cond_field_1_ingredient':'apple'}
        with patch('app_state.st.session_state',state):
            save_condition_edit('1','ingredient','cond_field_1_ingredient')
        self.assertNotIn('cond_edits',state)
        with patch('app_state.st.session_state',{}):
            save_condition_edit('1','ingredient','missing')

    def test_canvas_wrapper_does_not_shadow_native_trigger_with_a_state_default(self):
        from box_editor_component import render_box_canvas
        from streamlit.components.v2.bidi_component.state import ComponentResult
        w=self.workspace()
        event={'kind':'region','bbox':[1,1,20,20]}
        with patch('box_editor_component._canvas',return_value=ComponentResult({}, {'event':event})) as mount:
            result=render_box_canvas('data:image/jpeg;base64,',self.image.size,w,1,[1,1,20,20],'test')
        self.assertEqual(result,event)
        self.assertNotIn('default',mount.call_args.kwargs)


if __name__ == '__main__': unittest.main()
