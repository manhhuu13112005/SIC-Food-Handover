// No external code, network calls, HTML interpolation, browser storage or eval.
export function imagePoint(clientX, clientY, rect, width, height) {
  const clip = (v,max) => Math.max(0,Math.min(max,v));
  return [clip((clientX-rect.left)/rect.width*width,width),
          clip((clientY-rect.top)/rect.height*height,height)];
}
export function regionBox(start,end) {
  return [Math.floor(Math.min(start[0],end[0])),Math.floor(Math.min(start[1],end[1])),
          Math.ceil(Math.max(start[0],end[0])),Math.ceil(Math.max(start[1],end[1]))];
}
export function hitBox(point,objects) {
  return objects.filter(r => r.bbox && point[0]>=r.bbox[0] && point[0]<=r.bbox[2]
      && point[1]>=r.bbox[1] && point[1]<=r.bbox[3])
    .sort((a,b) => ((a.bbox[2]-a.bbox[0])*(a.bbox[3]-a.bbox[1])
                   -(b.bbox[2]-b.bbox[0])*(b.bbox[3]-b.bbox[1])) || a.object_id-b.object_id)[0];
}
export default function({data,parentElement,setTriggerValue}) {
  const canvas=parentElement.querySelector('canvas');
  const surface=parentElement.querySelector('.surface');
  const label=parentElement.querySelector('.selection');
  const ctx=canvas.getContext('2d');
  const image=new Image();
  let start=null, drag=null, disposed=false;
  const selected=data.objects.find(r=>r.object_id===data.selected_id);
  label.textContent = selected ? `Đang chọn box ${selected.object_id}. Box trùng có thể chọn bằng danh sách bên dưới.` : 'Đang chọn vùng để thêm box mới.';
  const colors={yolo:'#24754d',edited:'#8042a8',manual:'#2472b5'};
  function draw() {
    if(disposed || !image.complete || !image.naturalWidth) return;
    const scale=Math.min((surface.clientWidth-16)/data.width,550/data.height,1);
    canvas.width=Math.max(1,Math.round(data.width*scale));
    canvas.height=Math.max(1,Math.round(data.height*scale));
    const sx=canvas.width/data.width, sy=canvas.height/data.height;
    ctx.drawImage(image,0,0,canvas.width,canvas.height);
    ctx.font='bold 14px sans-serif';
    for(const row of data.objects) {
      const [x1,y1,x2,y2]=row.bbox;
      const color=colors[row.source]||colors.yolo;
      ctx.strokeStyle=color;ctx.lineWidth=row.object_id===data.selected_id?4:2;
      ctx.setLineDash([]);ctx.strokeRect(x1*sx,y1*sy,(x2-x1)*sx,(y2-y1)*sy);
      const text=`${row.object_id} · ${row.source==='manual'?'Thêm':row.source==='edited'?'Đã sửa':'YOLO'}`;
      const w=ctx.measureText(text).width+8;
      const y=Math.max(0,y1*sy-22),x=Math.max(0,Math.min(canvas.width-w,x1*sx));
      ctx.fillStyle=color;ctx.fillRect(x,y,w,22);ctx.fillStyle='white';ctx.fillText(text,x+4,y+16);
    }
    const box=drag || data.draft;
    if(box && box[2]>box[0] && box[3]>box[1]) {
      ctx.strokeStyle='#d08108';ctx.lineWidth=3;ctx.setLineDash([7,5]);
      ctx.strokeRect(box[0]*sx,box[1]*sy,(box[2]-box[0])*sx,(box[3]-box[1])*sy);
      ctx.setLineDash([]);
    }
  }
  function point(e){return imagePoint(e.clientX,e.clientY,canvas.getBoundingClientRect(),data.width,data.height);}
  function send(payload){
    setTriggerValue('event',{...payload,event_id:crypto.randomUUID(),analysis_id:data.analysis_id,
                            image_token:data.image_token,revision:data.revision});
  }
  function down(e){if(e.button!==0)return;start=point(e);canvas.setPointerCapture(e.pointerId);}
  function move(e){if(!start)return;drag=regionBox(start,point(e));draw();}
  function up(e){
    if(!start)return;
    const end=point(e), rect=canvas.getBoundingClientRect();
    const moved=Math.hypot((end[0]-start[0])*rect.width/data.width,(end[1]-start[1])*rect.height/data.height);
    if(moved<4){const hit=hitBox(end,data.objects);if(hit)send({kind:'select',object_id:hit.object_id});}
    else {const bbox=regionBox(start,end);label.textContent=`Vùng chọn: ${bbox.join(', ')}. Bấm áp dụng bên dưới để lưu.`;send({kind:'region',bbox,target_id:data.selected_id||0});}
    start=null;drag=null;
  }
  function cancel(){start=null;drag=null;draw();}
  canvas.addEventListener('pointerdown',down);canvas.addEventListener('pointermove',move);
  canvas.addEventListener('pointerup',up);canvas.addEventListener('pointercancel',cancel);
  const observer=new ResizeObserver(draw);observer.observe(surface);
  image.onload=draw;
  // The server creates this JPEG data URI. No arbitrary URL is accepted.
  if(typeof data.image_data==='string' && data.image_data.startsWith('data:image/jpeg;base64,'))image.src=data.image_data;
  return ()=>{disposed=true;observer.disconnect();image.onload=null;
    canvas.removeEventListener('pointerdown',down);canvas.removeEventListener('pointermove',move);
    canvas.removeEventListener('pointerup',up);canvas.removeEventListener('pointercancel',cancel);};
}
