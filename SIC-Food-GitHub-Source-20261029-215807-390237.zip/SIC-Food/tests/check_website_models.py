"""Compatibility CLI for the current V5 pipeline CPU checks.

Historical legacy37 results remain in docs/website_validation.md.
New reports go to reports/module2_v5_20261029, never over the reviewed tables.
"""
from check_ingredient_pipeline import main

if __name__ == '__main__':
    main()
