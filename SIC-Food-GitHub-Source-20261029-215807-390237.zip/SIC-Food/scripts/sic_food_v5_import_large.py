"""SIC-Food V5: safe, incremental import and preview of nested-ZIP sources.

Run: python sic_food_v5_import_large.py --root C:\\Users\\ASUS\\SIC-Food preview
     python sic_food_v5_import_large.py --root C:\\Users\\ASUS\\SIC-Food import

Does NOT train, re-split, modify old datasets, or use LOCBEEF's protected test images.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import random
import shutil
import tempfile
import zipfile
from collections import Counter, defaultdict
from contextlib import contextmanager
from pathlib import Path, PurePosixPath

from PIL import Image, ImageOps, ImageDraw, UnidentifiedImageError

EXTENSIONS = {'.jpg', '.jpeg', '.png', '.webp', '.bmp'}
MAX_SINGLE_FILE = 60 * 1024 * 1024
MAX_IMAGE_PIXELS = 40_000_000
FIELDNAMES = ['source','source_split','original_group','source_class','proposed_target_class',
              'path','inner_zip','image_member','review_status','note']


@contextmanager
def local_child_zip(outer: zipfile.ZipFile, info: zipfile.ZipInfo, temp_dir: Path):
    """Copy nested ZIP to a temporary file on disk without expanding in RAM."""
    fd, name = tempfile.mkstemp(prefix='sic_food_v5_', suffix='.zip', dir=temp_dir)
    import os
    try:
        with os.fdopen(fd, 'wb') as dst, outer.open(info) as src:
            shutil.copyfileobj(src, dst, length=1024*1024)
        with zipfile.ZipFile(name) as inner:
            yield inner
    finally:
        Path(name).unlink(missing_ok=True)


def normalized_members(inner: zipfile.ZipFile):
    return [i for i in inner.infolist() if not i.is_dir() and
            PurePosixPath(i.filename).suffix.lower() in EXTENSIONS]


def dataset_info(source, inner_name, filename):
    # Mapping is only provisional and applies exclusively to photos of the actual ingredient.
    parts = PurePosixPath(filename.replace('\\','/')).parts
    if source == 'brinjalfruitx':
        if not parts: return None
        folder = parts[0]
        mapping = {
            'Healty Brinjal':'eggplant__normal_appearance',
            'Wet Rot':'eggplant__visible_defect',
            'Brinjal Fruit Creaking':'eggplant__visible_defect',
            'Shoot and Fruit Borer':'',
            'Phomopsis Bright':'',
        }
        if folder not in mapping: return None
        return 'unassigned', folder, mapping[folder], 'brinjalfruitx::'+folder
    if source == 'locbeef':
        if len(parts)<3 or parts[0] not in ('train','test') or parts[1] not in ('fresh','rotten'):
            return None
        split, folder = parts[0], parts[1]
        label = 'beef__normal_appearance' if folder == 'fresh' else 'beef__visible_defect'
        # No evidence of acquisition-session grouping: entire LOCBEEF train is provisional group.
        return split, folder, label, 'locbeef::'+split+'::'+folder
    return None


def sources(root):
    a = root/'datasets'/'external_v5'/'archives'
    return [('brinjalfruitx',a/'brinjalfruitx.zip'), ('locbeef',a/'locbeef.zip')]


def write_csv(out, rows, cols=FIELDNAMES):
    out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w', newline='', encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=cols)
        w.writeheader(); w.writerows(rows)


def open_thumb(inner, info, maximum=750):
    if info.file_size > MAX_SINGLE_FILE:
        raise ValueError(f'Oversized member: {info.file_size}')
    with inner.open(info) as stream:
        with Image.open(stream) as img:
            if img.width * img.height > MAX_IMAGE_PIXELS:
                raise ValueError('Pixel count exceeds limit')
            image = ImageOps.exif_transpose(img).convert('RGB')
            image.thumbnail((maximum,maximum), Image.Resampling.LANCZOS)
    return image


def run(root: Path, mode: str):
    reports = root/'datasets'/'external_v5'/'reports'
    preview_dir = root/'datasets'/'external_v5'/'review'/'large_dataset_previews'
    output_dir = root/'datasets'/'external_v5'/'large_import_candidates'
    for d in (reports, preview_dir, output_dir):d.mkdir(parents=True,exist_ok=True)
    inventory=[]; manifests=[]; protected=[]; problems=[]; num=Counter()
    if shutil.disk_usage(reports).free < 8*1024**3:
        raise RuntimeError('Less than 8GB free: nested ZIP temp files may not fit')
    for source, archive_path in sources(root):
        if not archive_path.is_file():
            raise FileNotFoundError(archive_path)
        with zipfile.ZipFile(archive_path) as outer:
            children=[f for f in outer.infolist() if f.filename.lower().endswith('.zip') and not f.is_dir()]
            for child in children:
                print(f'[{source}] Processing nested ZIP {child.filename} (~{child.file_size/1024**2:.0f} MB)',flush=True)
                with local_child_zip(outer, child, reports) as inner:
                    image_infos = normalized_members(inner)
                    grouped=defaultdict(list)
                    for info in image_infos:
                        cls = dataset_info(source,child.filename,info.filename)
                        if cls is not None:
                            grouped[cls[1]].append((info,cls))
                    for folder, entries in sorted(grouped.items()):
                        example = entries[0][1]
                        split, raw_label, proposed, group = example
                        inventory.append(dict(source=source, source_split=split,
                                              source_label=raw_label, suggested_label=proposed or 'REVIEW_ONLY',
                                              images=len(entries), nested_zip=child.filename))
                        print(f'    {split:10s} | {raw_label:25s} | {len(entries):5d} | {proposed or "REVIEW_ONLY"}',flush=True)
                        if mode == 'preview':
                            # Keep the original external TEST set unseen until final evaluation.
                            if source == 'locbeef' and split == 'test':
                                print('    TEST preview skipped to protect final evaluation.')
                                continue
                            rng=random.Random(2026)
                            chosen = rng.sample(entries, min(12,len(entries)))
                            canvas = Image.new('RGB',(4*205,3*225),'white')
                            draw=ImageDraw.Draw(canvas)
                            for idx,(info,_) in enumerate(chosen):
                                try:
                                    im = open_thumb(inner,info,185)
                                    x=(idx%4)*205+5; y=(idx//4)*225+5
                                    canvas.paste(im,(x,y))
                                    draw.text((x,y+188),str(idx+1),fill='black')
                                except Exception as e:
                                    problems.append((source,info.filename,str(e)))
                            name = f'{source}_{split}_{raw_label}'.replace(' ','_')+'.jpg'
                            target=preview_dir/name
                            canvas.save(target,quality=90)
                            print(f'    Preview: {target}',flush=True)
                        elif mode == 'import':
                            for idx,(info,entry) in enumerate(entries):
                                split, raw_label, proposed, group = entry
                                base={'source':source,'source_split':split,'original_group':group,
                                      'source_class':raw_label, 'proposed_target_class':proposed,
                                      'inner_zip':child.filename,'image_member':info.filename,
                                      'review_status':'pending','note':'Unverified original image, label & session'}
                                if source=='locbeef' and split=='test':
                                    protected.append({**base,'path':''})
                                    continue
                                # Brinjal Borer/Phomopsis require visual review of fruit vs foliage BEFORE extraction.
                                if not proposed:
                                    continue
                                h=hashlib.sha256((source+'|'+child.filename+'|'+info.filename).encode()).hexdigest()[:24]
                                target=output_dir/source/proposed/(h+'.jpg')
                                try:
                                    if not target.is_file():
                                        image=open_thumb(inner,info,1024)
                                        target.parent.mkdir(parents=True,exist_ok=True)
                                        image.save(target,format='JPEG',quality=90)
                                    manifests.append({**base,'path':str(target)})
                                    num[(source,proposed)]+=1
                                except Exception as e:
                                    problems.append((source,info.filename,str(e)))
                                if (idx+1)%250 == 0:print(f'    {raw_label}: {idx+1}/{len(entries)}',flush=True)
    write_csv(reports/'v5_large_source_inventory.csv',inventory,
              ['source','source_split','source_label','suggested_label','images','nested_zip'])
    if mode=='import':
        write_csv(reports/'v5_large_import_candidates.csv',manifests)
        write_csv(reports/'v5_locbeef_protected_test_index.csv',protected)
        print(f'IMPORTED CANDIDATES: {len(manifests)} ; PROTECTED TEST (index only): {len(protected)}')
        for k,c in sorted(num.items()):print('  ',k,c)
    if problems:
        write_csv(reports/'v5_large_import_errors.csv',
                  [dict(source=s,image_member=m,error=e) for s,m,e in problems],
                  ['source','image_member','error'])
        print(f'WARN: {len(problems)} input issues; see v5_large_import_errors.csv')
    else:
        print('DONE with no image read errors.')


def main():
    p=argparse.ArgumentParser()
    p.add_argument('mode', choices=['preview','import'])
    p.add_argument('--root', type=Path, default=Path(r'C:\Users\ASUS\SIC-Food'))
    args=p.parse_args()
    run(args.root,args.mode)
if __name__=='__main__':main()
