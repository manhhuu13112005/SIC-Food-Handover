"""Deterministic synthetic tests for geometry, marginalization and isolation."""
import copy
import json
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from PIL import Image
import torch
from condition_service import ConditionClassifier
from ingredient_pipeline import (analyze_ingredients, crop_bounds, effective_result,
                                 load_pipeline_settings, supported_ingredient)

INGREDIENTS = ['apple', 'banana', 'beef', 'bell_pepper', 'cabbage', 'carrot', 'chicken',
               'cucumber', 'eggplant', 'fish', 'lettuce', 'mango', 'onion', 'orange',
               'pork', 'potato', 'shrimp', 'strawberry', 'tomato']
NAMES = [f'{i}__{s}' for i in INGREDIENTS for s in ('normal_appearance', 'visible_defect')]


def detection(label='Apple', box=None, score=.8):
    return {'original_label': label, 'bbox': box or [0, 0, 20, 20], 'class_id': 0, 'confidence': score}


def classifier():
    c = ConditionClassifier(lambda x: torch.zeros(1, 38), lambda im: torch.zeros(3, 8, 8), NAMES,
                            {'version': 'v5'})
    c.predict_ingredient = Mock(return_value={'ingredient': 'apple', 'condition': 'normal_appearance',
        'ingredient_score': .9, 'condition_score': .8, 'top3': []})
    return c


class IngredientPipelineTests(unittest.TestCase):
    def run_pipeline(self, detections, c=None, settings=None):
        c = c or classifier()
        detector = SimpleNamespace(names={0: 'Apple'})
        with patch('ingredient_pipeline.detect_ingredients', return_value=detections) as detect:
            result = analyze_ingredients(Image.new('RGB', (100, 100)), detector, c, settings)
        return result, c, detect

    def test_crop_zero_padding_clipping_and_research_padding(self):
        self.assertEqual(load_pipeline_settings()['padding'], 0)
        self.assertEqual(crop_bounds([-3.8, 2.9, 120, 90.7], (100, 100)), (0, 2, 100, 90))
        self.assertEqual(crop_bounds([20, 20, 40, 60], (100,100), .1), (18, 16, 42, 64))
        for box in ([0,0,0,1], [3,3,1,1], [101,0,120,20], [0,0,float('nan'),1], [0,1,2]):
            with self.assertRaises(ValueError): crop_bounds(box, (100,100))

    def test_ingredient_sum_can_differ_from_highest_joint_class(self):
        names = ['apple__normal_appearance', 'apple__visible_defect',
                 'banana__normal_appearance', 'banana__visible_defect']
        probabilities = torch.tensor([[.26, .25, .48, .01]])
        c = ConditionClassifier(lambda _: probabilities.log(), lambda _: torch.zeros(3,2,2), names)
        result = c.predict_ingredient(Image.new('RGB',(20,20)))
        self.assertEqual(result['ingredient'], 'apple')
        self.assertEqual(result['condition'], 'normal_appearance')
        self.assertAlmostEqual(result['ingredient_score'], .51, places=6)
        self.assertAlmostEqual(result['condition_score'], .26/.51, places=6)
        self.assertEqual(result['top3'][0]['ingredient'], 'banana')
        c.class_names = names[:-1]
        with self.assertRaises(ValueError): c.predict_ingredient(Image.new('RGB',(20,20)))

    def test_four_apples_preserved_order_and_crop_alignment(self):
        ds = [detection(box=[60,10,80,30]), detection(box=[1,40,20,60]),
              detection(box=[1,2,20,20]), detection(box=[30,1,50,20])]
        result, c, detect = self.run_pipeline(ds)
        self.assertEqual([r['object_id'] for r in result['objects']], [1,2,3,4])
        self.assertEqual([r['bbox_xyxy'][:2] for r in result['objects']], [[1,2],[1,40],[30,1],[60,10]])
        self.assertEqual(c.predict_ingredient.call_count, 4)
        self.assertEqual([call.args[0].size for call in c.predict_ingredient.call_args_list],
                         [(19,18),(19,20),(20,19),(20,20)])
        self.assertEqual(detect.call_count, 1)
        self.assertEqual(detect.call_args.kwargs['confidence'], .25)
        self.assertEqual(detect.call_args.kwargs['image_size'], 640)
        self.assertFalse(detect.call_args.kwargs['agnostic_nms'])

    def test_no_detection_never_classifies_whole_image(self):
        result, c, _ = self.run_pipeline([])
        self.assertEqual(result['summary']['detected'], 0)
        c.predict_ingredient.assert_not_called()

    def test_aliases_supported_and_prepared_foods_rejected(self):
        supported = set(INGREDIENTS)
        aliases = load_pipeline_settings()['aliases']
        self.assertEqual(supported_ingredient(' Bell Pepper ', supported, aliases), 'bell_pepper')
        for name in ['Steak','Pork Satay','Chicken Rice','Apple Pie','Lemon','Broccoli']:
            self.assertIsNone(supported_ingredient(name, supported, aliases))
        result, c, _ = self.run_pipeline([detection('Apple Pie'), detection('Lemon')])
        self.assertEqual(result['summary']['unsupported'], 2)
        c.predict_ingredient.assert_not_called()

    def test_mixed_overlapping_boxes_and_disagreement(self):
        result, c, _ = self.run_pipeline([detection('Apple'), detection('Banana')])
        self.assertEqual(len(result['objects']), 2)  # Never silently deduplicate.
        self.assertEqual(result['objects'][1]['status'], 'disagreement')
        self.assertEqual(result['objects'][1]['yolo_label'], 'Banana')
        self.assertEqual(result['objects'][1]['ingredient'], 'apple')

    def test_low_scores_bad_crop_and_single_crop_failure_are_isolated(self):
        c = classifier()
        prediction = dict(c.predict_ingredient.return_value, ingredient_score=.4)
        c.predict_ingredient.side_effect = [RuntimeError('synthetic'), prediction]
        result, _, _ = self.run_pipeline([detection(box=[1,1,20,20]), detection(box=[30,1,50,20]),
                                         detection(box=[200,1,220,20])], c)
        self.assertEqual([r['status'] for r in result['objects']], ['error','low_confidence','error'])
        self.assertIsNone(result['objects'][0]['condition'])
        self.assertEqual(result['objects'][2]['error_code'], 'invalid_crop')
        self.assertEqual(c.predict_ingredient.call_count, 2)
        json.dumps(result, allow_nan=False)

    def test_limit_and_settings_validation(self):
        settings = dict(load_pipeline_settings(), max_detections=2)
        result, c, _ = self.run_pipeline([detection() for _ in range(4)], settings=settings)
        self.assertEqual(c.predict_ingredient.call_count, 2)
        self.assertTrue(result['limit_reached'])
        for field, value in [('padding', -.1), ('confidence', float('nan')), ('max_detections', True)]:
            with self.assertRaises(ValueError): self.run_pipeline([], settings=dict(settings, **{field:value}))

    def test_edits_are_separate_and_wrong_checkpoint_is_rejected(self):
        result, c, _ = self.run_pipeline([detection()])
        row = result['objects'][0]
        before = copy.deepcopy(row)
        edit = effective_result(row, {'ingredient':'banana', 'condition':'visible_defect', 'review':'confirmed'})
        self.assertEqual(row, before)
        self.assertEqual(edit['source'], 'user')
        self.assertEqual(edit['ingredient'], 'banana')
        c.metadata['version'] = 'v6'
        with self.assertRaisesRegex(ValueError, 'V5'): self.run_pipeline([], c)

    def test_detection_settings_do_not_change_module_one(self):
        from detection_service import detect_image, detect_ingredients
        import numpy as np
        model = Mock()
        model.predict.return_value = [SimpleNamespace(boxes=[], names={}, plot=lambda: np.zeros((10,10,3), dtype=np.uint8))]
        image = Image.new('RGB',(10,10))
        detect_image(model,image)
        self.assertEqual(model.predict.call_args.kwargs, {'conf':.5,'device':'cpu','verbose':False})
        detect_ingredients(model,image,confidence=.25,image_size=640,iou=.7,agnostic_nms=False,max_detections=50)
        self.assertEqual(model.predict.call_args.kwargs['max_det'], 50)


if __name__ == '__main__': unittest.main()
