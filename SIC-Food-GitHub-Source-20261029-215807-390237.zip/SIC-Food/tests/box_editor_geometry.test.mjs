import test from 'node:test';
import assert from 'node:assert/strict';
import {imagePoint,regionBox,hitBox} from '../components/box_editor/editor.mjs';

test('Pointer coordinates map display scaling and offset to original image pixels',()=>{
  assert.deepEqual(imagePoint(220,170,{left:20,top:70,width:400,height:200},800,400),[400,200]);
  assert.deepEqual(imagePoint(-10,500,{left:20,top:70,width:400,height:200},800,400),[0,400]);
});
test('Dragging in any direction yields covering XYXY coordinates',()=>{
  assert.deepEqual(regionBox([99.2,80.3],[10.8,20.5]),[10,20,100,81]);
});
test('Overlapping boxes choose the smallest region; the Python dropdown can select either',()=>{
  const boxes=[{object_id:1,bbox:[0,0,100,100]},{object_id:2,bbox:[20,20,40,40]}];
  assert.equal(hitBox([30,30],boxes).object_id,2);
  assert.equal(hitBox([80,80],boxes).object_id,1);
  assert.equal(hitBox([120,120],boxes),undefined);
});
