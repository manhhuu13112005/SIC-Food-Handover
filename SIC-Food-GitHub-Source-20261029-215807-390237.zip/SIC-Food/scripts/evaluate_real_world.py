"""Windows CPU entry point for independent research only."""
import argparse
import sys
from pathlib import Path
PROJECT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(PROJECT))
from research.real_world_test import (inventory, load_models, model_contract, freeze,
                                      infer, evaluate, write_json, identifier)
from research.leakage_audit import audit


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['inventory','freeze','manual-freeze','infer','evaluate','audit','run','smoke'])
    parser.add_argument('--data',type=Path,default=PROJECT/'datasets/real_world_test_v1')
    parser.add_argument('--output',type=Path,default=PROJECT/'reports/real_world_test_v1')
    parser.add_argument('--run',type=Path)
    parser.add_argument('--max-references',type=int)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    if args.command=='inventory':
        path=args.output/('inventory_'+identifier()+'.json'); write_json(path,inventory(args.data)); print(path); return
    if args.command=='audit':
        print(audit(args.data,args.output,PROJECT,args.max_references)); return
    models=load_models()
    ingredients=sorted(models['v5'].ingredient_groups())
    if args.command=='smoke':
        # Explicitly technical only. This image has no independent labels.
        import tempfile, shutil
        with tempfile.TemporaryDirectory(prefix='phase_c_smoke_') as tmp:
            data=Path(tmp); (data/'images').mkdir()
            shutil.copyfile(PROJECT/'images/test image.png',data/'images/technical_smoke.png')
            run=freeze(data,args.output,ingredients)
            predictions=infer(run,models)
            write_json(run/'technical_smoke.json',dict(scope='TECHNICAL_ONLY_NO_ACCURACY_OR_GENERALIZATION',
                       crop_predictions=len(predictions),versions=sorted(models),contracts=model_contract(models)))
            print(run)
        return
    if args.command in ('freeze','manual-freeze','run'):
        run=freeze(args.data,args.output,ingredients,manual=args.command=='manual-freeze')
        print(run)
    else:
        if not args.run: parser.error('--run is required')
        run=args.run
    if args.command in ('infer','run'): infer(run,models)
    if args.command in ('evaluate','run'): print(evaluate(args.data,run,ingredients))


if __name__=='__main__': main()
