"""Known-answer synthetic checks; these are never independent model accuracy evidence."""
import copy
import csv
import tempfile
import unittest
from pathlib import Path
from PIL import Image
from research.evaluation_metrics import (classification,classifier_metrics,iou,detection_metrics,average_precision)
from research.real_world_test import (inventory,save_annotation,latest_annotation,freeze,infer,evaluate,
                                     read_json,write_json,digest)
from research.leakage_audit import audit


class MetricsTests(unittest.TestCase):
    def test_confusion_and_macro(self):
        r=classification(['a','a','b'],['a','b','b'],['a','b','c'])
        self.assertEqual(r['confusion_matrix'],[[1,1,0],[0,1,0],[0,0,0]])
        self.assertAlmostEqual(r['accuracy'],2/3)
        self.assertAlmostEqual(r['macro_f1'],4/9)
        self.assertAlmostEqual(r['macro_f1_supported'],2/3)

    def test_uncertain_and_condition_denominator(self):
        rows=[dict(ingredient='apple',condition=s,pred_ingredient=p,pred_condition='visible_defect')
              for s,p in [('uncertain','apple'),('normal_appearance','apple'),('visible_defect','orange')]]
        r=classifier_metrics(rows,['apple','orange'])
        self.assertEqual(r['ingredient']['n'],3)
        self.assertEqual(r['joint']['n'],2)
        self.assertEqual(r['uncertain_excluded'],1)
        self.assertEqual(r['condition_denominator'],1)
        self.assertEqual(r['condition_given_correct_ingredient'],0)

    def test_empty_not_zero_accuracy(self):
        r=classifier_metrics([],['apple'])
        self.assertIsNone(r['ingredient']['accuracy'])
        self.assertIsNone(r['joint']['macro_f1'])

    def test_detection_perfect_duplicate_miss_wrong_label(self):
        gt=[dict(id=str(i),image_id='im',bbox=[i*20,0,i*20+10,10],label='apple') for i in range(4)]
        ps=[dict(g,confidence=.9) for g in gt]
        self.assertEqual(detection_metrics(ps,gt)['class_aware_map50_95'],1)
        duplicate=dict(ps[0],id='dup',confidence=.95)
        r=detection_metrics([duplicate,*ps[:-1]],gt)
        self.assertEqual(r['localization_tp_iou50'],3)
        self.assertEqual(r['localization_recall_iou50'],.75)
        self.assertLess(r['localization_ap50'],1)
        wrong=[dict(g,confidence=.9,label='peach') for g in gt]
        r=detection_metrics(wrong,gt)
        self.assertEqual(r['localization_recall_iou50'],1)
        self.assertEqual(r['class_aware_map50_95'],0)

    def test_iou_and_no_gt(self):
        self.assertEqual(iou([0,0,10,10],[5,0,15,10]),1/3)
        self.assertIsNone(average_precision([],[],.5))

    def test_out_of_scope_is_not_a_detector_class(self):
        gt=[dict(id='gt',image_id='im',bbox=[0,0,10,10],label='out_of_scope')]
        ps=[dict(gt[0],label='avocado',confidence=.9)]
        result=detection_metrics(ps,gt)
        self.assertEqual(result['localization_recall_iou50'],1)
        self.assertIsNone(result['class_aware_map50_95'])
        self.assertEqual(result['class_aware_out_of_scope_gt_excluded'],1)


class FakeModel:
    def __init__(self):
        self.seen=[]
    def predict_ingredient(self,image):
        self.seen.append(image.tobytes())
        return dict(ingredient='apple',condition='normal_appearance')


class WorkflowTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name)
        self.data=self.root/'test'; (self.data/'images').mkdir(parents=True)
        Image.new('RGB',(60,30),'red').save(self.data/'images/a.png')
        self.im=inventory(self.data)['images'][0]
        self.ingredients=['apple','orange']
        self.project=self.root/'project'; (self.project/'config').mkdir(parents=True)
        write_json(self.project/'config/ingredient_pipeline.json',dict(aliases={},confidence=.25,image_size=640,iou=.7,agnostic_nms=False,max_detections=50))
        (self.project/'best.pt').write_bytes(b'fake detector test fixture')
        self.annotation=dict(image_id=self.im['image_id'],image_sha256=self.im['sha256'],status='reviewed',reviewer='human',actual_count=2,bbox_complete=True,
                             objects=[dict(id='g1',ingredient='apple',condition='normal_appearance',bbox=[0,0,20,20]),dict(id='g2',ingredient='orange',condition='uncertain',bbox=[30,0,50,20])],detection_reviews=[])

    def tearDown(self): self.tmp.cleanup()

    def frozen(self):
        self.calls=0
        def detector(image):
            self.calls+=1
            return [dict(bbox=[0,0,20,20],original_label='Peach',confidence=.9),
                    dict(bbox=[0,0,20,20],original_label='Apple',confidence=.8)]
        return freeze(self.data,self.root/'output',self.ingredients,project=self.project,detector=detector)

    def predictions(self,run):
        import unittest.mock
        models={'v5':FakeModel(),'v6':FakeModel()}
        with unittest.mock.patch('research.real_world_test.model_contract',return_value={}):
            infer(run,models,self.project)
        return models

    def test_append_only_review_requires_reason(self):
        saved=save_annotation(self.data,self.annotation,self.im,self.ingredients)
        with self.assertRaises(ValueError): save_annotation(self.data,self.annotation,self.im,self.ingredients)
        corrected=copy.deepcopy(self.annotation); corrected['status']='draft'
        save_annotation(self.data,corrected,self.im,self.ingredients,'recheck crop')
        self.assertIsNone(latest_annotation(self.data,self.im['image_id'],True))
        self.assertEqual(len(list((self.data/'annotations'/self.im['image_id']).glob('*.json'))),2)
        self.assertEqual(saved['status'],'reviewed')

    def test_invalid_labels_boxes_and_duplicate_matches(self):
        for change in ['ingredient','bbox','actual_count','duplicate']:
            a=copy.deepcopy(self.annotation)
            if change=='ingredient': a['objects'][0]['ingredient']='Peach'
            if change=='bbox': a['objects'][0]['bbox']=[20,0,0,20]
            if change=='actual_count': a['actual_count']=3
            if change=='duplicate': a['detection_reviews']=[dict(run_id='r',detection_id=d,decision='valid',gt_id='g1') for d in ('a','b')]
            with self.assertRaises(ValueError): save_annotation(self.data,a,self.im,self.ingredients)

    def test_shared_crops_single_yolo_and_immutable(self):
        run=self.frozen(); self.assertEqual(self.calls,1)
        models=self.predictions(run)
        self.assertEqual(models['v5'].seen,models['v6'].seen)
        with self.assertRaises(FileExistsError): self.predictions(run)
        frozen=read_json(run/'frozen.json'); path=run/frozen['crops'][0]['crop_path']; path.write_bytes(b'changed')
        with self.assertRaises(ValueError): evaluate(self.data,run,self.ingredients)

    def test_missed_unsupported_duplicate_pipeline(self):
        save_annotation(self.data,self.annotation,self.im,self.ingredients)
        run=self.frozen(); self.predictions(run)
        report=evaluate(self.data,run,self.ingredients); result=read_json(report/'summary.json')
        self.assertEqual(result['yolo']['actual_objects'],2)
        self.assertEqual(result['yolo']['matched_objects'],1)
        self.assertEqual(result['yolo']['duplicate_candidates_iou50'],1)
        self.assertEqual(result['classifiers']['v5']['ingredient']['accuracy'],1)
        self.assertEqual(result['pipeline']['v5']['ingredient_recall'],0) # matched Peach is gated out
        self.assertEqual(result['pipeline']['v5']['actual_objects_denominator'],2)
        self.assertTrue((report/'v5_ingredient_confusion.png').exists())
        manual=freeze(self.data,self.root/'output',self.ingredients,project=self.project,manual=True)
        self.predictions(manual)
        assisted=read_json(evaluate(self.data,manual,self.ingredients)/'summary.json')
        self.assertEqual(assisted['scope'],'manual_assisted')
        self.assertEqual(assisted['pipeline']['v5']['ingredient_recall'],.5)

    def test_count_review_has_no_map_and_no_ground_truth_from_ai(self):
        run=self.frozen(); self.predictions(run)
        self.assertIsNone(latest_annotation(self.data,self.im['image_id']))
        a=copy.deepcopy(self.annotation); a['bbox_complete']=False
        for obj in a['objects']: obj['bbox']=None
        crop=read_json(run/'frozen.json')['crops'][0]
        a['detection_reviews']=[dict(run_id=run.name,detection_id=crop['id'],decision='valid',gt_id='g1')]
        save_annotation(self.data,a,self.im,self.ingredients)
        summary=read_json(evaluate(self.data,run,self.ingredients)/'summary.json')
        self.assertNotIn('iou_metrics',summary['yolo'])
        self.assertFalse(summary['matching_complete'])

    def test_empty_dataset_report(self):
        empty=self.root/'empty'; (empty/'images').mkdir(parents=True)
        run=freeze(empty,self.root/'output',self.ingredients,project=self.project)
        self.predictions(run)
        report=evaluate(empty,run,self.ingredients)
        self.assertIsNone(read_json(report/'summary.json')['classifiers']['v5']['ingredient']['accuracy'])

    def test_audit_exact_near_and_missing(self):
        manifest=self.project/'refs.csv'
        with manifest.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=['path']); w.writeheader()
            w.writerow(dict(path=str(self.data/'images/a.png')))
            w.writerow(dict(path=str(self.root/'missing.png')))
        result=read_json(audit(self.data,self.root/'out',self.project,manifests=['refs.csv','absent.csv'])/'audit.json')
        self.assertEqual(result['examined'],1)
        self.assertEqual(result['unreadable'],1)
        self.assertEqual(len(result['missing_manifests']),1)
        self.assertFalse(result['independence_confirmed'])
        self.assertGreaterEqual(result['match_rows'],3)

    def test_jupyter_manual_entry_and_resume(self):
        from research.review_notebook import review
        # Simulated human input, deliberately independent of any AI prediction.
        answers=iter(['count','1','object','gt001','orange','uncertain','0,0,20,20',
                      'source','new photo','session-1','approve','reviewer','yes','quit'])
        displayed=[]
        review(self.data,self.ingredients,input_fn=lambda _: next(answers),display_fn=displayed.append)
        ann=latest_annotation(self.data,self.im['image_id'],True)
        self.assertEqual(ann['objects'][0]['ingredient'],'orange')
        self.assertEqual(ann['capture_session'],'session-1')
        self.assertEqual(ann['actual_count'],1)
        self.assertGreaterEqual(len(displayed),2)
        answers=iter(['quit'])
        review(self.data,self.ingredients,input_fn=lambda _:next(answers),display_fn=lambda _:None)
        self.assertEqual(latest_annotation(self.data,self.im['image_id'])['revision'],ann['revision'])


if __name__=='__main__': unittest.main()
