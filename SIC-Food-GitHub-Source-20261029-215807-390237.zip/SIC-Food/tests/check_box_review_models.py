"""Real CPU checks for manual recovery. New reports only; no old review writes."""
import copy
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    from image_service import decode_image
    from model_loader import load_model,load_condition_model
    from ingredient_pipeline import analyze_ingredients,annotate_objects
    from box_review import start_review,update_box,delete_box,restore_boxes,export_review
    from detection_service import detect_image
    from page2 import detect_video_frame

    output=ROOT/'reports/module2_box_editor_20261029'
    output.mkdir(parents=True,exist_ok=True)
    reference=json.loads((ROOT/'reports/module2_v5_20261029/real_pipeline_results.json').read_text(encoding='utf-8'))
    baseline={(r['image_file'],r['object_id']):(r['bbox_xyxy'],r['yolo_label'],r['ingredient'],r['condition'])
              for r in reference['predictions']}
    detector,classifier=load_model(),load_condition_model()
    assert detector is load_model() and classifier is load_condition_model()
    assert classifier.metadata['version']=='v5' and len(classifier.class_names)==38
    cache={}; count=0
    for file in sorted((ROOT/'tests/manual_pipeline_images').iterdir()):
        if file.suffix.lower() not in ('.jpg','.jpeg','.png'):continue
        image=decode_image(file.read_bytes())
        result=analyze_ingredients(image,detector,classifier)
        for row in result['objects']:
            assert baseline[(file.name,row['object_id'])]==(row['bbox_xyxy'],row['yolo_label'],row['ingredient'],row['condition'])
            count+=1
        cache[file.name]=result
    assert count==63

    file=ROOT/'tests/manual_pipeline_images/images (3).jpg'
    image=decode_image(file.read_bytes())
    initial=cache[file.name]
    assert initial['objects']==[], 'This image must demonstrate actual YOLO misses.'
    workspace=start_review(initial,hashlib.sha256(file.read_bytes()).hexdigest())
    annotate_objects(image,workspace['objects']).save(output/'missed_oranges_before.jpg')
    with patch.object(classifier,'predict_ingredient',wraps=classifier.predict_ingredient) as infer:
        workspace,ids=update_box(workspace,image,classifier,None,[66,235,260,425],'orange',True)
        assert ids==[1] and infer.call_count==1
        unchanged=copy.deepcopy(workspace['objects'][0])
        workspace,ids=update_box(workspace,image,classifier,None,[242,278,434,469],'orange',True)
        assert ids==[2] and infer.call_count==2
        assert workspace['objects'][0]==unchanged
        both=copy.deepcopy(workspace)
        annotate_objects(image,workspace['objects']).save(output/'missed_oranges_after.jpg')
        untouched=copy.deepcopy(workspace['objects'][1])
        workspace,ids=update_box(workspace,image,classifier,1,[70,240,257,421])
        assert ids==[1] and infer.call_count==3 and workspace['objects'][1]==untouched
        again,ids=update_box(workspace,image,classifier,1,[70,240,257,421])
        assert ids==[] and infer.call_count==3 and again is workspace
        workspace=delete_box(workspace,2)
        assert len(workspace['objects'])==1 and infer.call_count==3
        workspace=restore_boxes(workspace)
        assert workspace['objects']==[] and infer.call_count==3
        crop_runs=infer.call_count
    orange_report=export_review(both)
    (output/'missed_oranges_review.json').write_text(json.dumps(orange_report,ensure_ascii=False,indent=2),encoding='utf-8')

    file=ROOT/'tests/manual_pipeline_images/images.jpg'
    image=decode_image(file.read_bytes())
    result=cache[file.name]
    workspace=start_review(result,hashlib.sha256(file.read_bytes()).hexdigest())
    peach=next(r for r in workspace['objects'] if r['yolo_label']=='Peach')
    assert peach['status']=='unsupported'
    other=[copy.deepcopy(r) for r in workspace['objects'] if r['object_id']!=peach['object_id']]
    with patch.object(classifier,'predict_ingredient',wraps=classifier.predict_ingredient) as infer:
        workspace,ids=update_box(workspace,image,classifier,peach['object_id'],peach['crop_xyxy'],'apple',True)
        assert infer.call_count==1 and ids==[peach['object_id']]
    assert [r for r in workspace['objects'] if r['object_id']!=peach['object_id']]==other
    recovered=next(r for r in workspace['objects'] if r['object_id']==peach['object_id'])
    assert recovered['yolo_label']=='Peach' and recovered['manual_confirmation']['ingredient']=='apple'
    (output/'peach_review.json').write_text(json.dumps(export_review(workspace),ensure_ascii=False,indent=2),encoding='utf-8')
    annotate_objects(image,workspace['objects']).save(output/'peach_after_confirmation.jpg')
    sample=decode_image((ROOT/'images/test image.png').read_bytes())
    detections,_=detect_image(detector,sample)
    video,_=detect_video_frame(detector,ROOT/'images/test video.mp4',0)
    assert len(detections)==5 and len(video)==2
    summary={'baseline_images':len(cache),'baseline_boxes_unchanged':count,
        'missed_oranges_yolo_boxes':0,'oranges_added':2,
        'manual_orange_predictions':[{'object_id':r['object_id'],'ingredient':r['ingredient'],
            'condition':r['condition'],'status':r['status']} for r in both['objects']],
        'crop_runs_for_add_add_edit_noop_delete_restore':crop_runs,
        'peach_original_status':peach['status'],'peach_after_confirmation':recovered['ingredient'],
        'module1_image_boxes':len(detections),'module1_video_boxes':len(video),
        'caveat':'Manual boxes selected by a human; two oranges remain a diagnostic example, not an accuracy benchmark.'}
    (output/'real_checks.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    print('PASS: real V5 selective inference and unchanged automatic baseline.')


if __name__=='__main__': main()
