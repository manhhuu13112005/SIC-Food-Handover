"""Local Streamlit V2 canvas. Static trusted assets; dynamic data is never HTML."""
import base64
from io import BytesIO
from pathlib import Path

from streamlit.components.v2 import component

ASSETS = Path(__file__).resolve().parent / 'components/box_editor'
_canvas = component('sic_box_editor',
    html=(ASSETS/'editor.html').read_text(encoding='utf-8'),
    css=(ASSETS/'editor.css').read_text(encoding='utf-8'),
    js=(ASSETS/'editor.mjs').read_text(encoding='utf-8'), isolate_styles=True)


def preview_data(image):
    preview = image.copy()
    preview.thumbnail((1024,1024))
    buffer = BytesIO()
    preview.save(buffer, format='JPEG', quality=88)
    return 'data:image/jpeg;base64,' + base64.b64encode(buffer.getvalue()).decode('ascii')


def render_box_canvas(image_data, image_size, workspace, selected_id, draft, key):
    data = {'image_data':image_data, 'width':image_size[0], 'height':image_size[1],
        'analysis_id':workspace['analysis_id'], 'image_token':workspace['image_token'],
        'revision':workspace['revision'], 'selected_id':selected_id, 'draft':draft,
        'objects':[{'object_id':r['object_id'], 'bbox':r['crop_xyxy'],
                    'source':'manual' if r.get('origin') == 'manual' else 'edited' if r.get('geometry_edited') else 'yolo'}
                   for r in workspace['objects'] if r['crop_xyxy']]}
    # "event" is a trigger, not a state key. A manual default would shadow it.
    value = _canvas(data=data, key=key, on_event_change=lambda:None)
    return value.event
