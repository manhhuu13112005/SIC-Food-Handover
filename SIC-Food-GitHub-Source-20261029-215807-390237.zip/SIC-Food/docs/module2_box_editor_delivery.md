# Bàn giao công cụ quản lý bounding box Module 2

Ngày 29/10/2026. Source chính: `C:\Users\ASUS\SIC-Food`.

## Kết quả

Đã mở rộng Module 2 đang hoạt động, giữ một pipeline **YOLO → crop → EfficientNet V5**. Người dùng vẫn upload và phân tích tự động trước, rồi mới mở công cụ để chọn/thêm/sửa/loại/khôi phục box. Không có chế độ phân loại tự động toàn ảnh.

Chỉ crop thay đổi hoặc box được mở phạm vi bằng xác nhận thủ công mới chạy V5. Không chạy lại YOLO khi chỉnh box. Kết quả của các box khác giữ nguyên. Box thêm thủ công không được gán nhãn/điểm YOLO giả.

## Source và sao lưu

Đã đọc pipeline, page, detection/classification services, app_state, cấu hình, test và báo cáo `docs/module2_v5_delivery.md` trước khi sửa.

Sao lưu: `backups/module2_box_editor_20261029_160614/`, kèm `source_hashes.json` và `protected_hashes.json`. Kiểm tra cuối: **32/32 file bảo vệ khớp hash** gồm weights YOLO/V5/V6, notebook, source/dữ liệu Module 1, manifest Train/Validation, services nạp/suy luận model hiện có và bảng kiểm duyệt cũ.

### Các file sửa

| File | Thay đổi |
| --- | --- |
| `ingredient_pipeline.py` | Tách phần suy luận crop đã có thành `classify_object`, dùng chung cho tự động và box chỉnh sửa; giữ phép gộp điểm/preprocessing; annotation ghi nguồn vùng |
| `condition_page.py` | Thêm công cụ quản lý vùng trong cùng trang; ảnh/thẻ theo box đang giữ; hiển thị nguồn YOLO/sửa/thêm, xác nhận thủ công; JSON schema 2 |
| `app_state.py` | Reset workspace/canvas theo ảnh; bỏ qua callback cũ của widget/box đã được thay hoặc loại |
| `README.md` | Hướng dẫn thao tác, chạy/test, contract xuất JSON và giới hạn mới |
| `tests/ui_harness.py` | Fixture canvas/model ghi rõ; hỗ trợ kiểm tra V5 riêng crop; không dùng trong production |
| `tests/test_website_ui.py` | Điều chỉnh một kỳ vọng: ảnh không có box vẫn phải có selector công cụ thêm vùng, nhưng không có thẻ sửa nhãn đối tượng |

### Các file mới

- `box_review.py`: thao tác workspace dạng giao dịch, snapshot gốc, provenance, lịch sử, ID ổn định và validation sự kiện.
- `box_editor_ui.py`: UI chọn box, tọa độ, xác nhận phạm vi, thêm/sửa/loại/khôi phục.
- `box_editor_component.py`: wrapper canvas V2 có sẵn của Streamlit.
- `components/box_editor/editor.html`, `editor.css`, `editor.mjs`: frontend cục bộ, kéo vùng/click chọn box và đổi tọa độ theo kích thước ảnh gốc.
- `tests/test_box_review.py`, `test_box_review_ui.py`, `box_editor_geometry.test.mjs`: regression mới.
- `tests/check_box_review_models.py`: kiểm tra thật CPU và ghi báo cáo riêng.
- Báo cáo này và `reports/module2_box_editor_20261029/`.

Không sửa `condition_service.py`, `detection_service.py`, model loader, cấu hình confidence/IoU/padding/NMS, checkpoint, dataset, notebook hoặc logic dinh dưỡng. Không huấn luyện và không cài thêm thư viện.

## Dependency, bảo mật và bảo trì

Đã kiểm tra Streamlit **1.65.0** cài trên máy có `streamlit.components.v2.component`. Dùng API này với canvas HTML/CSS/JavaScript nhỏ trong repository, không thêm package canvas bên thứ ba, npm bundle hoặc CDN. Node chỉ phục vụ chạy test JavaScript, không cần khi mở website.

Component V2 chạy như mã tin cậy của ứng dụng; shadow DOM chỉ cô lập style, **không phải sandbox bảo mật**. Vì vậy:

- HTML/CSS/JS là các file tĩnh do dự án quản lý; không ghép nội dung người dùng vào mã hoặc HTML.
- Dynamic data đi qua `data`; text dùng `textContent` và canvas text, không dùng `innerHTML`/eval.
- Ảnh preview do server tạo dưới dạng JPEG data URI; frontend không tải URL tùy ý, không fetch/CDN, không lưu localStorage.
- Python kiểm tra lại kiểu dữ liệu, tọa độ hữu hạn/trong ảnh, ID mục tiêu, image token, analysis ID và revision; bỏ sự kiện stale/replay.
- Kéo chỉ tạo bản nháp, không thêm box hoặc suy luận cho đến khi người dùng bấm áp dụng.
- Pointer listeners/ResizeObserver được dọn khi component unmount.
- Có tọa độ số thay thế thao tác kéo; cần mang theo thư mục `components/box_editor` khi chia sẻ source.

Tham chiếu chính thức: [component V2](https://docs.streamlit.io/develop/api-reference/custom-components/st.components.v2.component), [state và trigger](https://docs.streamlit.io/develop/concepts/custom-components/components-v2/state-and-triggers). Đã đối chiếu thêm API và cách ghép trigger/state trong package 1.65 cài cục bộ; không chỉ dựa vào tài liệu web phiên bản mới hơn.

## Hướng dẫn sử dụng

1. Upload ảnh trong **Trạng thái nguyên liệu** và bấm **Phân tích bằng AI** như trước.
2. Mở **Quản lý vùng nguyên liệu · thêm / sửa / xóa box**.
3. Chọn box bằng cách nhấp vào vùng trên canvas hoặc chọn ID trong **Box cần chỉnh sửa**. Với box trùng/chồng nhau, danh sách cho phép chọn đúng từng ID; canvas ưu tiên box nhỏ nhất chứa điểm nhấp.
4. **Sửa vùng:** chọn box, kéo hình chữ nhật mới; có thể nhập tiếp Trái/Trên/Phải/Dưới bằng pixel ảnh gốc. Bấm **Áp dụng vùng / xác nhận**.
5. **Loại box:** chọn ID rồi bấm **Loại box đã chọn**. Box được giữ trong dữ liệu loại/lịch sử của phiên và không mất snapshot YOLO ban đầu.
6. **Thêm box bị bỏ sót:** chọn **＋ Thêm box mới**, kéo vùng hoặc nhập tọa độ, chọn nguyên liệu trong 19 loại, đánh dấu **Tôi xác nhận vùng chọn là nguyên liệu đã chọn để chạy V5**, rồi bấm **Thêm box và phân tích V5**.
7. **YOLO sai nhãn, ví dụ Peach nhưng thực tế là Táo:** chọn box, chọn Táo trong **Nguyên liệu người dùng xác nhận**, đánh dấu xác nhận rồi áp dụng. Nhãn YOLO gốc vẫn là Peach; V5 tự dự đoán trên crop, không bị ép thành Táo.
8. **Khôi phục:** bấm **Khôi phục box YOLO ban đầu** để trở về box/kết quả ban đầu và bỏ vùng/bản sửa hiện tại, không chạy lại model.
9. **Xuất JSON:** tải file chứa snapshot gốc, vùng hiện tại, vùng đã loại, lịch sử và bản sửa nhãn.

Xác nhận nguyên liệu được lưu kèm timestamp UTC và nguồn thao tác. Box thêm thủ công không có yolo_label/yolo_score/class_id; không tự giả lập YOLO đã nhận ra nó. Box unsupported có thể được sửa vùng mà vẫn giữ unsupported nếu chưa xác nhận nguyên liệu.

## Quy tắc cập nhật và ID

- Snapshot `cond_result`/`original_analysis` giữ nguyên từ lần chạy tự động.
- `cond_workspace.objects` là các vùng đang giữ; thêm metadata `origin`, `yolo_object_id`, `geometry_edited`, `manual_confirmation`, `crop_revision`.
- ID YOLO giữ nguyên; box mới nhận ID tăng dần, không dùng lại ID đã xóa, kể cả sau restore. Không đánh lại số các box khác khi kéo/xóa; dãy ID có thể có khoảng trống.
- ID trong ảnh và thẻ luôn là cùng một `object_id`.
- Vùng/loại tham chiếu không đổi không suy luận lại. Xác nhận cùng nguyên liệu trên crop đã phân loại được ghi riêng và tái sử dụng kết quả.
- Chỉ box thay crop/tham chiếu mới mất bản sửa nhãn trước đó, tránh dùng xác nhận cũ cho crop mới. Bản sửa và kết quả các box còn lại giữ nguyên.
- Xóa hoặc khôi phục không gọi YOLO/V5. Cache model hiện có tiếp tục được sử dụng khi cần V5.
- Đổi ảnh/xóa ảnh/Reset xóa workspace, draft, preview và kết quả cũ. Chuyển trang giữ các box đã áp dụng; draft chưa áp dụng có thể trở về crop đang lưu.
- JSON schema 2: `original_yolo_analysis`, `working_objects`, `working_summary`, `removed_objects`, `history`, `user_edits`, `effective_results`, image token và revision. Tổng quan hiện tính theo vùng đang giữ và ghi số box YOLO ban đầu riêng.

## Kiểm thử cuối

| Nhóm kiểm tra | Kết quả |
| --- | --- |
| Toàn bộ unittest hiện tại và mới | **85/85 PASS**, 11,743 giây, ngoài sandbox Windows |
| Test JavaScript hình học/click box chồng nhau | **3/3 PASS** |
| AST root/tests | **35 file PASS** |
| Model thật V5 trên CPU | **PASS**, không đổi checkpoint/preprocessing |
| Baseline tự động 18 ảnh | **63/63 box giữ nguyên** bbox/nhãn YOLO/nguyên liệu/trạng thái so với báo cáo trước |
| Module 1 model thật | **5 box ảnh / 2 box video frame 0** |
| Module 1 dinh dưỡng và điều hướng | **PASS** trong bộ hồi quy; source/data giữ nguyên hash |
| File bảo vệ | **32/32 hash khớp** |
| Startup/health | **HTTP 200, ok**, cổng 8502 |
| Browser canvas thật | Kéo vùng → tọa độ Python → xác nhận Cam → thêm box → V5 → thẻ và cảnh báo: **PASS** |
| JSON tải từ browser thật | **PASS**, schema 2, snapshot 0 box, working 1 box, history 1 add_box |

### Các tình huống bắt buộc

| Tình huống | Bằng chứng |
| --- | --- |
| Bốn quả táo đúng | Test giữ ID/crop và kiểm tra baseline thật trong 18 ảnh |
| Box trùng | Fixture hai box cùng vùng; loại một, giữ một, restore đúng snapshot; không chạy model |
| Bỏ sót cam | Ảnh thật `images (3).jpg` có hai quả cam, YOLO trả 0 box; browser thêm một vùng, CLI thêm hai vùng |
| Apple bị gọi Peach | Ảnh thật `images.jpg`; chỉ sau xác nhận thủ công mới chạy V5; kết quả V5 là apple, YOLO gốc vẫn Peach |
| Xóa/thêm/sửa | Pure state tests, AppTest và minh chứng browser thêm vùng |
| Chỉ crop thay đổi chạy lại | Spy model thật: thêm 1, thêm 2, sửa box 1 tạo tổng 3 lần; no-op/xóa/restore không tăng; kết quả box 2 giữ nguyên khi sửa box 1 |
| Đổi ảnh/Reset/JSON | AppTest cùng JSON download thực tế |
| Module 1 không đổi | Hồi quy UI/dinh dưỡng, inference thật và hash |

### Các lỗi đã phát hiện và xử lý trong quá trình thực hiện

- Widget tọa độ bị Streamlit cleanup khi chuyển trang nhưng binding còn lưu: đã bổ sung seed lại các key thiếu; test hiện kiểm tra exception ngay sau navigation.
- Callback cũ từ widget đã bị loại có thể tới muộn: bỏ qua callback nếu key/box không còn tồn tại.
- Trigger canvas bị default state cùng tên che mất: bỏ `default={'event': None}` cho trigger; thêm test dùng `ComponentResult` thật và xác minh browser kéo vùng cập nhật tọa độ.

Các lỗi trên đã được sửa trước lần kiểm thử cuối. Không ghi PASS cho một bước chỉ vì model/canvas mock chạy được. Các stack trace synthetic trong unittest là lỗi cố ý để kiểm tra xử lý exception, không phải lỗi production cuối.

## Kết quả thật và giới hạn model

File mới trong `reports/module2_box_editor_20261029/`:

- `real_checks.json`: tóm tắt CPU/baseline và số lần suy luận.
- `missed_oranges_review.json`, `peach_review.json`: snapshot, lịch sử, kết quả model thật.
- `missed_oranges_before.jpg`, `missed_oranges_after.jpg`, `peach_after_confirmation.jpg`: ảnh annotation từ service.
- `browser_missed_before.jpg`, `browser_missed_after.jpg`: screenshot trình duyệt thật.
- `browser_export_snapshot.json`: nội dung JSON đã tải từ website và kiểm tra lại.

**Minh chứng bỏ sót là thật, nhưng V5 vẫn nhầm nguyên liệu:** trên hai crop cam được bổ sung trong CLI, V5 dự đoán `mango / visible_defect` và status `disagreement`; browser cũng hiển thị tham chiếu người dùng Cam và dự đoán Xoài. Công cụ đã khôi phục được vùng cần phân tích, không sửa được mọi lỗi nhận dạng của model. Không ép kết quả thành Cam để báo thành công.

![Vùng bổ sung thủ công và cảnh báo bất đồng thật](../reports/module2_box_editor_20261029/browser_missed_after.jpg)

Đây là ví dụ chẩn đoán nhỏ, không phải benchmark hoặc bằng chứng tăng accuracy tổng thể.

## Chạy trên Windows và Jupyter

CMD/Anaconda Prompt trong môi trường `sic-food`:

```bat
cd /d "C:\Users\ASUS\SIC-Food"
python -m streamlit run main.py --server.port 8502
```

Server hiện có đã được khởi động lại để nạp source mới, vẫn chỉ lắng nghe localhost. Nếu cổng 8502 đang chạy thì mở http://127.0.0.1:8502 thay vì khởi động thêm.

Jupyter trong đúng kernel:

```python
import subprocess, sys
from pathlib import Path
root = Path(r"C:\Users\ASUS\SIC-Food")
with (root / "streamlit.log").open("a", encoding="utf-8") as log:
    server = subprocess.Popen(
        [sys.executable, "-m", "streamlit", "run", str(root / "main.py"),
         "--server.address", "127.0.0.1", "--server.port", "8502"],
        cwd=root, stdout=log, stderr=subprocess.STDOUT,
        creationflags=subprocess.CREATE_NO_WINDOW,
    )
print("http://127.0.0.1:8502")
# Chỉ dừng server do cell này tạo khi cần:
# server.terminate()
```

Lệnh kiểm thử:

```bat
python -B -m unittest discover -s tests -p "test_*.py"
python -B tests/check_box_review_models.py
node --test tests/box_editor_geometry.test.mjs
```

Không cần chạy notebook training. Không sửa hoặc thay model V6.

## Hạn chế còn lại

- Chỉ có chọn/vẽ lại hình chữ nhật trục thẳng và tọa độ số; chưa có resize bằng các tay nắm ở góc, polygon hoặc segment mask.
- Box trùng không tự bị xóa; người dùng chọn đúng ID và loại. Giữ NMS theo lớp, padding 0% và confidence 0,25.
- Snapshot và lịch sử chỉ trong phiên RAM; restore là về bản YOLO đầu tiên, chưa có undo từng bước hoặc lưu tài khoản.
- Xác nhận nguyên liệu chỉ mở phạm vi crop để chạy V5, không bảo đảm V5 đúng. Trường hợp cam/Xoài ở trên còn cần người dùng xem lại hoặc sửa nhãn hiển thị.
- Giới hạn 50 vùng đang giữ; có thể phải loại box không liên quan trước khi thêm.
- Canvas dùng preview tối đa 1024×1024 nhưng tọa độ được đổi về ảnh gốc; vật quá nhỏ có thể dễ chỉnh bằng tọa độ số hơn kéo chuột.
- Chưa kiểm thử điện thoại thật, mọi trình duyệt hoặc tải nhiều người dùng đồng thời. Không có training, calibration/OOD mới hoặc thay đổi chất lượng dataset trong công việc này.
