# Bàn giao giai đoạn C — kiểm thử độc lập V5/V6

Ngày kiểm tra: 29/10/2026. Công cụ đã triển khai trực tiếp, chỉ thêm file nghiên cứu. Website tiếp tục dùng V5.

## Kết luận hiện tại

**Chưa đủ dữ liệu để so sánh độc lập V5/V6.** Thư mục Test mới có 0 ảnh, 0 đối tượng được duyệt. CSV collection_targets.csv chỉ là kế hoạch thu thập, không phải Ground Truth. Không công bố accuracy, mAP thực tế, lớp yếu hoặc model thắng khi chưa đo được. Bộ thăm dò 18 ảnh cũ không tham gia số liệu đánh giá này.

- [Báo cáo nghiên cứu theo run](runs/20261029T100518473475Z_e26ff77a/evaluations/20261029T101104740440Z_0bf7b106/report.md)
- [Kết quả có mẫu số rõ ràng](runs/20261029T100518473475Z_e26ff77a/evaluations/20261029T101104740440Z_0bf7b106/summary.json)
- [Audit phạm vi tham chiếu](audits/20261029T100230344929Z_b3ac90d6/audit.json): 4 manifest, 36.924 đường dẫn tham chiếu duy nhất; chưa quét ảnh tham chiếu vì Test trống. Trạng thái SKIPPED_NO_TEST_IMAGES, independence_confirmed=false. Không kết luận không rò rỉ.

## Kiểm tra đã chạy

| Kiểm tra | Kết quả | Phạm vi |
|---|---|---|
| Toàn bộ Python unittest bản bàn giao | PASS 99/99 | 85 test cũ + 14 test mới |
| JavaScript box editor | PASS 3/3 | Hồi quy tọa độ và chọn box |
| YOLO + V5 + V6 thật trên CPU | PASS kỹ thuật | 6 crop chung, 12 dự đoán; không đo accuracy |
| Notebook | PASS compile + mô phỏng nhập/duyệt/lưu/đọc lại bằng Jupyter reviewer | Chưa kiểm tra thủ công frontend Jupyter trên trình duyệt |
| Bảo vệ file có sẵn | PASS 84/84 SHA-256 giữ nguyên | Source, cấu hình, checkpoint, CSV cũ và manifest đã chụp trước triển khai |
| So sánh độc lập Test mới | CHƯA THỂ ĐÁNH GIÁ | 0 ảnh, 0 nhãn |

[Log hồi quy cuối](regression_tests_release.log). [Xác minh file bảo vệ](protection_verification.json). [Suy luận CPU kỹ thuật](runs/20261029T100237831116Z_64b44069/technical_smoke.json).

Trong một lần chạy trung gian, test cũ test_classification_prepare_idempotent_and_no_crop thất bại với 0 thay vì 2 bản ghi fixture. Chạy riêng PASS; hai lần hồi quy tiếp theo PASS (98 và 99 test). Chưa xác định nguyên nhân không ổn định; không sửa source cũ. Giữ log tại regression_tests_verified.log, isolated_legacy_test.log và regression_tests_rerun.log. Một lần chạy trong sandbox ban đầu bị từ chối tempfile; các lần xác nhận chạy ngoài sandbox. Các lỗi mô phỏng model failure trong log UI là tình huống kiểm thử dự kiến.

V5/V6 đều được nạp bằng loader kiểm tra chặt trên CPU: EfficientNet B0, 38 lớp, cùng thứ tự 19 nguyên liệu ×2 trạng thái, Resize 224×224, ToTensor, ImageNet normalization. YOLO chạy một lần; PNG crop padding 0% và SHA-256 được giữ chung cho cả hai model. Checkpoint/model/preprocessing được lưu trong predictions.json. Smoke dùng ảnh kỹ thuật images/test image.png sẵn có, không dùng làm bằng chứng độc lập.

## File mới và chức năng

- ../../Real_World_Test_V1_Review.ipynb — quy trình Jupyter kiểm duyệt và tiếp tục phiên cũ.
- ../../research/__init__.py — package nghiên cứu độc lập.
- ../../research/review_notebook.py — hiển thị ảnh gốc/box, nhập số lượng, GT, trạng thái, tọa độ, duyệt box trùng/sai, lưu nháp và approve.
- ../../research/real_world_test.py — inventory, kiểm tra nhãn, lưu revision, freeze crop, nạp CPU, infer chung, evaluate, CSV/PNG/báo cáo.
- ../../research/evaluation_metrics.py — classification, macro F1, confusion matrix, IoU/AP101, matching một-một.
- ../../research/leakage_audit.py — trùng byte, trùng pixel, pHash; phạm vi Train/Validation, Test nội bộ và ứng viên trùng bộ thăm dò cũ.
- ../../scripts/evaluate_real_world.py — CLI inventory/freeze/infer/evaluate/audit/run/manual-freeze/smoke.
- ../../tests/test_real_world_evaluation.py — 14 test có đáp án biết trước, không phải số liệu model.
- ../../docs/real_world_test_v1_guide.md — hướng dẫn Windows CPU/Jupyter, mẫu số, cách đọc kết quả và giới hạn.

Mọi file cũ giữ nguyên; manifest bảo vệ nằm tại ../../backups/phase_c_protection_20261029_165358/protected_hashes.json. Dữ liệu Train/Validation chỉ được đọc manifest trong lần audit này, không chỉnh ảnh hoặc nhãn.

## Cách sử dụng

```powershell
cd C:\Users\ASUS\SIC-Food
conda activate sic-food
python -m notebook Real_World_Test_V1_Review.ipynb
```

Thêm ảnh mới vào datasets/real_world_test_v1/images, freeze một lần, kiểm duyệt thủ công bằng notebook rồi infer/evaluate và audit. Dùng kernel sic-food. Các lệnh và cách tiếp tục RUN cũ nằm trong hướng dẫn. Không có dependency giao diện mới; không dùng ipywidgets/sklearn/scipy. IPython và matplotlib đã có trong môi trường hiện tại.

## Các đầu ra khi có nhãn

YOLO tự động, classifier trên crop hợp lệ, pipeline tự động trên toàn bộ đối tượng và kết quả crop thủ công được báo cáo riêng. Có bảng từng ảnh, support theo trạng thái, accuracy theo nguyên liệu, P/R/F1 và macro F1, ma trận ingredient/joint, bảng thịt/hải sản, hai chiều V5 đúng/V6 sai, danh sách lỗi và ảnh crop có chú thích. uncertain bị loại khỏi trạng thái/joint, vẫn tính ingredient; luôn ghi số bị loại. Không có GT bbox đầy đủ thì chỉ có chỉ số duyệt thủ công, không có mAP. Hiện các bảng không có mẫu; không tạo ảnh lỗi hoặc biểu đồ accuracy giả.

## Đề xuất Train 4

1. Chưa chọn V5 hay V6 làm nền; giữ website V5. Chưa có bằng chứng để khẳng định cần fine-tune classifier hoặc detector.
2. Thu thập đủ nhãn độc lập cho cả 38 cặp nguyên liệu/trạng thái, nhiều phiên chụp. Tất cả lớp hiện có support=0 nên chưa xác định lớp yếu. Ưu tiên bảo đảm nhóm beef/pork/chicken/fish/shrimp và các cảnh nhiều đối tượng có mặt trong kế hoạch.
3. Khi có dữ liệu, dùng lỗi bỏ sót/trùng và IoU để quyết định cải thiện YOLO; dùng lỗi crop hợp lệ, trạng thái và nhầm lẫn nguyên liệu để quyết định EfficientNet. So sánh cặp V5/V6 trên cùng crop, báo support và giới hạn cỡ mẫu.
4. Nếu train tiếp trong một giai đoạn được cho phép sau: replay dữ liệu lớp cũ, balanced sampling, learning rate nhỏ, giám sát validation lớp cũ để hạn chế quên; chia theo phiên chụp/nguồn. Không đưa Test này vào Train. **Chưa thực hiện Train.**

## Giới hạn còn lại

Không có bằng chứng tổng quát hóa mới khi Test trống. pHash chỉ phát hiện ứng viên; nguồn ngoài 4 manifest và provenance phiên chụp chưa xác minh. Chỉ một người ghi nhãn tại một thời điểm; chưa có khóa nhiều session. Nhập bbox bằng tọa độ, chưa có canvas kéo thả trong notebook. Đánh giá class-aware YOLO chỉ trên nguyên liệu GT có tên trong 19 loại; out_of_scope là chưa xác minh nhãn đầy đủ trong 214 lớp. AP có IoU .50:.05:.95/101 recall points, không phải toàn bộ COCO crowd/ignore/area protocol. Điểm pipeline là recall theo đối tượng và được báo cùng detection precision. Kết quả trên một tập nhỏ không thay thế đánh giá tổng quát.
